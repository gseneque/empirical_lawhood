"""Read-only source correspondence; derivative, not kinetic prediction."""

import ast
import hashlib
import json
import pathlib
import shlex

from empirical_lawhood.adapters.physical.rubisco_kinetics.genbank import _CODON_TABLE
from empirical_lawhood.adapters.physical.rubisco_kinetics.workbook import decode_native_workbook

BASE = pathlib.Path('/tmp/empirical-lawhood-rubisco-20261009/public-inputs')
OUT = BASE / 'followup-plant4/tobacco-galdieria-alignment-inspection.json'


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def digest(sequence):
    return hashlib.sha256(sequence.encode('ascii')).hexdigest()


def align(a, b, match, mismatch, gap_open, gap_extend):
    """Global affine DP. All optimal paths examined at both requested sites.

    Gap length L scores gap_open+(L-1)*gap_extend, terminal gaps charged.
    States M (paired), X (gap in b), Y (gap in a); X/Y extend or open from M.
    A representative alignment prefers M,X,Y in ties; uncertainty census uses
    every reachable optimal predecessor, not the chosen representative.
    """
    n, m = len(a), len(b)
    bad = -10**9
    D = [[[bad] * (m + 1) for _ in range(n + 1)] for _ in range(3)]
    D[0][0][0] = 0
    for i in range(1, n + 1):
        D[1][i][0] = gap_open + (i - 1) * gap_extend
    for j in range(1, m + 1):
        D[2][0][j] = gap_open + (j - 1) * gap_extend
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            score = match if a[i - 1] == b[j - 1] else mismatch
            D[0][i][j] = max(D[s][i - 1][j - 1] for s in range(3)) + score
            D[1][i][j] = max(D[0][i - 1][j] + gap_open, D[1][i - 1][j] + gap_extend)
            D[2][i][j] = max(D[0][i][j - 1] + gap_open, D[2][i][j - 1] + gap_extend)
    optimum = max(D[s][n][m] for s in range(3))

    def predecessors(state, i, j):
        if i == j == 0:
            return []
        if state == 0:
            if not (i and j):
                return []
            score = match if a[i - 1] == b[j - 1] else mismatch
            return [(s, i - 1, j - 1) for s in range(3) if D[s][i - 1][j - 1] + score == D[state][i][j]]
        if state == 1:
            return [(s, i - 1, j) for s, penalty in [(0, gap_open), (1, gap_extend)] if i and D[s][i - 1][j] + penalty == D[state][i][j]]
        return [(s, i, j - 1) for s, penalty in [(0, gap_open), (2, gap_extend)] if j and D[s][i][j - 1] + penalty == D[state][i][j]]

    end_states = [(s, n, m) for s in range(3) if D[s][n][m] == optimum]
    reachable = set()
    todo = end_states.copy()
    sites = {369: set(), 391: set()}
    while todo:
        current = todo.pop()
        if current in reachable:
            continue
        reachable.add(current)
        state, i, j = current
        if i in sites and state in (0, 1):
            sites[i].add(j if state == 0 else None)
        todo.extend(predecessors(state, i, j))

    current = min(end_states)
    aa, bb = [], []
    while current[1:] != (0, 0):
        state, i, j = current
        aa.append(a[i - 1] if state != 2 else '-')
        bb.append(b[j - 1] if state != 1 else '-')
        current = min(predecessors(state, i, j))
    aa, bb = ''.join(reversed(aa)), ''.join(reversed(bb))
    assert aa.replace('-', '') == a and bb.replace('-', '') == b
    columns = []
    ai = bi = 0
    for x, y in zip(aa, bb):
        ai += x != '-'
        bi += y != '-'
        columns.append({'a': x, 'b': y, 'a_position': ai if x != '-' else None, 'b_position': bi if y != '-' else None})
    windows = {}
    for position in sites:
        k = next(k for k, c in enumerate(columns) if c['a_position'] == position)
        cs = columns[max(0, k - 20):k + 21]
        windows[str(position)] = {'a': ''.join(c['a'] for c in cs), 'b': ''.join(c['b'] for c in cs), 'columns': cs}
    return {
        'scoring': {'match': match, 'mismatch': mismatch, 'gap_open': gap_open, 'gap_extend': gap_extend},
        'global_score': optimum,
        'alignment': [aa, bb],
        'identical_pairs': sum(x == y and x != '-' for x, y in zip(aa, bb)),
        'paired_columns': sum(x != '-' and y != '-' for x, y in zip(aa, bb)),
        'a_gap_residues': aa.count('-'),
        'b_gap_residues': bb.count('-'),
        'all_optimal_site_mappings': {str(i): sorted(v, key=lambda x: -1 if x is None else x) for i, v in sites.items()},
        'site_windows': windows,
    }


native_path = BASE / 'followup-plant4/native-panel-inspection.json'
native = json.loads(native_path.read_text())
parent = native['parent_lsu']['translated_protein']
assert len(parent) == 477 and digest(parent) == native['parent_lsu']['protein_sha256']
s8_path = BASE / 'followup-plant4/tables-members/sciadv.aeh3246_table_s8.xlsx'
s8_payload = s8_path.read_bytes()
s8 = decode_native_workbook(s8_payload, expected_sha256=hashlib.sha256(s8_payload).hexdigest(), selected_sheets=('Sheet1',))
assert s8.fingerprint() == native['s8_identity']
s8_sheet = s8.worksheets[0]
assert s8_sheet.cell('A2').token == 'pET-NtLS-Rca'
plasmid = s8_sheet.cell('B2').token.upper()
assert len(plasmid) == 9000 and set(plasmid) <= set('ACGT')
cds = plasmid[4020:5454]
translation = ''.join(_CODON_TABLE[cds[i:i+3]] for i in range(0, len(cds), 3))
assert translation == parent + '*' and cds == native['parent_lsu']['dna']
reference_path = BASE / 'followup-plant4/P00876.txt'
reference_lines = reference_path.read_text().splitlines()
sq = next(i for i, line in enumerate(reference_lines) if line.startswith('SQ   '))
reference = ''.join(''.join(c for c in line if c.isalpha()) for line in reference_lines[sq + 1:] if line != '//')
assert len(reference) == 477 and reference[368] == 'V' and reference[390] == 'T'
differences = [{'position_1based': i + 1, 'reference': x, 'parent': y} for i, (x, y) in enumerate(zip(reference, parent)) if x != y]
assert differences == [{'position_1based': 369, 'reference': 'V', 'parent': 'A'}]
red_path = BASE / 'followup-reference2/galdieria-O98949.json'
red_entry = json.loads(red_path.read_text())
red = red_entry['sequence']['value']
entity_path = BASE / 'galdieria-1bwv-entities1.json'
entity = json.loads(entity_path.read_text())
assert len(red) == 493 and entity['entity_poly']['pdbx_seq_one_letter_code_can'] == red

# Reuse only the reviewed read-only parser definitions, avoiding the helper's
# original top-level source-inspection publication effects.
helper_path = BASE.parent / 'inspect_structure_correspondence.py'
tree = ast.parse(helper_path.read_text())
parser_tree = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in ('tokens', 'tables')], type_ignores=[])
exec(compile(parser_tree, str(helper_path), 'exec'), globals())
cif_path = BASE / 'galdieria-1bwv.cif'
loops, _ = tables(cif_path)
native_entity = next(row for row in loops['_entity_poly'] if row['_entity_poly.entity_id'] == '1')
assert ''.join(native_entity['_entity_poly.pdbx_seq_one_letter_code_can'].split()) == red
results = []
for sequence_role, sequence in [('P00876_reference_V369', reference), ('S8_biochemical_parent_A369', parent)]:
    for scoring in [(2, -1, -5, -1), (3, -2, -7, -1), (2, -1, -8, -1), (2, -1, -2, -2)]:
        result = align(sequence, red, *scoring)
        result['sequence_role'] = sequence_role
        results.append(result)
mapped = set()
for result in results:
    for values in result['all_optimal_site_mappings'].values():
        mapped.update(x for x in values if x is not None)
scheme = [row for row in loops['_pdbx_poly_seq_scheme'] if row['_pdbx_poly_seq_scheme.entity_id'] == '1' and int(row['_pdbx_poly_seq_scheme.seq_id']) in mapped]
atom_presence = []
for row in scheme:
    seq = row['_pdbx_poly_seq_scheme.seq_id']
    chain = row['_pdbx_poly_seq_scheme.asym_id']
    atoms = [r for r in loops['_atom_site'] if r['_atom_site.label_asym_id'] == chain and r['_atom_site.label_seq_id'] == seq]
    atom_presence.append({'label_asym_id': chain, 'seq_id': seq, 'atom_count': len(atoms), 'author_ids': sorted({r['_atom_site.auth_seq_id'] for r in atoms}), 'components': sorted({r['_atom_site.label_comp_id'] for r in atoms})})
output = {
    'schema': 'rubisco.exposed-tobacco-galdieria-correspondence.v1',
    'role': 'DERIVATIVE_READ_ONLY_CORRESPONDENCE_NOT_KINETIC_TRANSPORT',
    'inputs': [identity(p) for p in [s8_path, native_path, reference_path, red_path, entity_path, cif_path, helper_path, pathlib.Path(__file__)]],
    'source_workbook_identity': native['s8_identity'],
    'independent_original_cds_check': {'sheet': 'Sheet1', 'plasmid_name_cell': 'A2', 'dna_cell': 'B2', 'plasmid_bases': len(plasmid), 'lsu_plus_start_1based': 4021, 'lsu_plus_end_1based_including_stop': 5454, 'lsu_cds_sha256': digest(cds), 'translation_exactly_matches_parent': True, 'translation_terminal_stop': True},
    'proteins': {
        'P00876_reference': {'length': len(reference), 'sha256': digest(reference)},
        'S8_biochemical_parent': {'length': len(parent), 'sha256': digest(parent), 'differences_from_reference': differences},
        'Galdieria_O98949_1BWV_canonical': {'length': len(red), 'sha256': digest(red), 'uniprot_entry_audit': red_entry['entryAudit']},
    },
    'method': 'Global affine dynamic programming; exact integer scores; charged end gaps; inspect all optimal paths at native positions369/391. Four declared score variants for both exact tobacco sequence views.',
    'results': results,
    'native_1BWV_scheme_rows': scheme,
    'native_1BWV_atom_presence': atom_presence,
    'limits': [
        'Alignment uniqueness is conditional on the declared scoring methods, not a phylogenetic or structural homology proof.',
        'Deposited sequence/atom correspondence verifies residue identity and author numbering, not the tobacco kinetic assay parent or Galdieria assay preparation.',
        'Biochemical parent is S8 V369A; do not silently replace it with native V369 or the separate transit-peptide/His-tag plant fusion.',
        'No mutation effect, mechanism, red-algal transport, candidate nomination, two-target qualification or EL advantage is inferred.',
    ],
}
OUT.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'output': identity(OUT), 'proteins': output['proteins'], 'site_mappings': [{'role': r['sequence_role'], 'scoring': r['scoring'], 'sites': r['all_optimal_site_mappings']} for r in results], 'native_scheme_chainA': [r for r in scheme if r['_pdbx_poly_seq_scheme.asym_id'] == 'A']}))
