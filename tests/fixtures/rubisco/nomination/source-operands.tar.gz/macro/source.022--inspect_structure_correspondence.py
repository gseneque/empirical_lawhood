import hashlib, json, pathlib, shlex
root=pathlib.Path('/tmp/empirical-lawhood-rubisco-20261009/public-inputs')

def tokens(path):
 lines=path.read_text().splitlines(); out=[]; i=0
 while i<len(lines):
  line=lines[i]
  if line.startswith(';'):
   block=[line[1:]]; i+=1
   while i<len(lines) and not lines[i].startswith(';'): block.append(lines[i]); i+=1
   if i==len(lines): raise ValueError('unterminated CIF block')
   out.append('\n'.join(block))
  else: out.extend(shlex.split(line,comments=True,posix=True))
  i+=1
 return out

def tables(path):
 ts=tokens(path); i=0; loops={}; scalars={}
 while i<len(ts):
  t=ts[i]
  if t=='loop_':
   i+=1; headers=[]
   while i<len(ts) and ts[i].startswith('_'): headers.append(ts[i]); i+=1
   vals=[]
   while i<len(ts) and not (len(vals)%len(headers)==0 and (ts[i].startswith('_') or ts[i] in ('loop_','stop_') or ts[i].startswith('data_'))): vals.append(ts[i]); i+=1
   assert headers and len(vals)%len(headers)==0,(path.name,headers,len(vals))
   loops[headers[0].split('.')[0]]=[dict(zip(headers,vals[k:k+len(headers)])) for k in range(0,len(vals),len(headers))]
  elif t.startswith('_'):
   scalars[t]=ts[i+1]; i+=2
  else: i+=1
 return loops,scalars

out={'schema':'rubisco.exposed-structure-correspondence-inspection.v1','exposure':'public primary structures; static correspondence only; no molecular execution or kinetic support','structures':[]}
panel=json.loads((root/'wilson2017-exact-mutant-panel-inspection.json').read_text())
for name in ['galdieria-1bwv.cif','te-3zxw.cif']:
 path=root/name; loops,scalars=tables(path)
 entity_rows=loops.get('_entity_poly',[])
 entities=[]
 for r in entity_rows:
  can=''.join(r['_entity_poly.pdbx_seq_one_letter_code_can'].split())
  entities.append({'entity_id':r['_entity_poly.entity_id'],'canonical_sequence':can,'canonical_sequence_ascii_sha256':hashlib.sha256(can.encode()).hexdigest(),'native_chemical_sequence':r['_entity_poly.pdbx_seq_one_letter_code'],'chains':r['_entity_poly.pdbx_strand_id']})
 schemes=loops.get('_pdbx_poly_seq_scheme',[])
 requested=[]
 for r in schemes:
  if name=='galdieria-1bwv.cif' and ((r['_pdbx_poly_seq_scheme.asym_id']=='A' and r['_pdbx_poly_seq_scheme.seq_id'] in ['210','332','340','386','394']) or (r['_pdbx_poly_seq_scheme.entity_id']=='2' and r['_pdbx_poly_seq_scheme.seq_id'] in ['1','98'])): requested.append(r)
  if name=='te-3zxw.cif' and ((r['_pdbx_poly_seq_scheme.asym_id']=='A' and r['_pdbx_poly_seq_scheme.seq_id'] in ['201','415','451']) or (r['_pdbx_poly_seq_scheme.entity_id']=='2' and r['_pdbx_poly_seq_scheme.seq_id']=='98')): requested.append(r)
 assembly=loops.get('_pdbx_struct_assembly',[])
 relations={}
 if name=='te-3zxw.cif':
  relations={key:next(e['canonical_sequence'] for e in entities if e['entity_id']==eid)==panel['parent_construct'][key+'_sequence'] for key,eid in [('LSU','1'),('SSU','2')]}
  assert all(relations.values())
 atoms=loops.get('_atom_site',[])
 chemistry={}
 for atom in atoms:
  comp=atom['_atom_site.label_comp_id']; chemistry[comp]=chemistry.get(comp,0)+1
 out['structures'].append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'entities':entities,'assembly_native_rows':assembly,'requested_residue_correspondence':requested,'MG000148_canonical_sequence_equal':relations,'native_component_atom_counts':chemistry,'atom_rows':len(atoms)})
out['limits']=['1BWV author residue332 maps canonical sequence340=VAL; author386 maps sequence394=GLN; bare literature positions are not source-sequence indices.','3ZXW canonical LSU and SSU sequences equal MG000148.1 proteins; carbamylated lysine and bound inhibitors remain distinct chemical states.','Static inhibitor-bound coordinates and residue mapping do not supply reaction barriers, conformational populations, kcat or conventional specificity.','The historical Galdieria specificity238 source has not been bound to the exact1BWV preparation/strain.']
p=root/'rubisco-structure-correspondence-inspection.json'; p.write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'structures':[{'file':pathlib.Path(r['path']).name,'identity':r['MG000148_canonical_sequence_equal'],'components':r['native_component_atom_counts']} for r in out['structures']]}))
