"""Bounded correspondence inspection of acquired original sources only."""

import ast
import hashlib
import json
import pathlib
import re
import shlex
import sys

import numpy as np

from empirical_lawhood.adapters.physical.rubisco_kinetics import genbank as genbank_module
from empirical_lawhood.adapters.physical.rubisco_kinetics.genbank import _CODON_TABLE, decode_te_parent_genbank

BASE = pathlib.Path('/tmp/empirical-lawhood-rubisco-20261009/public-inputs')
OUT = BASE / 'followup-plant4/te-galdieria-ssu-correspondence-inspection.json'


def identity(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def digest(sequence):
    return hashlib.sha256(sequence.encode('ascii')).hexdigest()


def functions_only(path, names):
    tree = ast.parse(path.read_text())
    result = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name in names]
    assert {x.name for x in result} == set(names)
    return result


alignment_helper = pathlib.Path('/tmp/rubisco-tobacco-red-alignment-v1.py')
alignment_function = functions_only(alignment_helper, ('align',))[0]
rewritten = 0
for node in ast.walk(alignment_function):
    if isinstance(node, ast.Assign) and any(isinstance(x, ast.Name) and x.id == 'sites' for x in node.targets):
        assert isinstance(node.value, ast.Dict) and [x.value for x in node.value.keys] == [369, 391]
        node.value = ast.Dict(keys=[ast.Constant(98)], values=[ast.Call(func=ast.Name(id='set', ctx=ast.Load()), args=[], keywords=[])])
        rewritten += 1
assert rewritten == 1
exec(compile(ast.fix_missing_locations(ast.Module(body=[alignment_function], type_ignores=[])), str(alignment_helper), 'exec'), globals())
cif_helper = BASE.parent / 'inspect_structure_correspondence.py'
exec(compile(ast.Module(body=functions_only(cif_helper, ('tokens', 'tables')), type_ignores=[]), str(cif_helper), 'exec'), globals())

te_path = BASE / 'te-MG000148.gb'
te_bytes = te_path.read_bytes()
te_parent = decode_te_parent_genbank(te_bytes, expected_sha256=hashlib.sha256(te_bytes).hexdigest())
te = te_parent.coding_sequence('rbcS').protein_sequence
assert len(te) == 118 and te[97] == 'V'
te_cif_path = BASE / 'te-3zxw.cif'
te_loops, _ = tables(te_cif_path)
te_entity = next(r for r in te_loops['_entity_poly'] if r['_entity_poly.entity_id'] == '2')
assert ''.join(te_entity['_entity_poly.pdbx_seq_one_letter_code_can'].split()) == te
red_cif_path = BASE / 'galdieria-1bwv.cif'
red_loops, _ = tables(red_cif_path)
red_entity = next(r for r in red_loops['_entity_poly'] if r['_entity_poly.entity_id'] == '2')
red_pdb = ''.join(red_entity['_entity_poly.pdbx_seq_one_letter_code_can'].split())
red_protein_path = BASE / 'galdieria-O98950.json'
red_protein = json.loads(red_protein_path.read_text())
red_uniprot = red_protein['sequence']['value']
assert len(red_pdb) == len(red_uniprot) == 138
assert [(i+1, x, y) for i, (x, y) in enumerate(zip(red_pdb, red_uniprot)) if x != y] == [(1, 'V', 'M')]

ab_path = BASE / 'followup-reference2/galdieria-AB018008.1.txt'
ab_text = ab_path.read_text()
assert len(ab_text) < 100000 and ab_text.startswith('ID   AB018008; SV 1;')
ab_sequence = ''.join(re.findall('[acgt]+', ab_text.split('\nSQ   ', 1)[1].split('\n', 1)[1].split('//', 1)[0])).upper()
assert len(ab_sequence) == 1970
ab_features = ab_text.split('FT   CDS             1550..1966', 1)[1].split('\nXX', 1)[0]
assert '/gene="rbcS"' in ab_features and '/protein_id="BAA75797.1"' in ab_features and '/transl_table=11' in ab_features
qualifier = ab_features.split('/translation="', 1)[1].split('"', 1)[0]
ab_reported_protein = ''.join(re.findall('[A-Z]+', qualifier.replace('\nFT                   ', '')))
assert ab_reported_protein == red_uniprot
ab_ssu_cds = ab_sequence[1549:1966]
assert len(ab_ssu_cds) == 417 and ab_ssu_cds[:3] == 'GTG'
ab_literal = ''.join(_CODON_TABLE[ab_ssu_cds[i:i+3]] for i in range(0, len(ab_ssu_cds), 3))
assert ab_literal == red_pdb + '*'
note = ab_features.split('/note="', 1)[1].split('"', 1)[0].replace('\nFT                   ', ' ')
assert note == 'whether initiation codon GTG codes for Met or Val is unknown'

results = []
for role, sequence in [('1BWV_canonical_V1', red_pdb), ('O98950_AB018008_reported_M1', red_uniprot)]:
    for scoring in [(2, -1, -5, -1), (3, -2, -7, -1), (2, -1, -8, -1), (2, -1, -2, -2)]:
        result = align(te, sequence, *scoring)
        result['galdieria_sequence_role'] = role
        results.append(result)
red_positions = {98}
for result in results:
    red_positions.update(p for p in result['all_optimal_site_mappings']['98'] if p is not None)


def residue_evidence(loops, entity_id, positions):
    scheme = [row for row in loops['_pdbx_poly_seq_scheme'] if row['_pdbx_poly_seq_scheme.entity_id'] == entity_id and int(row['_pdbx_poly_seq_scheme.seq_id']) in positions]
    atoms = []
    for row in scheme:
        chain = row['_pdbx_poly_seq_scheme.asym_id']
        seq = row['_pdbx_poly_seq_scheme.seq_id']
        selected = [a for a in loops['_atom_site'] if a['_atom_site.label_asym_id'] == chain and a['_atom_site.label_seq_id'] == seq]
        atoms.append({'label_asym_id': chain, 'label_seq_id': seq, 'atom_count': len(selected), 'components': sorted({a['_atom_site.label_comp_id'] for a in selected}), 'author_positions': sorted({a['_atom_site.auth_seq_id'] for a in selected}), 'ca_atoms': [{k: a[k] for k in ('_atom_site.auth_asym_id', '_atom_site.auth_seq_id', '_atom_site.Cartn_x', '_atom_site.Cartn_y', '_atom_site.Cartn_z')} for a in selected if a['_atom_site.label_atom_id'] == 'CA']})
    return {'scheme_rows': scheme, 'atom_presence': atoms}


def ca_coordinates(loops, entity):
    chains = {r['_pdbx_poly_seq_scheme.asym_id'] for r in loops['_pdbx_poly_seq_scheme'] if r['_pdbx_poly_seq_scheme.entity_id'] == entity}
    out = {chain: {} for chain in chains}
    for atom in loops['_atom_site']:
        chain = atom['_atom_site.label_asym_id']
        if chain in chains and atom['_atom_site.label_atom_id'] == 'CA':
            position = int(atom['_atom_site.label_seq_id'])
            # No alternate CA conformations in these selected chains.
            assert position not in out[chain]
            out[chain][position] = np.array([float(atom[k]) for k in ('_atom_site.Cartn_x', '_atom_site.Cartn_y', '_atom_site.Cartn_z')])
    return out


def paired_columns(result):
    a, b = result['alignment']
    ai = bi = 0
    out = []
    for x, y in zip(a, b):
        ai += x != '-'
        bi += y != '-'
        if x != '-' and y != '-':
            out.append((ai, bi, x, y))
    return out


def rigid_fit(x, y):
    xc, yc = x.mean(axis=0), y.mean(axis=0)
    u, _, vh = np.linalg.svd((x - xc).T @ (y - yc))
    handedness = np.eye(3)
    handedness[-1, -1] = 1 if np.linalg.det(u @ vh) > 0 else -1
    rotation = u @ handedness @ vh
    translation = yc - xc @ rotation
    errors = np.linalg.norm(x @ rotation + translation - y, axis=1)
    return rotation, translation, errors


te_ca = ca_coordinates(te_loops, '2')
gal_ca = ca_coordinates(red_loops, '2')
structural = []
for result in results[:4]:
    all_pairs = paired_columns(result)
    # Hold out the complete queried segment. Only identical residues outside
    # Te90..106 seed the fit, so choosing93 versus95 cannot seed a preference.
    seed_pairs = [(a,b) for a,b,x,y in all_pairs if x == y and not 90 <= a <= 106]
    for te_chain in sorted(te_ca):
        for gal_chain in sorted(gal_ca):
            pairs = [(a,b) for a,b in seed_pairs if a in te_ca[te_chain] and b in gal_ca[gal_chain]]
            x = np.array([te_ca[te_chain][a] for a,b in pairs])
            y = np.array([gal_ca[gal_chain][b] for a,b in pairs])
            rotation, translation, errors = rigid_fit(x,y)
            variants = [('ALL_IDENTICAL_HOLDOUT_ANCHORS', pairs, rotation, translation, errors)]
            # Declared robustness diagnostic, not automatic homology admission.
            retained = list(range(len(pairs)))
            for _ in range(10):
                selected_x, selected_y = x[retained], y[retained]
                rot, shift, selected_errors = rigid_fit(selected_x, selected_y)
                new_retained = [retained[k] for k,e in enumerate(selected_errors) if e <= 4.0]
                if len(new_retained) < 8 or new_retained == retained:
                    break
                retained = new_retained
            if len(retained) >= 8:
                rot, shift, selected_errors = rigid_fit(x[retained], y[retained])
                variants.append(('ITERATIVE4A_TRIMMING_DIAGNOSTIC', [pairs[k] for k in retained], rot, shift, selected_errors))
            for method, used_pairs, rot, shift, used_errors in variants:
                query = te_ca[te_chain][98] @ rot + shift
                candidates = sorted((float(np.linalg.norm(query - coordinate)), position, red_pdb[position-1]) for position, coordinate in gal_ca[gal_chain].items())
                structural.append({'scoring': result['scoring'], 'method': method, 'Te_label_chain': te_chain, 'Galdieria_label_chain': gal_chain, 'holdout_Te_positions': [90,106], 'anchor_pairs': used_pairs, 'anchor_count': len(used_pairs), 'anchor_rmsd_A': float(np.sqrt(np.mean(used_errors**2))), 'anchor_max_error_A': float(used_errors.max()), 'all_anchors_within4A': bool((used_errors <= 4.0).all()), 'rotation_row_vectors': rot.tolist(), 'translation_A': shift.tolist(), 'query98_nearest_CA': [{'Galdieria_sequence_position': p, 'residue': aa, 'distance_A': distance} for distance,p,aa in candidates[:5]], 'query98_candidate_distances_A': [{'Galdieria_sequence_position': p, 'residue': red_pdb[p-1], 'distance_A': float(np.linalg.norm(query-gal_ca[gal_chain][p]))} for p in [93,94,95,96,98] if p in gal_ca[gal_chain]]})

groups = []
for scoring in [(2,-1,-5,-1),(3,-2,-7,-1),(2,-1,-8,-1),(2,-1,-2,-2)]:
    for method in ('ALL_IDENTICAL_HOLDOUT_ANCHORS', 'ITERATIVE4A_TRIMMING_DIAGNOSTIC'):
        group = [r for r in structural if tuple(r['scoring'][k] for k in ('match','mismatch','gap_open','gap_extend')) == scoring and r['method'] == method]
        assert len(group) == 16
        nearest_counts = {}
        for r in group:
            nearest = str(r['query98_nearest_CA'][0]['Galdieria_sequence_position'])
            nearest_counts[nearest] = nearest_counts.get(nearest,0) + 1
        groups.append({'scoring': dict(zip(('match','mismatch','gap_open','gap_extend'),scoring)), 'method': method, 'deposited_chain_pair_count': len(group), 'anchor_count_range': [min(r['anchor_count'] for r in group),max(r['anchor_count'] for r in group)], 'anchor_rmsd_range_A': [min(r['anchor_rmsd_A'] for r in group),max(r['anchor_rmsd_A'] for r in group)], 'nearest_site_counts': nearest_counts, 'distance_ranges_A': {str(p): [min(next(x['distance_A'] for x in r['query98_candidate_distances_A'] if x['Galdieria_sequence_position']==p) for r in group),max(next(x['distance_A'] for x in r['query98_candidate_distances_A'] if x['Galdieria_sequence_position']==p) for r in group)] for p in (93,94,95,96,98)}})
robust = [r for r in structural if r['method']=='ITERATIVE4A_TRIMMING_DIAGNOSTIC']
assert len(robust)==64 and all(r['all_anchors_within4A'] and r['query98_nearest_CA'][0]['Galdieria_sequence_position']==95 for r in robust)
gal_evidence = residue_evidence(red_loops, '2', red_positions)
mapped_rows = [r for r in gal_evidence['scheme_rows'] if r['_pdbx_poly_seq_scheme.seq_id']=='95']
assert len(mapped_rows)==4 and all(r['_pdbx_poly_seq_scheme.mon_id']=='ILE' and r['_pdbx_poly_seq_scheme.auth_seq_num']=='112' for r in mapped_rows)
assert red_pdb[94]==red_uniprot[94]=='I'


output = {
    'schema': 'rubisco.exposed-te-galdieria-ssu-correspondence.v1',
    'role': 'DERIVATIVE_SOURCE_CORRESPONDENCE_NOT_KINETIC_TRANSPORT',
    'inputs': [identity(p) for p in [te_path, te_cif_path, red_cif_path, red_protein_path, ab_path, alignment_helper, cif_helper, pathlib.Path(genbank_module.__file__), pathlib.Path(__file__)]],
    'proteins': {
        'Te_MG000148_3ZXW_exact': {'length': len(te), 'sha256': digest(te), 'native_accession': 'ATN39933.1', 'sequence': te, 'site98': te[97]},
        'Galdieria_1BWV': {'length': len(red_pdb), 'sha256': digest(red_pdb), 'sequence': red_pdb},
        'Galdieria_O98950_AB018008_reported': {'length': len(red_uniprot), 'sha256': digest(red_uniprot), 'sequence': red_uniprot, 'uniprot_audit': red_protein['entryAudit']},
    },
    'AB018008_independent_cds_check': {'native_location': '1550..1966', 'native_protein_accession': 'BAA75797.1', 'cds_sha256': digest(ab_ssu_cds), 'initial_codon': 'GTG', 'native_note': note, 'reported_translation_equals_O98950': True, 'literal_noninitiation_codon_translation_equals_1BWV_plus_terminal_stop': True, 'processing_role': 'SEPARATE_NATIVE_SEQUENCE_VIEWS_NO_MATURE_PROCESSING_INFERENCE'},
    'method': 'Reuse reviewed global affine DP function with requested site dictionary changed only to98; exact integer scores, end gaps charged, all optimal paths inspected. Four declared scoring variants for both Galdieria initiation views. Source/deposited numbering and atom presence checked independently. Kabsch CA superposition uses identical sequence anchors outside queried Te90..106 segment, all16 deposited chain pairs, four scoring seeds, and all-anchor versus declared4A-trimming diagnostics.',
    'structural_fit_rule': {'role': 'POST_HOC_STATIC_CORRESPONDENCE_DIAGNOSTIC_NOT_PROSPECTIVE_KINETIC_ASSESSMENT', 'seed': 'Only identical paired sequence residues outside Te90..106; query98 and its entire local segment excluded from fitting.', 'rigid_fit': 'Least-squares CA Kabsch proper rotation, no reflection, Angstrom coordinates.', 'all_anchor_rule': 'Retain and report every untrimmed fit; no fit silently excluded.', 'trimming_rule': 'Repeatedly fit current seed anchors and remove anchors farther than4.0A from their paired position, at most10iterations, retaining at least8anchors; report exact retained pairs, full transform, RMSD, maximum error and threshold satisfaction.', 'site_diagnostic': 'Compare transformed TeV98 CA to every deposited Galdieria SSU CA; record five nearest and explicit93/94/95/96/98 distances.', 'independence_limit': 'Four chains and repeated scoring fits are correlated views of two deposited structures, not independent biological observations.', 'numerical_profile': {'numpy': np.__version__, 'python': sys.version, 'executable': sys.executable}},
    'alignment_results': results,
    'Te_native_residue_evidence': residue_evidence(te_loops, '2', {98}),
    'Galdieria_native_residue_evidence': gal_evidence,
    'structural_holdout_diagnostics': structural,
    'structural_complete_group_summary': groups,
    'correspondence_conclusion': {'sequence_alone': 'AMBIGUOUS: three affine choices permit93SERor95ILE; the linear-gap choice additionally permits94THR,96ILEor a gap. Same outcomes for both initiation views.', 'structural_support': 'Three untrimmed scoring seeds have near0.9A backbone RMSD and nearest95ILE for every chain pair. The3/-2/-7/-1seed has poor near6.8A untrimmed RMSD and nearest94THR, retained openly. Declared4A trimming produces nearest95ILE in all64chain/seed fits with near0.9A RMSD.', 'mapped_native_site': {'Galdieria_sequence_position_1based':95,'native_residue':'I','1BWV_author_position':112,'1BWV_author_chains':['S','U','W','Y'],'Te_sequence_position_1based':98,'Te_native_residue':'V'}, 'met_substitution_hypothesis_recipe': 'I95M in exact Galdieria O98950/AB018008 SSU sequence coordinates; equivalently I112M in 1BWV SSU author coordinates. This is a structurally supported site hypothesis, not a nominated candidate or forecast.', 'rejected_literal_numbering': 'F98M is not supported as the TeV98M homologous-site transfer; literal Galdieria98PHE is approximately10.5A away after well-fitting superposition.', 'phenotype_transport':'UNKNOWN; neither Te measured percentage gain nor high-specificity preservation transfers through residue correspondence.'},
    'limits': [
        'Same literal site number does not establish homologous-site correspondence.',
        'Sequence alignment uniqueness is conditional on declared scoring; structural equivalence and phenotype transport are separate claims.',
        'AB018008 native initiation uncertainty remains explicit; neither Met/Val view establishes mature processing or assay-preparation identity.',
        'No mutation response, nomination, calibrated biological support or EL advantage is inferred.',
    ],
}
OUT.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'output': identity(OUT), 'proteins': {key: {k: v for k, v in value.items() if k != 'sequence'} for key,value in output['proteins'].items()}, 'mappings': [{'role':r['galdieria_sequence_role'], 'scoring':r['scoring'], 'sites':r['all_optimal_site_mappings']} for r in results]}))
