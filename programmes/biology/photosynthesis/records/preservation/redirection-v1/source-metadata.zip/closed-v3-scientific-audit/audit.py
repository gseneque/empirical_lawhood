"""Native-free retained-byte checker; no EL authority or new scientific execution."""
from __future__ import annotations

from decimal import Decimal, localcontext
from pathlib import Path
import gzip
import hashlib
import itertools
import json
import math
import re
import resource
import time
import zipfile

ROOT = Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution/rr-qmmm-retained-reference-v3')
OUT = Path('/tmp/rubisco-qmmm-retained-reference-scientific-audit-v3')
CONFIG = Path('/tmp/rubisco-qmmm-reference-from-retained-v3/execution-config-v3.json')
CONFIG_SHA = 'a1633431db55b3e466c2618f9bf32c2e47141e60912e99cf8cb6f8b00589d93c'
CENSUS_SHA = '92c6c63cc5dad115cdf2e8e34cd129e82bc6cad2fd4ab006370201a3c5efaaa3'
FORCE_PINS = {'before-ash-masks': ('4619f7f0b3ace3a73afab99113c0f2e665d364c01d836dddd3b98c313b4d1ccd', 8892038), 'after-ash-masks': ('eaeaddf26565f613e73ee050aeb8a95acbab3767f6616d35dfcc25b1c34257d6', 8968492)}
BINDINGS: dict[str, dict] = {}


def checked(path, sha=None, size=None):
    path = Path(path)
    assert not path.is_symlink() and path.is_file(), str(path)
    raw = path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert sha is None or digest == sha, str(path) + ': digest'
    assert size is None or len(raw) == size, str(path) + ': size'
    BINDINGS[str(path)] = {'bytes': len(raw), 'sha256': digest}
    return raw


def binding(row):
    return checked(row['path'], row['sha256'], row['bytes'])


def joined(path):
    path = Path(path)
    j = json.loads(checked(path))
    raw = b''.join(checked(path.parent / row['name'], row['sha256'], row['bytes']) for row in j['ordered_chunks'])
    assert len(raw) == j['whole_bytes'] and hashlib.sha256(raw).hexdigest() == j['whole_sha256']
    return json.loads(raw), j


def scaled(a, b):
    a, b = Decimal(str(a)), Decimal(str(b))
    return abs(a-b) / max(Decimal(1), abs(a), abs(b))


def parse_prmtop(raw):
    result = {}
    key = None
    width = None
    for line in raw.decode('ascii').splitlines():
        if line.startswith('%FLAG '):
            key = line[6:].strip()
            result[key] = []
            width = None
        elif line.startswith('%FORMAT'):
            width = int(re.search(r'\(\d+[a-zA-Z](\d+)', line).group(1))
        elif line.startswith('%') or key is None:
            continue
        else:
            for start in range(0, len(line), width):
                token = line[start:start+width].strip()
                if token:
                    result[key].append(token)
    return result


def main():
    started_wall = time.monotonic()
    started_cpu = time.process_time()
    census = json.loads(checked(ROOT/'closed-census.json', CENSUS_SHA))
    members = census['members_excluding_self']
    names = [row['name'] for row in members]
    assert len(names) == len(set(names))
    for row in members:
        path = ROOT / row['name']
        assert path.resolve().is_relative_to(ROOT.resolve())
        checked(path, row['sha256'], row['bytes'])
        assert path.stat().st_mode & 0o777 == 0o444, str(path) + ': mode'
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()}
    assert actual == set(names) | {'closed-census.json'}, 'complete raw physical denominator'
    assert all(not p.is_symlink() for p in ROOT.rglob('*'))
    cfg = json.loads(checked(CONFIG, CONFIG_SHA, 629798))
    plan = json.loads(binding(cfg['reference_plan_join']))
    plan, plan_join = joined(cfg['reference_plan_join']['path'])
    qm = set(plan['real_qm_full_indices_0based'])
    assert len(qm) == 76 and len(plan['active_full_indices_0based']) == 50
    before, before_join = joined(ROOT/'reference-work/native-force-observations/before-ash-masks.join.json')
    after, after_join = joined(ROOT/'reference-work/native-force-observations/after-ash-masks.join.json')
    for stage, j in [('before-ash-masks', before_join), ('after-ash-masks', after_join)]:
        assert (j['whole_sha256'], j['whole_bytes']) == FORCE_PINS[stage]
    sections = parse_prmtop(binding(cfg['derived_prmtop']))
    ints = lambda name: list(map(int, sections[name]))
    floats = lambda name: [float(t.replace('D', 'E')) for t in sections[name]]
    group = lambda values, count: [values[i:i+count] for i in range(0, len(values), count)]
    source_checks = {}
    def coefficient_check(name, nindices, expected):
        rows = before[name]
        assert len(rows) == len(expected)
        errors = []
        scaled_errors = []
        for idx, (want, got) in enumerate(zip(expected, rows)):
            assert want[:nindices] == got[:nindices], (name, idx, 'index/order')
            for x, y in zip(want[nindices:], got[nindices:]):
                assert math.isclose(x, y, rel_tol=1e-13, abs_tol=1e-13), (name, idx, 'native conversion')
                errors.append(abs(x-y))
                scaled_errors.append(abs(x-y)/max(1, abs(x)))
        source_checks[name] = {'count': len(rows), 'max_abs_conversion_roundoff': max(errors, default=0), 'max_scaled_conversion_roundoff': max(scaled_errors, default=0)}
    k, e = floats('BOND_FORCE_CONSTANT'), floats('BOND_EQUIL_VALUE')
    coefficient_check('bonds', 2, [[i//3,j//3,e[p-1]*.1,2*(k[p-1]*418.4)] for i,j,p in group(ints('BONDS_INC_HYDROGEN')+ints('BONDS_WITHOUT_HYDROGEN'),3)])
    k, e = floats('ANGLE_FORCE_CONSTANT'), floats('ANGLE_EQUIL_VALUE')
    coefficient_check('angles', 3, [[i//3,j//3,m//3,e[p-1],2*(k[p-1]*4.184)] for i,j,m,p in group(ints('ANGLES_INC_HYDROGEN')+ints('ANGLES_WITHOUT_HYDROGEN'),4)])
    k, phase, periodicity = floats('DIHEDRAL_FORCE_CONSTANT'), floats('DIHEDRAL_PHASE'), floats('DIHEDRAL_PERIODICITY')
    coefficient_check('torsions', 5, [[i//3,j//3,abs(m)//3,abs(n)//3,int(.5+periodicity[p-1]),phase[p-1],k[p-1]*4.184] for i,j,m,n,p in group(ints('DIHEDRALS_INC_HYDROGEN')+ints('DIHEDRALS_WITHOUT_HYDROGEN'),5)])
    masks = {}
    for name, nindices, minimum in [('bonds',2,2),('angles',3,2),('torsions',4,3)]:
        changed = 0
        for want, got in zip(before[name], after[name]):
            expected = want[:]
            if sum(i in qm for i in want[:nindices]) >= minimum:
                expected[-1] = 0.0
                changed += 1
            assert got == expected, (name, 'mask')
        masks[name] = changed
    original_exceptions = {tuple(sorted(row[:2])): row for row in before['exceptions']}
    final_exceptions = {tuple(sorted(row[:2])): row for row in after['exceptions']}
    qq = {(i,j) for i in qm for j in qm if i<j}
    assert len(original_exceptions) == 75274 and len(final_exceptions) == 77827
    assert set(final_exceptions) == set(original_exceptions) | qq
    for pair, row in final_exceptions.items():
        assert row[3:] == ([0.0,0.0] if pair in qq else original_exceptions[pair][3:])
    assert before['force_roster'] == after['force_roster']
    for key in before['custom_lj']:
        if key not in {'exclusions','counts'}:
            assert before['custom_lj'][key] == after['custom_lj'][key], key
    source = json.loads(binding(cfg['retained_reload_witness']))
    nt = source['native_named_NTYPES']
    types = source['retained_native_ATOM_TYPE_INDEX']
    lookup, a, b = [source['native_lj_tables'][name] for name in ['NONBONDED_PARM_INDEX','LENNARD_JONES_ACOEF','LENNARD_JONES_BCOEF']]
    assert nt == 25 and source['native_POINTERS'][:2] == [13828,25] and len(types) == 13828 and len(lookup) == 625 and len(a) == len(b) == 325
    assert types == ints('ATOM_TYPE_INDEX') and lookup == ints('NONBONDED_PARM_INDEX') and a == floats('LENNARD_JONES_ACOEF') and b == floats('LENNARD_JONES_BCOEF')
    av, bv = [0.0]*625, [0.0]*625
    for i in range(nt):
        for j in range(nt):
            k = lookup[nt*i+j]-1
            av[i+nt*j] = math.sqrt(a[k])*(math.sqrt(4.184)*.1**6)
            bv[i+nt*j] = b[k]*(4.184*.1**6)
    cf = after['custom_lj']
    assert cf['tabulated_functions'] == [['acoef','Discrete2DFunction',25,25,av],['bcoef','Discrete2DFunction',25,25,bv]]
    assert cf['particles'] == [[float(t-1)] for t in types]
    selected_charges = [float(Decimal(n)/Decimal(d)) for n,d in plan['classical_charge_fractions']]
    assert before['particles'] == after['particles'] == [[v,1.0,0.0] for v in selected_charges]
    source_14 = {}
    scee, scnb = floats('SCEE_SCALE_FACTOR'), floats('SCNB_SCALE_FACTOR')
    for i,j,k,l,p in group(ints('DIHEDRALS_INC_HYDROGEN')+ints('DIHEDRALS_WITHOUT_HYDROGEN'),5):
        if k>0 and l>0:
            pair = tuple(sorted((i//3,l//3)))
            source_14[pair] = (scee[p-1], scnb[p-1])
    for pair, row in final_exceptions.items():
        expected = 0.0 if any(i in qm for i in pair) or pair not in source_14 else selected_charges[pair[0]]*selected_charges[pair[1]]/source_14[pair][0]
        assert row[2] == expected, ('Coulomb/SCEE',pair)
    cp = ROOT/'reference-work/source-table-control'
    control = json.loads(checked(cp/'source-table-control-report.json'))
    live = json.loads(binding(control['actual_live_force_witness']))
    setup = json.loads(binding(control['control_setup']))
    control_source = json.loads(binding(control['source_witness']))
    assert control_source == source
    assert live['particles'] == cf['particles'] and live['exclusions'] == cf['exclusions']
    assert live['tabulated_functions'][0]['values'] == av and live['tabulated_functions'][1]['values'] == bv
    assert setup['tables'] == live['tabulated_functions'] and setup['custom_expression'] == cf['energy_expression'] and setup['charges_e'] == [0,0] and setup['exclusions'] == []
    eligible = [(i,j,lookup[nt*(i-1)+j-1]-1) for i in sorted(set(types)) for j in sorted(set(types)) if i<j and a[lookup[nt*(i-1)+j-1]-1]>0 and b[lookup[nt*(i-1)+j-1]-1]>0]
    i,j,k = eligible[0]
    assert control['selected_pair']['source_types_1based'] == [i,j] and control['selected_pair']['source_coefficient_index_1based'] == k+1
    c4rows = []
    with localcontext() as ctx:
        ctx.prec = 80
        aa = Decimal(str(a[k]))*Decimal('4.184')*Decimal('.1')**12
        bb = Decimal(str(b[k]))*Decimal('4.184')*Decimal('.1')**6
        errors = []
        rawrows = []
        for label,r in [('baseline',Decimal('.4')),('minus',Decimal('.399999')),('plus',Decimal('.400001'))]:
            row = json.loads(checked(cp/(label+'-raw-native-energy-forces.json')))
            tokens = json.loads(binding(next(v for v in control['raw_native_token_members'] if label+'-' in v['path'])))
            assert row['status'] == 'RETURNED' and row['coordinates_nm'] == [[0,0,0],[float(r),0,0]]
            assert Decimal(tokens['energy_kj_per_mol_token']) == Decimal(str(row['energy_kj_per_mol']))
            assert [[Decimal(t) for t in v] for v in tokens['forces_kj_per_mol_nm_tokens']] == [[Decimal(str(t)) for t in v] for v in row['forces_kj_per_mol_nm']]
            energy = aa/r**12-bb/r**6
            deriv = -12*aa/r**13+6*bb/r**7
            want = [[deriv,Decimal(0),Decimal(0)],[-deriv,Decimal(0),Decimal(0)]]
            errs = [scaled(row['energy_kj_per_mol'],energy)]+[scaled(x,y) for v,w in zip(row['forces_kj_per_mol_nm'],want) for x,y in zip(v,w)]
            errors.extend(errs)
            rawrows.append(row)
            c4rows.append({'label':label,'energy_kj_per_mol':row['energy_kj_per_mol'],'forces_kj_per_mol_nm':row['forces_kj_per_mol_nm'],'maximum_scaled_error':str(max(errs))})
        fd = (Decimal(str(rawrows[2]['energy_kj_per_mol']))-Decimal(str(rawrows[1]['energy_kj_per_mol'])))/(2*Decimal('.000001'))
        fd_error = scaled(fd,-rawrows[0]['forces_kj_per_mol_nm'][1][0])
        assert max(errors) <= Decimal('1e-10') and fd_error <= Decimal('1e-8')
        assert abs(max(errors)-Decimal(control['maximum_analytic_scaled_error'])) < Decimal('1e-42')
        assert fd_error == Decimal(control['finite_difference']['scaled_error'])
        c4max = str(max(errors))
    call = ROOT/'reference-work/cases/reference-v2/calls/call-0001'
    lines = checked(call/'gradient').decode().splitlines()
    m = re.fullmatch(r'\s*cycle\s*=\s*(\d+)\s+SCF energy\s*=\s*([-+.\dEe]+)\s+\|dE/dxyz\|\s*=\s*([-+.\dEe]+)\s*',lines[1])
    assert lines[0] == '$grad' and lines[-1] == '$end' and m and len(lines[2:-1]) == 162
    gradient = [[float(t.replace('D','E')) for t in row.split()] for row in lines[83:-1]]
    pcgrad = [[float(t.replace('D','E')) for t in row.split()] for row in checked(call/'pcgrad').decode().splitlines()]
    assert len(gradient) == 81 and len(pcgrad) == 13747
    assert all(len(row) == 3 and all(math.isfinite(v) and abs(v)<1e8 for v in row) for row in gradient+pcgrad)
    stderr = checked(call/'stderr.txt').decode()
    stdout = checked(call/'stdout.txt').decode()
    assert stderr == 'normal termination of xtb\n' and 'convergence criteria satisfied after 67 iterations' in stdout
    process = json.loads(checked(call/'process-observation.json'))
    assert process['native_started'] and process['returncode'] == 0 and process['operational_refusal'] is None
    archives = {}
    for name in ['call-0001.plan.zip','call-0001.capture.zip']:
        path = ROOT/'reference-work/cases/reference-v2/bridge'/name
        checked(path)
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            archives[name] = {'members':len(archive.namelist()),'CRC_verified':True}
    inp = json.loads(gzip.decompress(checked(ROOT/'reference-work/reference-observations/evaluation-001-input.json.gz')))
    coords = inp['coordinates_angstrom']
    ids = inp['physical_atom_ids']
    assert ids == [row[0] for row in plan['physical_atoms']] and len(coords) == 13828
    assert coords == [[float(v) for v in row[2]] for row in plan['physical_atoms']]
    excluded = {tuple(sorted(p)) for p in cf['exclusions']}
    grid = {}
    short = []
    checks = 0
    for i, xyz in enumerate(coords):
        key = tuple(math.floor(v/.75) for v in xyz)
        for delta in itertools.product((-1,0,1),repeat=3):
            for other in grid.get(tuple(k+d for k,d in zip(key,delta)),()):
                if (other,i) in excluded:
                    continue
                distance = math.dist(xyz,coords[other])
                checks += 1
                if distance < .75:
                    index = types[other]-1+25*(types[i]-1)
                    if av[index] or bv[index]:
                        nm = distance*.1
                        scalar = (av[index]/nm**6)**2-bv[index]/nm**6
                        short.append({'physical_ids':[ids[other],ids[i]],'native_indices_0based':[other,i],'source_types_1based':[types[other],types[i]],'source_rows':[plan['physical_atoms'][other],plan['physical_atoms'][i]],'distance_angstrom':distance,'nonexcluded':True,'both_fixed_MM':other in plan['fixed_mm_full_indices_0based'] and i in plan['fixed_mm_full_indices_0based'],'source_custom_LJ_kj_per_mol':scalar,'approx_Eh_using_2625_499638_kj_per_mol_per_Eh':scalar/2625.499638})
        grid.setdefault(key,[]).append(i)
    short.sort(key=lambda row:row['distance_angstrom'])
    assert len(short) == 3 and all(row['both_fixed_MM'] for row in short)
    worker = json.loads(checked(ROOT/'reference-work/worker-report.json'))
    ref = json.loads(checked(ROOT/'reference-work/reference-observations/reference-report.json'))
    refusal = json.loads(checked(ROOT/'reference-work/reference-observations/evaluation-001-refusal.json'))
    journal = [json.loads(line) for line in checked(ROOT/'reference-work/native-effect-journal.jsonl').decode().splitlines()]
    summary = json.loads(checked(ROOT/'measured-summary.json'))
    assert all(worker['native_effect_counters'][k] == 1 for k in ['MM_run_attempts','MM_run_returns','classical_create_simulation_attempts','classical_create_simulation_returns','coupled_run_attempts','coupled_run_returns'])
    assert ref['coupled_evaluation_entries'] == 1 and ref['full_physical_evaluation_returns'] == 0 and ref['fresh_full_coupled_gradient'] == 'UNENTERED' and ref['optimizer'] == 'REFUSED'
    assert not list((ROOT/'reference-work/reference-observations').glob('*-result.json*'))
    output = {'role':'READ_ONLY_NATIVE_FREE_RETAINED_SOURCE_AND_NUMERICAL_AUDIT_NOT_NEW_SCIENCE_OR_AUTHORITY','status':'PASS_FOR_EXPLICIT_AUDIT_CHECKS_WITH_REFERENCE_REPAIR_REFUSAL_PRESERVED',
      'root':str(ROOT),'root_census_sha256':CENSUS_SHA,'raw_physical_files_including_census':len(actual),'raw_physical_bytes':sum((ROOT/name).stat().st_size for name in actual),'actual_plane_manifest_verification':'Separate parent/peer custody audit; this script verifies physical bytes only, not authority',
      'force_source_and_masks':{'before_whole_sha256':before_join['whole_sha256'],'after_whole_sha256':after_join['whole_sha256'],'full_physical_particles':13828,'source_NTYPES':25,'lookup_entries':625,'source_AB_entries_each':325,'native_table_entries_each':625,'bonded_source':source_checks,'exact_bonded_masks':masks,'original_exception_pairs':len(original_exceptions),'final_exception_pairs':len(final_exceptions),'all_QM_pairs':len(qq),'new_QM_exclusions':len(qq-set(original_exceptions)),'existing_QM_source_pairs':len(qq & set(original_exceptions)),'cross_LJ_preserved':True,'source_selected_Coulomb_SCEE_exact':True},
      'C4':{'status':'PASS','pair':control['selected_pair'],'roster':c4rows,'maximum_analytic_scaled_error':c4max,'finite_difference_scaled_error':str(fd_error),'native_counters':control['native_counters'],'scope':'One selected two-particle occupied source-table pair conformance; not enzyme-gradient qualification'},
      'xTB_primitive':{'normal_termination':True,'SCC_iterations':67,'energy_Eh':m[2],'quantum_gradient_rows':81,'quantum_gradient_maxabs':max(abs(v) for row in gradient for v in row),'quantum_gradient_l2':math.sqrt(math.fsum(v*v for row in gradient for v in row)),'pointcharge_gradient_rows':len(pcgrad),'pointcharge_gradient_maxabs':max(abs(v) for row in pcgrad for v in row),'pointcharge_gradient_l2':math.sqrt(math.fsum(v*v for row in pcgrad for v in row)),'all_raw_components_finite_below_assessor_bound':True,'waited_native_CPU_seconds':process['waited_native_cpu_seconds'],'raw_archives':archives},
      'reference':{'status':ref['status'],'optimizer':ref['optimizer'],'fresh_gradient':ref['fresh_full_coupled_gradient'],'coupled_evaluation_entries':ref['coupled_evaluation_entries'],'accepted_full_physical_evaluation_returns':ref['full_physical_evaluation_returns'],'actual_method_attempts_and_returns':worker['native_effect_counters'],'new_native_processes':worker['native_processes_started'],'new_callback_reservations':worker['attempted_callback_reservations'],'refusal':refusal['refusal'],'uncaptured_operands':'Raw full MM/coupled energy and full 13,828-row gradient are not retained before assessor guards. Generic guard rejects NaN/Inf OR abs(value)>1e8; energy is checked first, then gradients. Cannot identify which rejected operand from these bytes. No repaired geometry, stationarity, fresh gradient, species, barrier, kinetics or EL superiority conclusion.'},
      'starting_contact_diagnostic':{'role':'Source-table scalar arithmetic at retained initial coordinates; not actual uncaptured native total energy or new force execution','selection':'Complete fixed-size grid search for nonexcluded source-positive-LJ pairs with r<0.75 Angstrom; not a relaxed geometry','coordinate_denominator':13828,'nonexcluded_grid_candidate_distance_checks':checks,'complete_selected_pair_denominator':3,'pairs':short,'interpretation':'Two fixed-MM starting scalar contributions individually exceed assessor bound by large margins, making huge finite returned values plausible. These are source-provenance/environment contacts, not optimization drift or transferred active-site protons; actual total/rejected operand remains unknown.'},
      'resources':{'complete_waited_worker_CPU_seconds':summary['process']['complete_waited_worker_cpu_seconds'],'operational_refusal':summary['operational_refusal'],'source_closure_refusal':worker['final_source_closure_refusal'],'native_free_checker_body_CPU_seconds':time.process_time()-started_cpu,'native_free_checker_body_wall_seconds':time.monotonic()-started_wall,'checker_body_scope':'Before observation serialization; excludes process startup, writing/chmod/closure and tail. Separate outer time file measures invocation.'},
      'software_checker_effects':{'native_library_imports':0,'source_owner_admissions':0,'chemical_context_constructors':0,'native_Context':0,'force_objectives':0,'xTB_or_native_processes':0},'bindings':BINDINGS,'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    target = OUT/'observation.json'
    with target.open('xb') as stream:
        stream.write((json.dumps(output,sort_keys=True,indent=2,allow_nan=False)+'\n').encode())
    print(json.dumps({'status':output['status'],'C4':output['C4']['maximum_analytic_scaled_error'],'FD':str(fd_error),'starting_contacts':len(short),'native_returned_but_assessor_accepted':0,'checker_body_CPU':output['resources']['native_free_checker_body_CPU_seconds']}))


if __name__ == '__main__':
    main()
