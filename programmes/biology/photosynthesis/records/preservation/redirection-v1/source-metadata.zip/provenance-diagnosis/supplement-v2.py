"""Native-free exact deposited joins, archived alternate preparation, grid oracle."""
import ast
import base64
from collections import defaultdict
from decimal import Decimal
from hashlib import sha256
import importlib.abc
import io
from itertools import product
import json
import math
from pathlib import Path
import resource
import sys
import time
import zipfile
import struct
import re

class NoNative(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'numpy','scipy','parmed','openmm','simtk','ash','geometric','pyscf','Bio'}:
            raise ImportError('native science forbidden')
        return None
sys.meta_path.insert(0,NoNative())
ROOT=Path(__file__).parent
start=time.monotonic(); resource.setrlimit(resource.RLIMIT_CPU,(60,60));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,)*2)
bindings=[]
def need(v,m):
    if not v: raise ValueError(m)
def read(p, expected=None, bound=64*1024**2):
    p=Path(p); need(p.is_file() and not p.is_symlink() and p.stat().st_size<=bound,'bounded original bytes')
    b=p.read_bytes(); h=sha256(b).hexdigest()
    if expected:need(h==expected,'source digest '+str(p))
    bindings.append({'path':str(p),'bytes':len(b),'sha256':h});return b
# Reuse only pure byte grammar/arithmetic function definitions, no module body.
source=read(ROOT/'diagnose-v2.py'); tree=ast.parse(source)
names={'flags','exclusions','inpcrd','npy','contacts'}
subset=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names],type_ignores=[])
exec(compile(subset,'exact-selected-pure-parser-functions','exec'),globals())
core_root=Path('/tmp/empirical-lawhood-rubisco-20261009/public-inputs/followup-rr-amber-core-v1')
core=json.loads(read(core_root/'dry-core-source-projection-v1a.json','bfbaa57a1b9d466e311c23c37616cd54771ac170d7fc361ef7769a4004040c5f'))
native=json.loads(read(core_root/'9RUB-native-atom-mapping-original.json','caa36c34be4eb61cc6b804e6130f4e0845b27f95fa74117db02229ac5d787985'))
native_rows=[dict(zip(native['CIF_atom_site_columns_in_source_order_then_PDB_witnesses'],row,strict=True)) for row in native['rows']]
rows={r['id']:r for r in native_rows}
translation=tuple(map(Decimal,core['inherited_coordinate_translation_angstrom'])); count=0;chaincounts=defaultdict(int)
for atom in core['atoms']:
    if atom[13]!='positive-occupancy native 9RUB heavy atom; exact translation':continue
    witness=atom[14]; need(type(witness)is list and len(witness)==4,'full source witness identity')
    r=rows[witness[0]]
    need(witness[1:]==[r['auth_asym_id'],r['auth_seq_id'],r['auth_atom_id']],'author chain residue atom witness')
    need(atom[3]==r['type_symbol'] and Decimal(r['occupancy'])>0,'native element positive occupancy')
    need(tuple(Decimal(atom[10+i]) for i in range(3))==tuple(Decimal(r[k])+translation[i] for i,k in enumerate(['Cartn_x','Cartn_y','Cartn_z'])),'all inherited native coordinates exact declared translation')
    count+=1;chaincounts[witness[1]]+=1
need(count==7028,'complete declared7028 actual independently checked')
# Independent exhaustive finite synthetic grid oracle, including negative cells,
# threshold equality, zero distance, exclusions and zero-A contact census.
synthetic=[(-1.51,0,0),(-.76,0,0),(-.75,0,0),(-.001,.1,.1),(0,0,0),(.1,.1,.1),(.74,0,0),(.75,0,0),(.751,0,0),(0,0,0)]
excluded={(3,4),(4,9)}
expected=sorted([a,b] for b in range(len(synthetic)) for a in range(b) if (a,b) not in excluded and sum((x-y)**2 for x,y in zip(synthetic[a],synthetic[b]))<.75**2)
actual=contacts(synthetic,excluded)
need([r['indices_0based'] for r in actual['pairs']]==expected,'independent exhaustive grid oracle')
zero=contacts([(0,0,0),(.2,0,0)],(),[1,1],[1]*625,[0.0]*325,[0.0]*325)
need(zero['near_contact_denominator']==zero['near_contacts_with_zero_source_A']==1,'zeroA contacts not hidden')
# Archived HIE91 is exposed alternate parent source, not a new selection/cure.
envelope=Path('/media/chevre/SEMIOS/icf-yolo/programmes/rubisco-el/r02s-m1-pilot-v5/runs/rubisco-r02s-m1-native-v5.pilot.production/outputs/rubisco-r02s-m1-native-v5.native-protocol/native-result.canonical.json')
e=json.loads(read(envelope,'8dbc9e528e341cee554128bcedc9876f2f3141c2e4b62a22b737f9b5bcef855a'))
a=base64.b64decode(e['value']['prepared_archive_base64'],validate=True);need(sha256(a).hexdigest()=='a22c4fb687e88ff36d92d06378f3b3176b565fd1281b83cccad52454b0f1a653','archive hash')
z=zipfile.ZipFile(io.BytesIO(a)); census=json.loads(read(ROOT/'authenticated-parent-archive-census-v2.json')); membermap={r['name']:r for r in census['members']}
def member(name):
    b=z.read(name);r=membermap[name];need(len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256'],'archived member source identity');bindings.append(r|{'archive_member':True});return b
wanted={'POINTERS','ATOM_NAME','RESIDUE_LABEL','RESIDUE_POINTER','ATOM_TYPE_INDEX','NUMBER_EXCLUDED_ATOMS','EXCLUDED_ATOMS_LIST','NONBONDED_PARM_INDEX','LENNARD_JONES_ACOEF','LENNARD_JONES_BCOEF','BONDS_INC_HYDROGEN','BONDS_WITHOUT_HYDROGEN'}
f=flags(member('WT-HIE91/prepared.prmtop'),wanted);n=int(f['POINTERS'][0]);need(n==116767,'full alternate original')
xyz,_=inpcrd(member('WT-HIE91/prepared.inpcrd'));relaxed,_=npy(member('WT-HIE91/relaxed.npy'),n)
types=list(map(int,f['ATOM_TYPE_INDEX'][:13828]));lookup=list(map(int,f['NONBONDED_PARM_INDEX']));A=list(map(float,f['LENNARD_JONES_ACOEF']));B=list(map(float,f['LENNARD_JONES_BCOEF']));ex=exclusions(f,n,13828)
alt_initial=contacts(xyz[:13828],ex,types,lookup,A,B);alt_relaxed=contacts(relaxed[:13828],ex,types,lookup,A,B)
# Complete actual observed customforce table/type joins for all three contacts.
v3=Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution/rr-qmmm-retained-reference-v3')
obs=json.loads(read(ROOT/'observation.json'))
j=json.loads(read(v3/'reference-work/native-force-observations/after-ash-masks.join.json')); pieces=[]
for r in j['ordered_chunks']:
    b=read(v3/'reference-work/native-force-observations'/r['name']);need(len(b)==r['bytes'] and sha256(b).hexdigest()==r['sha256'],'actual force chunks');pieces.append(b)
b=b''.join(pieces);need(len(b)==j['whole_bytes'] and sha256(b).hexdigest()==j['whole_sha256'],'actual full force witness')
force=json.loads(b)['custom_lj'];need(force['energy_expression']=='(a/r6)^2-b/r6; r6=r^6;a=acoef(type1, type2);b=bcoef(type1, type2);','actual selected kernel expression')
tables={r[0]:r for r in force['tabulated_functions']};need(set(tables)=={'acoef','bcoef'},'actual complete functions')
critical=[]
for p in obs['complete_contact_denominators']['held_reactive_reference']['pairs']:
    aa,bb=p['indices_0based'];ta,tb=p['source_types_1based'];need(force['particles'][aa]==[float(ta-1)] and force['particles'][bb]==[float(tb-1)],'actual critical particle type unchanged source')
    idx=(ta-1)+25*(tb-1);a=tables['acoef'][4][idx];b=tables['bcoef'][4][idx]
    aexpected=math.sqrt(p['source_A'])*math.sqrt(4.184)*.1**6;bexpected=p['source_B']*4.184*.1**6
    need(a==aexpected and b==bexpected,'actual critical source LJ conversion exact sourcecode operation')
    critical.append({'indices_0based':[aa,bb],'actual_zero_based_types':[ta-1,tb-1],'actual_acoef':a,'actual_bcoef':b,'exact_source_conversion_match':True,'not_total_MM_energy_or_force':True})
report={'role':'BOUNDED_NATIVE_FREE_SOURCE_PROVENANCE_SUPPLEMENT','status':'PASS','input_bindings':bindings,'actual_deposited_native_joins':{'complete_count':count,'chains':dict(chaincounts),'exact_decimal_translation':True},'independent_synthetic_grid_oracle':{'points':len(synthetic),'full_pairs':45,'expected_unexcluded_close_pairs':len(expected),'zero_A_preserved':True,'PASS':True},'existing_exposed_HIE91_parent':{'full_source_atoms':n,'retained_dry_atoms':13828,'initial_contacts':alt_initial,'archived_relaxed_contacts':alt_relaxed,'source_names_at_same_critical_slots':[[f['ATOM_NAME'][i] for i in r['indices_0based']] for r in alt_initial['pairs']],'interpretation':'Existing alternate H91 tautomer shares severe completed-ring preparation contacts; neither tautomer certifies deposited-D91 or assay-parent biology. Archived relaxed geometry is source-only and not newly measured stationary state.'},'actual_source_LJ_critical_pair_joins':critical,'native_effects':0,'software_body_resources':{'CPU_seconds':time.process_time(),'wall_seconds':time.monotonic()-start,'startup_and_tail':'outer resource witness'}}
raw=(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();need(len(raw)<=8*1024**2,'bounded report')
with (ROOT/'supplement-observation-v2.json').open('xb') as stream:stream.write(raw)
print(json.dumps({'status':'PASS','actual7028nativejoins':count,'HIE91initialcontacts':alt_initial['near_contact_denominator'],'HIE91relaxedcontacts':alt_relaxed['near_contact_denominator'],'actualcriticalkerneljoins':len(critical),'CPU_body_seconds':time.process_time()}))
