"""Bounded TLEaP/OpenMM work invoked only by the issued M1 native task."""

from __future__ import annotations

import base64
from dataclasses import replace
from decimal import Decimal
from hashlib import sha256
from importlib.metadata import version
from io import BytesIO
import math
import os
from pathlib import Path
import resource
import subprocess
import time
from typing import Any, Callable
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

from icf_yolo.kernel.provenance import ObjectIdentity
from icf_yolo.kernel.references import ArtifactIdentity

from .preparation import isolated_kcx_parameters, leap_commands, reconstruct_coordinates
from .records import (
    MAX_ATOMS,
    ARCHIVE_SCHEMA,
    MolecularInputV1,
    MAX_PREPARED_BYTES,
    SOURCE,
    MolecularActiveCaseV1,
    MolecularCheckpointV1,
    MolecularCaseV1,
    MolecularConfigV1,
    MolecularResultV1,
    MolecularSampleV1,
    NativeCommandV1,
)

from .resources import MAX_PREPARED_EXPANDED_BYTES, MAX_CONTEXT_BYTES
from .checkpoints import (
    CheckpointStore,
    hardware_fingerprint,
    unpack_checkpoint,
    validate_checkpoint,
    pack_latest_checkpoint,
)

SOFTWARE = Path("/home/chevre/gs-ml/icf-yolo-rubisco-r02s-20260925/.venv/rubisco-tools/amber24")
EXTERNAL = Path("/media/chevre/SEMIOS/icf-yolo/programmes/rubisco-el")


class PreparationRefusal(ValueError):
    """An explicitly declared native preparation/observation limitation."""


class NativeInterruption(RuntimeError):
    """Operational stop: preserve the last checkpoint, never complete a case."""


def decimal(value: float) -> Decimal:
    if not math.isfinite(value):
        raise PreparationRefusal("NONFINITE_NATIVE_OBSERVATION")
    return Decimal(str(float(value)))


def pack_prepared(members: dict[str, bytes]) -> tuple[str, str]:
    if sum(map(len, members.values())) > MAX_PREPARED_EXPANDED_BYTES:
        raise PreparationRefusal("PREPARED_MEMBERS_EXCEED_BOUND")
    buffer = BytesIO()
    with ZipFile(buffer, "w", compression=ZIP_DEFLATED, compresslevel=1) as archive:
        for name, payload in sorted(members.items()):
            info = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            archive.writestr(info, payload, compresslevel=1)
    payload = buffer.getvalue()
    encoded = base64.b64encode(payload).decode("ascii")
    if len(encoded) > MAX_PREPARED_BYTES:
        raise PreparationRefusal("PREPARED_ARCHIVE_EXCEEDS_BOUND")
    return encoded, sha256(payload).hexdigest()


def unpack_prepared(result: MolecularResultV1) -> dict[str, bytes]:
    payload = base64.b64decode(result.prepared_archive_base64, validate=True)
    if sha256(payload).hexdigest() != result.prepared_archive_sha256:
        raise ValueError("M1 prepared archive checksum changed")
    with ZipFile(BytesIO(payload)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        if (
            len(names) > 42
            or len(names) != len(set(names))
            or sum(i.file_size for i in infos) > MAX_PREPARED_EXPANDED_BYTES
        ):
            raise ValueError("M1 prepared archive inventory is unbounded")
        allowed = {
            f"{v}-{p}/{n}"
            for v in ("WT", "M100T", "D206E")
            for p in ("HID91", "HIE91")
            for n in (
                "prepared.prmtop",
                "prepared.inpcrd",
                "relaxed.npy",
                "leap.stdout",
                "leap.log",
                "reconstructed.pdb",
                "relaxation.json",
            )
        }
        if any(
            i.filename not in allowed or i.flag_bits & 1 or i.file_size > 64 * 1024**2
            for i in infos
        ):
            raise ValueError("M1 prepared archive contains an undeclared member")
        return {i.filename: archive.read(i) for i in infos}


def _read(path: Path, limit: int) -> bytes:
    if path.is_symlink() or not path.is_file() or path.stat().st_size > limit:
        raise PreparationRefusal("PREPARATION_FILE_ABSENT_OR_OVERSIZED")
    with path.open("rb") as stream:
        payload = stream.read(limit + 1)
    if len(payload) > limit:
        raise PreparationRefusal("PREPARATION_FILE_EXCEEDS_BOUND")
    return payload


def prepare_topology(
    directory: Path, reconstructed: bytes, inputs: dict[str, bytes], *, timeout_seconds: float
) -> None:
    parameters, residue, _ = isolated_kcx_parameters(
        inputs["kcx-parameters"], inputs["kcx-residue"], SOFTWARE
    )
    files = {
        "reconstructed.pdb": reconstructed,
        "kcx-isolated.frcmod": parameters,
        "kcx-isolated.prepin": residue,
        "rubp.frcmod": inputs["rubp-parameters"],
        "rubp.prepi": inputs["rubp-residue"],
        "build.leap": leap_commands(),
    }
    for name, payload in files.items():
        if len(payload) > (64 if name == "reconstructed.pdb" else 1) * 1024**2:
            raise PreparationRefusal("PREPARATION_SUPPORT_FILE_EXCEEDS_DECLARED_BOUND")
        (directory / name).write_bytes(payload)
    # Direct fixed executable and include roots: no user-authored shell or loader.
    command = [str(SOFTWARE / "bin/teLeap")]
    command += ["-I" + str(SOFTWARE / "dat/leap" / p) for p in ("prep", "lib", "parm", "cmd")]
    command += ["-f", "build.leap"]
    environment = dict(os.environ)
    environment.update(
        AMBERHOME=str(SOFTWARE), OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1"
    )
    with (directory / "leap.stdout").open("wb") as log:
        try:
            completed = subprocess.run(
                command,
                cwd=directory,
                env=environment,
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            raise NativeInterruption("TLEAP_ATTEMPT_RESERVATION_EXHAUSTED") from exc
    text = _read(directory / "leap.stdout", 4 * 1024**2).decode("ascii", errors="replace")
    if completed.returncode or "FATAL" in text or not (directory / "prepared.prmtop").is_file():
        raise PreparationRefusal("TLEAP_PREPARATION_REFUSED")


def _observation_indices(
    parm: Any, sequence: str, variant: str, preparation: str
) -> tuple[Any, ...]:
    import numpy as np
    from Bio.Data.PDBData import protein_letters_3to1

    if len(parm.atoms) > MAX_ATOMS:
        raise PreparationRefusal("ATOM_CENSUS_EXCEEDS_BOUND")
    protein: list[int] = []
    sites = []
    for offset in (0, 460):
        residues = parm.residues[offset : offset + 458]
        if len(residues) != 458 or residues[189].name != "KCX":
            raise PreparationRefusal("PREPARED_PROTEIN_OR_CARBAMATE_CENSUS_DIFFERS")
        for position, residue in enumerate(residues, start=2):
            if position == 191:
                expected, actual = "KCX", residue.name
            elif position == 91:
                expected, actual = preparation[:3], residue.name
            else:
                expected = (
                    "T"
                    if variant == "M100T" and position == 100
                    else "E"
                    if variant == "D206E" and position == 206
                    else sequence[position - 1]
                )
                name = residue.name
                if (position == 2 and name.startswith("N") and len(name) == 4) or (
                    position == 459 and name.startswith("C") and len(name) == 4
                ):
                    name = name[1:]
                actual = "H" if name == "HIE" else protein_letters_3to1.get(name)
            if actual != expected or len({a.name for a in residue.atoms}) != len(residue.atoms):
                raise PreparationRefusal("PREPARED_SEQUENCE_OR_ATOM_CENSUS_DIFFERS")
        protein.extend(a.idx for r in residues for a in r.atoms)
        ligand, metal = parm.residues[offset + 458 : offset + 460]
        if ligand.name != "RUB" or metal.name != "MG":
            raise PreparationRefusal("PREPARED_ACTIVE_SITE_ORDER_DIFFERS")
        for residue, count, charge in ((residues[189], 23, -1), (ligand, 26, -4), (metal, 1, 2)):
            if (
                len(residue.atoms) != count
                or abs(sum(a.charge for a in residue.atoms) - charge) > 0.00001
            ):
                raise PreparationRefusal("PREPARED_CHEMICAL_ATOM_OR_CHARGE_CENSUS_DIFFERS")
        for left, right in ((residues[188], residues[189]), (residues[189], residues[190])):
            carbon = next(a for a in left.atoms if a.name == "C")
            nitrogen = next(a for a in right.atoms if a.name == "N")
            if nitrogen not in carbon.bond_partners:
                raise PreparationRefusal("CARBAMATE_PEPTIDE_BOUNDARY_DISCONNECTED")

        def atom(residue: Any, name: str) -> int:
            matches = [a.idx for a in residue.atoms if a.name == name]
            if len(matches) != 1:
                raise PreparationRefusal("PREPARED_RECEIVER_ATOM_ABSENT_OR_DUPLICATED")
            return int(matches[0])

        sites.append(
            (
                atom(metal, "MG"),
                atom(ligand, "O2"),
                atom(ligand, "C2"),
                atom(residues[189], "OQ1"),
                atom(residues[189], "OQ2"),
                atom(residues[164], "NZ"),
                atom(ligand, "O3"),
                *(atom(ligand, name) for name in ("C3", "C4", "C5", "O4")),
            )
        )
    if (
        sum(r.name == "KCX" for r in parm.residues) != 2
        or sum(r.name == "RUB" for r in parm.residues) != 2
    ):
        raise PreparationRefusal("PREPARED_ACTIVATION_CENSUS_DIFFERS")
    if any(r.name not in ("WAT", "Na+", "Cl-") for r in parm.residues[920:]):
        raise PreparationRefusal("UNDECLARED_SOLVENT_OR_ION_RESIDUE")
    return (
        tuple(sites),
        np.array(protein, dtype=np.int64),
        np.array([a.charge for a in parm.atoms], dtype=np.float64),
    )


def _receivers(
    positions: Any, box: Any, indices: tuple[Any, ...]
) -> tuple[tuple[Decimal, ...], ...]:
    import numpy as np

    sites, protein, charges = indices
    lengths = np.diag(box)
    if np.max(np.abs(box - np.diag(lengths))) > 1e-8 or np.min(lengths) <= 1.8:
        raise PreparationRefusal("UNSUPPORTED_PERIODIC_BOX")

    def wrapped(delta: Any) -> Any:
        return delta - lengths * np.rint(delta / lengths)

    result = []
    for mg, o2, c2, oq1, oq2, nz, o3, *_ in sites:
        distances = [
            np.linalg.norm(wrapped(positions[mg] - positions[o2])),
            min(np.linalg.norm(wrapped(positions[mg] - positions[j])) for j in (oq1, oq2)),
            np.linalg.norm(wrapped(positions[nz] - positions[o3])),
        ]
        delta = wrapped(positions[o2] - positions[protein])
        radii = np.linalg.norm(delta, axis=1)
        valid = (radii > 0.05) & (radii < 2.0)
        bond = wrapped(positions[o2] - positions[c2])
        bond_length = np.linalg.norm(bond)
        if not 0.08 < bond_length < 0.2:
            raise PreparationRefusal("RUBP_CARBONYL_GEOMETRY_INVALID")
        field = 138.935456 * np.sum(
            charges[protein[valid], None] * delta[valid] / radii[valid, None] ** 3, axis=0
        )
        result.append(tuple(decimal(x) for x in (*distances, np.dot(field, bond / bond_length))))
    return tuple(result)


def _chirality(positions: Any, indices: tuple[Any, ...]) -> tuple[int, ...]:
    import numpy as np

    result = []
    for _, _, c2, _, _, _, o3, c3, c4, c5, o4 in indices[0]:
        for center, a, b, c in ((c3, c2, c4, o3), (c4, c3, c5, o4)):
            volume = float(
                np.dot(
                    positions[a] - positions[center],
                    np.cross(positions[b] - positions[center], positions[c] - positions[center]),
                )
            )
            if not math.isfinite(volume) or abs(volume) < 1e-7:
                raise PreparationRefusal("RUBP_STEREOCENTRE_DEGENERATE")
            result.append(1 if volume > 0 else -1)
    return tuple(result)


def _checkpoint_input(record: MolecularCheckpointV1, capsule: bytes) -> MolecularInputV1:
    return MolecularInputV1(
        "checkpoint",
        ArtifactIdentity(
            f"native-checkpoint.{record.fingerprint()}",
            "operational-native-state",
            ARCHIVE_SCHEMA,
            sha256(capsule).hexdigest(),
            "application/zip",
            len(capsule),
        ),
        ObjectIdentity.from_record(record.checkpoint_id, record),
    )


def observe(
    config: MolecularConfigV1,
    inputs: dict[str, bytes],
    progress: Callable[[Decimal], None],
    *,
    execution_identity: tuple[str, str, str],
) -> MolecularResultV1:
    """Run or continue the fixed pilot from authenticated native boundaries."""
    import json
    import numpy as np
    import openmm as mm  # type: ignore[import-untyped]
    from openmm import app, unit
    from parmed.amber import AmberParm  # type: ignore[import-untyped]

    if config.phase != "PILOT":
        raise ValueError("The v5 checkpointed execution contract currently exposes PILOT only")
    if version("openmm") != config.openmm_version or version("parmed") != config.parmed_version:
        raise ValueError("M1 numerical software changed after freeze")
    directory = Path.cwd().resolve(strict=True)
    if not directory.is_relative_to(EXTERNAL) or directory == EXTERNAL:
        raise PermissionError("M1 native work requires guarded external worker scratch")
    started = time.monotonic()
    issued_config = config
    # The scheduler alone allocates this attempt. The frozen two-attempt
    # contract permits reading only its immediate predecessor's restart state.
    # Never restart an interrupted issued trajectory from initial coordinates.
    run_id, task_id, attempt_id = execution_identity
    prefix = f"{run_id}.{task_id}.attempt-"
    if attempt_id.startswith(prefix) and attempt_id != prefix + "001":
        if attempt_id != prefix + "002" or config.resume_checkpoint is not None:
            raise ValueError("Native attempt is outside the frozen continuation census")
        previous = directory.parent / (prefix + "001") / "checkpoints"
        record, capsule = pack_latest_checkpoint(previous)
        if (record.origin_run_id, record.origin_task_id, record.origin_attempt_id) != (
            run_id,
            task_id,
            prefix + "001",
        ):
            raise ValueError("Checkpoint belongs to another issued attempt")
        config = replace(
            config,
            resume_checkpoint=ObjectIdentity.from_record(record.checkpoint_id, record),
            # No complete prior-attempt timing is available inside the worker.
            # The immutable resource journal retains the original launch cost.
            prior_attempt_seconds=None,
            inputs=(*config.inputs, _checkpoint_input(record, capsule)),
        )
        inputs = {**inputs, "checkpoint": capsule}
    loaded = (
        unpack_checkpoint(inputs["checkpoint"]) if config.resume_checkpoint is not None else None
    )
    if loaded is not None:
        validate_checkpoint(loaded, config)
    elif "checkpoint" in inputs:
        raise ValueError("Unbound checkpoint input is not an authorized continuation")
    store = CheckpointStore(directory / "checkpoints")
    if loaded is not None:
        store.import_checkpoint(loaded)
    prepared: dict[str, bytes] = {} if loaded is None else dict(loaded.prepared)
    cases = [] if loaded is None else list(loaded.record.completed_cases)
    restored_case_count = len(cases)
    restored_sample_count = (
        0
        if loaded is None or loaded.record.active is None
        else len(loaded.record.active.case.samples)
    )
    generation = 0 if loaded is None else loaded.record.generation
    parent_sha256 = None if loaded is None else loaded.record.fingerprint()
    hardware = hardware_fingerprint()
    protocol = config.protocol_fingerprint()
    from .progress import NativeWorkProgress

    work = NativeWorkProgress(progress)
    if loaded is not None:
        work.count = loaded.record.progress_count
    global_failure = (
        "NATIVE_BUDGET_EXHAUSTED"
        if any(
            case.failure_code and case.failure_code.startswith("NATIVE_BUDGET") for case in cases
        )
        else None
    )
    sequence = "".join(inputs["reference"].decode("ascii").splitlines()[1:])

    def elapsed() -> float:
        # Each attempt of the original issue has a finite reservation. Prior
        # actual/unknown attempt costs remain explicit; they never become zero.
        return time.monotonic() - started

    if loaded is None:
        # A crash inside the first preparation must still have an explicit
        # durable boundary. It authorizes replay of that unfinished call only.
        generation = 1
        origin = MolecularCheckpointV1(
            f"checkpoint.{execution_identity[0]}.{generation:06d}",
            protocol,
            *execution_identity,
            hardware,
            generation,
            None,
            (),
            None,
            (),
            0,
            decimal(elapsed()),
        )
        store.commit(origin)
        parent_sha256 = origin.fingerprint()

    for case_index, (variant, preparation, seed) in enumerate(config.cases):
        if case_index < len(cases):
            continue
        saved = loaded.record.active if loaded is not None else None
        if saved is not None and saved.case_index != case_index:
            saved = None
        reconstructed, audit = reconstruct_coordinates(
            inputs["structure"], inputs["reference"], variant, preparation
        )
        if saved is not None and saved.case.reconstruction != audit:
            raise ValueError("Checkpoint reconstruction differs from the frozen preparation")
        key = f"{variant}-{preparation}"
        case_directory = directory / f"{key}-{seed}"
        case_directory.mkdir(exist_ok=False)
        case_started = time.monotonic()
        prior_case_seconds = 0.0 if saved is None else float(saved.case.case_elapsed_seconds)
        preparation_seconds = 0.0 if saved is None else float(saved.case.preparation_seconds)
        context_seconds = 0.0 if saved is None else float(saved.case.context_seconds)
        relaxation_seconds = 0.0 if saved is None else float(saved.case.relaxation_seconds)
        warmup_seconds = 0.0 if saved is None else float(saved.case.warmup_seconds)
        integration_seconds = 0.0 if saved is None else float(saved.case.integration_seconds)
        atom_count = 0 if saved is None else saved.case.atom_count
        topology_hash = None if saved is None else saved.case.topology_sha256
        positions_hash = None if saved is None else saved.case.minimized_positions_sha256
        net_charge = None if saved is None else saved.case.net_charge_e
        initial_force = None if saved is None else saved.case.initial_force_max_kj_mol_nm
        relaxed_force = None if saved is None else saved.case.relaxed_force_max_kj_mol_nm
        terminal_command = None if saved is None else saved.case.terminal_command
        samples = [] if saved is None else list(saved.case.samples)
        reports = [] if saved is None else list(saved.case.minimizer_report_calls)
        relaxed_captured = False if saved is None else saved.relaxed_captured
        warmup_complete = False if saved is None else saved.warmup_complete
        reference_chirality: tuple[int, ...] = ()
        failure = None
        context = integrator = system = None
        system_hash = integrator_hash = None
        active_stage = "preparation"
        stage_started = time.monotonic()
        stage_charged = False

        def current_case() -> MolecularCaseV1:
            return MolecularCaseV1(
                variant,
                preparation,
                seed,
                f"{SOURCE}.{variant.lower()}.{preparation.lower()}.{seed}",
                f"{SOURCE}.{variant.lower()}.{preparation.lower()}",
                audit,
                atom_count,
                topology_hash,
                positions_hash,
                decimal(preparation_seconds),
                decimal(context_seconds),
                decimal(relaxation_seconds),
                decimal(integration_seconds),
                tuple(samples),
                tuple(reports),
                net_charge,
                failure,
                initial_force,
                relaxed_force,
                terminal_command,
                decimal(warmup_seconds),
                decimal(prior_case_seconds + time.monotonic() - case_started),
            )

        def checkpoint(active: bool) -> None:
            nonlocal generation, parent_sha256
            members = tuple(
                (name, len(payload), store.put(payload))
                for name, payload in sorted(prepared.items())
            )
            active_record = None
            if active:
                data = b"" if context is None else context.createCheckpoint()
                if len(data) > MAX_CONTEXT_BYTES:
                    raise ValueError("Native checkpoint exceeds its full-state reservation")
                digest = None if not data else store.put(data)
                active_record = MolecularActiveCaseV1(
                    case_index,
                    current_case(),
                    len(reports),
                    relaxed_captured,
                    warmup_complete,
                    reference_chirality,
                    digest,
                    len(data),
                    system_hash if data else None,
                    integrator_hash if data else None,
                )
            generation += 1
            record = MolecularCheckpointV1(
                f"checkpoint.{execution_identity[0]}.{generation:06d}",
                protocol,
                *execution_identity,
                hardware,
                generation,
                parent_sha256,
                tuple(cases),
                active_record,
                members,
                work.count,
                (Decimal(0) if loaded is None else loaded.record.accounted_elapsed_seconds)
                + decimal(elapsed()),
            )
            store.commit(record)
            parent_sha256 = record.fingerprint()

        try:
            if elapsed() > config.maximum_native_seconds - 30:
                raise NativeInterruption("NATIVE_ATTEMPT_RESERVATION_EXHAUSTED")
            if saved is None:
                prepare_topology(
                    case_directory,
                    reconstructed,
                    inputs,
                    timeout_seconds=max(1.0, config.maximum_native_seconds - elapsed() - 30),
                )
            else:
                for name in (
                    "prepared.prmtop",
                    "prepared.inpcrd",
                    "leap.stdout",
                    "leap.log",
                    "reconstructed.pdb",
                ):
                    (case_directory / name).write_bytes(prepared[f"{key}/{name}"])
            topology_bytes = _read(case_directory / "prepared.prmtop", 64 * 1024**2)
            _read(case_directory / "prepared.inpcrd", 32 * 1024**2)
            topology_hash = sha256(topology_bytes).hexdigest()
            parm = AmberParm(
                str(case_directory / "prepared.prmtop"), str(case_directory / "prepared.inpcrd")
            )
            atom_count = len(parm.atoms)
            indices = _observation_indices(parm, sequence, variant, preparation)
            net_charge = decimal(sum(a.charge for a in parm.atoms))
            if abs(net_charge) > Decimal("0.001"):
                raise PreparationRefusal("PREPARED_SYSTEM_NOT_NEUTRAL")
            system = parm.createSystem(
                nonbondedMethod=app.PME,
                nonbondedCutoff=0.9 * unit.nanometer,
                constraints=app.HBonds,
                rigidWater=True,
                ewaldErrorTolerance=0.0005,
            )
            # Restraint anchors always come from the original preparation,
            # never from the subsequently restored relaxed coordinates.
            positions = np.asarray(parm.positions.value_in_unit(unit.nanometer), dtype=np.float64)
            reference_chirality = _chirality(positions, indices)
            if saved is not None and saved.reference_chirality != reference_chirality:
                raise ValueError("Checkpoint changed its original stereochemistry reference")
            restraint = mm.CustomExternalForce("0.5*k*periodicdistance(x,y,z,x0,y0,z0)^2")
            restraint.addGlobalParameter("k", 1000.0)
            for name in ("x0", "y0", "z0"):
                restraint.addPerParticleParameter(name)
            for atom in parm.atoms:
                if atom.residue.idx < 920 and atom.atomic_number > 1:
                    restraint.addParticle(atom.idx, positions[atom.idx].tolist())
            system.addForce(restraint)
            preparation_seconds += time.monotonic() - stage_started
            stage_charged = True
            for name in (
                "prepared.prmtop",
                "prepared.inpcrd",
                "leap.stdout",
                "leap.log",
                "reconstructed.pdb",
            ):
                prepared[f"{key}/{name}"] = _read(case_directory / name, 64 * 1024**2)
            work.advance(force=True)
            if saved is None:
                checkpoint(True)

            active_stage = "context"
            stage_started = time.monotonic()
            stage_charged = False
            integrator = mm.LangevinMiddleIntegrator(
                float(config.temperature_kelvin) * unit.kelvin,
                float(config.friction_per_ps) / unit.picosecond,
                float(config.timestep_ps) * unit.picosecond,
            )
            integrator.setRandomNumberSeed(seed)
            system_hash = sha256(mm.XmlSerializer.serialize(system).encode()).hexdigest()
            integrator_hash = sha256(mm.XmlSerializer.serialize(integrator).encode()).hexdigest()
            context = mm.Context(
                system,
                integrator,
                mm.Platform.getPlatformByName("CPU"),
                {"Threads": "1", "DeterministicForces": "true"},
            )
            if saved is not None and saved.context_sha256 is not None:
                if (
                    loaded is None
                    or loaded.context is None
                    or (saved.system_sha256, saved.integrator_sha256)
                    != (system_hash, integrator_hash)
                ):
                    raise ValueError(
                        "Checkpoint System/integrator differs from the pinned reconstruction"
                    )
                try:
                    context.loadCheckpoint(loaded.context)
                except mm.OpenMMException as exc:
                    raise ValueError(
                        "Native checkpoint cannot be restored under the frozen software"
                    ) from exc
                if context.createCheckpoint() != loaded.context:
                    raise ValueError(
                        "Native checkpoint did not restore byte-identical internal state"
                    )
                expected_steps = (config.warmup_steps if saved.warmup_complete else 0) + len(
                    saved.case.samples
                ) * (config.sampling_steps // config.sample_count)
                if (
                    context.getStepCount() != expected_steps
                    or abs(
                        float(context.getState().getTime().value_in_unit(unit.picosecond))
                        - expected_steps * float(config.timestep_ps)
                    )
                    > 1e-10
                ):
                    raise ValueError(
                        "Restored native action/time differs from its checkpoint cursor"
                    )
            else:
                context.setPositions(positions * unit.nanometer)
                state = context.getState(getForces=True)
                initial_force = decimal(
                    float(
                        np.max(
                            np.linalg.norm(
                                state.getForces(asNumpy=True).value_in_unit(
                                    unit.kilojoule_per_mole / unit.nanometer
                                ),
                                axis=1,
                            )
                        )
                    )
                )
            context_seconds += time.monotonic() - stage_started
            stage_charged = True
            work.advance(force=True)
            if saved is None or saved.context_sha256 is None:
                checkpoint(True)

            class Reporter(mm.MinimizationReporter):  # type: ignore[misc]
                calls = 0
                interrupted = False

                def report(self, iteration: int, x: Any, grad: Any, args: Any) -> bool:
                    self.calls += 1
                    work.advance()
                    self.interrupted = elapsed() > config.maximum_native_seconds - 30
                    return self.interrupted

            for strength in (1000.0, 100.0, 0.0)[len(reports) :]:
                if elapsed() > config.maximum_native_seconds - 30:
                    raise NativeInterruption("NATIVE_ATTEMPT_RESERVATION_EXHAUSTED")
                active_stage = "relaxation"
                stage_started = time.monotonic()
                stage_charged = False
                context.setParameter("k", strength)
                reporter = Reporter()
                mm.LocalEnergyMinimizer.minimize(context, 10.0, 500, reporter)
                if reporter.interrupted:
                    raise NativeInterruption("MINIMIZER_ATTEMPT_RESERVATION_EXHAUSTED")
                reports.append(reporter.calls)
                relaxation_seconds += time.monotonic() - stage_started
                stage_charged = True
                checkpoint(True)

            if not relaxed_captured:
                active_stage = "relaxation"
                stage_started = time.monotonic()
                stage_charged = False
                state = context.getState(getPositions=True, getForces=True)
                positions = np.asarray(
                    state.getPositions(asNumpy=True).value_in_unit(unit.nanometer), dtype=np.float64
                )
                relaxed_force = decimal(
                    float(
                        np.max(
                            np.linalg.norm(
                                state.getForces(asNumpy=True).value_in_unit(
                                    unit.kilojoule_per_mole / unit.nanometer
                                ),
                                axis=1,
                            )
                        )
                    )
                )
                if _chirality(positions, indices) != reference_chirality:
                    raise PreparationRefusal("RUBP_STEREOCHEMISTRY_CHANGED")
                buffer = BytesIO()
                np.save(buffer, positions, allow_pickle=False)
                prepared[f"{key}/relaxed.npy"] = buffer.getvalue()
                prepared[f"{key}/relaxation.json"] = (
                    json.dumps(
                        {
                            "minimizer_report_calls": reports,
                            "restraints_kj_mol_nm2": [1000, 100, 0],
                        },
                        sort_keys=True,
                    )
                    + "\n"
                ).encode()
                positions_hash = sha256(prepared[f"{key}/relaxed.npy"]).hexdigest()
                relaxed_captured = True
                relaxation_seconds += time.monotonic() - stage_started
                stage_charged = True
                work.advance(force=True)
                checkpoint(True)

            if not warmup_complete:
                if elapsed() > config.maximum_native_seconds - 30:
                    raise NativeInterruption("NATIVE_ATTEMPT_RESERVATION_EXHAUSTED")
                active_stage = "warmup"
                stage_started = time.monotonic()
                stage_charged = False
                context.setVelocitiesToTemperature(
                    float(config.temperature_kelvin) * unit.kelvin, seed + 1
                )
                before_steps = context.getStepCount()
                before_time = float(context.getState().getTime().value_in_unit(unit.picosecond))
                try:
                    integrator.step(config.warmup_steps)
                finally:
                    terminal_command = NativeCommandV1(
                        config.warmup_steps,
                        config.warmup_steps,
                        context.getStepCount() - before_steps,
                        decimal(
                            float(context.getState().getTime().value_in_unit(unit.picosecond))
                            - before_time
                        ),
                    )
                warmup_seconds += time.monotonic() - stage_started
                stage_charged = True
                warmup_complete = True
                work.advance(force=True)
                checkpoint(True)

            block = config.sampling_steps // config.sample_count
            for sample_index in range(len(samples) + 1, config.sample_count + 1):
                if elapsed() > config.maximum_native_seconds - 30:
                    raise NativeInterruption("NATIVE_ATTEMPT_RESERVATION_EXHAUSTED")
                active_stage = "integration"
                stage_started = time.monotonic()
                stage_charged = False
                before_steps = context.getStepCount()
                before_time = float(context.getState().getTime().value_in_unit(unit.picosecond))
                try:
                    integrator.step(block)
                finally:
                    terminal_command = NativeCommandV1(
                        block,
                        block,
                        context.getStepCount() - before_steps,
                        decimal(
                            float(context.getState().getTime().value_in_unit(unit.picosecond))
                            - before_time
                        ),
                    )
                state = context.getState(getEnergy=True, getPositions=True)
                positions = np.asarray(
                    state.getPositions(asNumpy=True).value_in_unit(unit.nanometer), dtype=np.float64
                )
                box = np.asarray(
                    state.getPeriodicBoxVectors(asNumpy=True).value_in_unit(unit.nanometer),
                    dtype=np.float64,
                )
                sites = _receivers(positions, box, indices)
                if _chirality(positions, indices) != reference_chirality:
                    raise PreparationRefusal("RUBP_STEREOCHEMISTRY_CHANGED")
                samples.append(
                    MolecularSampleV1(
                        sample_index,
                        terminal_command,
                        decimal(state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)),
                        sites,
                    )
                )
                if any(site[0] > Decimal("0.5") or site[1] > Decimal("0.5") for site in sites):
                    raise PreparationRefusal("ACTIVE_SITE_COORDINATION_LOST")
                integration_seconds += time.monotonic() - stage_started
                stage_charged = True
                work.advance(force=True)
                checkpoint(True)
        except PreparationRefusal as exc:
            failure = str(exc)
        except mm.OpenMMException:
            failure = "NATIVE_OPENMM_NUMERICAL_FAILURE"
        finally:
            if failure and not stage_charged:
                spent = time.monotonic() - stage_started
                if active_stage == "preparation":
                    preparation_seconds += spent
                elif active_stage == "context":
                    context_seconds += spent
                elif active_stage == "relaxation":
                    relaxation_seconds += spent
                elif active_stage == "warmup":
                    warmup_seconds += spent
                elif active_stage == "integration":
                    integration_seconds += spent
            for name in (
                "prepared.prmtop",
                "prepared.inpcrd",
                "leap.stdout",
                "leap.log",
                "reconstructed.pdb",
            ):
                path = case_directory / name
                if path.is_file() and not path.is_symlink() and path.stat().st_size <= 64 * 1024**2:
                    prepared[f"{key}/{name}"] = _read(path, 64 * 1024**2)
            del context, integrator
            context = None
        cases.append(current_case())
        work.advance(force=True)
        checkpoint(False)
        if failure and failure.startswith("NATIVE_BUDGET"):
            global_failure = "NATIVE_BUDGET_EXHAUSTED"
    encoded, digest = pack_prepared(prepared)
    return MolecularResultV1(
        SOURCE,
        ObjectIdentity.from_record(issued_config.config_id, issued_config),
        config.phase,
        tuple(cases),
        encoded,
        digest,
        decimal(elapsed()),
        max(
            resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
        )
        * 1024,
        work.count,
        global_failure,
        resume_checkpoint=config.resume_checkpoint,
        prior_attempt_seconds=config.prior_attempt_seconds,
        restored_case_count=restored_case_count,
        restored_sample_count=restored_sample_count,
    )
