# Bounded native-free source provenance diagnosis

The current reference's three severe fixed-MM contacts were inherited from the original parent Amber completion before its recorded minimization. They were not introduced by the EL source-coordinate mapping, the B287 donor splice, or the observed QM masks at these atom indices. This is an ordinary source/provenance diagnosis, not a new molecular calculation, accepted reactive state, total force measurement, kinetic result, or canonical scientific product.

The retained scope is R1 of `docs/rubisco-inquiry/scientific-redirection-v1.md`. No atoms, exclusions, immutable inputs, native solvers, Contexts, source constructors, fits, or acquisitions were changed or entered. All scientific native-effect counts are zero.

## Complete source and contact denominator

`observation.json` binds the complete original 55,092,530-byte parent envelope, its 42-member archive (41,295,643 bytes compressed; 180,758,177 expanded), the closed 44-file source core and every file in the closed 177-file latest reference packet. Original Amber atom names, types and coordinate tokens join all 13,828 retained dry atoms exactly out of 116,767 source atoms. `supplement-observation-v4.json` independently verifies all 7,028 positive-occupancy inherited native heavy-atom joins with exact Decimal translation (A: 3,512; B: 3,516). The deposited record retains 7,044 total heavy rows, including zero occupancy; its 7,035 positive-occupancy rows are only a geometry screen.

The spatial hash checks every unordered pair that could fall below 0.75 Angstrom; 95,599,878 full dry-core pairs are represented by the exact grid, with source exclusions applied and zero-LJ contacts retained. An independent exhaustive synthetic oracle checks negative cell boundaries, equality to the cutoff, overlaps, exclusions and zero-A admission. No sampling or favorable-pair selection was used.

| Source coordinate stage | Dry atom count | Complete nonexcluded contacts below 0.75 A |
| --- | ---: | ---: |
| Original WT-HID91 parent prepared coordinates | 13,828 | 3 |
| Held reactive reference with observed postmask exclusions | 13,828 | 3 |
| Archived WT-HID91 parent relaxed coordinates | 13,828 | 0 |
| Archived WT-HIE91 parent prepared coordinates | 13,828 | 4 |
| Archived WT-HIE91 parent relaxed coordinates | 13,828 | 0 |

For the selected HID source, the original and held coordinates of every reported contact atom are identical. The held plan changes only three physical proton positions: both H287 HE2-to-HD1 moves and the active RuBP C3 proton transfer. None is a contact atom below.

| Source zero-based indices | Physical identities | Original/held distance (A) | Archived relaxed distance (A) |
| --- | --- | ---: | ---: |
| 1345 / 10583 | A91 HID HE1 / B243 ARG NH1 | 0.278486927221 | 3.523244898458 |
| 1346 / 10588 | A91 HID NE2 / B243 ARG HH22 | 0.097095275467 | 3.943661048992 |
| 3674 / 8258 | A243 ARG HH22 / B91 HID CE1 | 0.652370026373 | 2.628707429308 |

Every pair is fixed MM, has positive native source LJ A, and is absent from original, derived, native pre-mask and native post-mask exclusions. Full original and derived exclusions each contain 75,274 pairs; the donor splice changes one H287-local pair in each direction. The observed pre-mask set equals the derived set exactly. The post-mask set is exactly its union with all real-QM pairs, totaling 77,827. The supplement also checks actual critical atom types and the observed complete-table kernel entries against the native source A/B conversion. Source scalar pair arithmetic is not the unrecorded total MM/coupled energy or gradient.

The alternate HIE source reorders atom slots within H91. It retains the same three ring contacts by physical name and adds HIE HE2 versus opposite ARG NH2 at 0.708100350093 A. Thus choosing the exposed HIE tautomer alone does not fix the completion defect.

## Three explanations and disposition

1. **Inherited parent completion / coordinate-stage selection: supported.** Both deposited residues 91 are Asp. The parent reconstruction explicitly keeps only N/CA/C/O/CB there, relabels the residue HID/HIE, and lets Amber complete the ring. The reconstructed heavy-only file has no below-cutoff overlap, but completion introduces the severe ring/Arg contacts in the prepared coordinates. The parent's actual next step applies whole-system minimization, then writes and uses `relaxed.npy` before warmup/sampling. The EL source core deliberately selected the earlier prepared coordinates. The bounded source search finds this sidechain-deletion recipe in the completion worktree's m1 v1-v6 preparations; it finds no explicit clash/overlap/steric admission in those preparation files. Exact producing v5 source copies and digests are retained.
2. **EL coordinate/index mapping error: no support for these contacts.** The complete original-to-core joins are exact; deposited identities/translation are independently checked. Critical atoms are unchanged in the held physical input and match the actual observed force table/type indices. This scoped result does not certify every undocumented native-library internal position.
3. **Derived donor/chain defect creates the contacts: excluded for this contact denominator.** The three contacts predate derivation, affect H91 and opposite Arg243 rather than H287, and retain all relevant source exclusions and actual mask semantics. Complete original and held severe contact sets agree.

The actual v3 rejected total energy/gradient were not retained before their finite/bounded guard. These source findings therefore do not prove whether a nonfinite or over-cap energy or gradient triggered that guard. They identify a genuine input/preparation defect and a plausible large-repulsion mechanism, with that causal limit explicit.

The archived relaxed coordinates are an evidenced existing reuse candidate, not an authorized coordinate patch. Their source is a whole solvated PME model with 0.9 nm cutoff, H-bond constraints and three restraint strengths (1000/100/0 kJ mol-1 nm-2). The saved reporter counts are 2023/1592/1125; no stationarity or force certificate is present in the relaxation record. Zero severe contacts does not qualify the dry reactive Hamiltonian, active enolate, proton state, or enzyme species. Moving to those coordinates requires an explicit source/preparation identity and a physically justified common construction. Deposited Asp91, computational P04718 His91 and the unverified assay-parent identity remain distinct choices. No His6-WT or H287 own-WT identity is inferred.

The current immutable reference is parked. There is no ad-hoc exclusion removal, local atom move, new whole-protein relaxation, automatic native retry or source-owner change in this diagnosis. Root owns the subsequent source/model decision.

## Software and resource history

The original diagnostic refused on an unselected Amber format after full archive authentication. The selected-format parser successor passed. The supplemental checker then retained three software refusals: wrong CIF-id column indexing, canonical Mg versus native `MG` spelling, and floating-operation association differing from the actual source conversion. The final supplemental checker passed with those representation rules corrected. Every original helper/stdout/stderr/resource file is preserved; these are software refusals, not native science.

Each process used a selected locked `uv run --no-sync` environment with native/optional science imports blocked. Main checker CPU limit: 120 seconds; supplement limit: 60 seconds; both 2 GiB address space. All outer resource observations are retained. Their startup-to-exit CPU sum is recorded in `resource-summary.json`. Earlier source reading and final closure engineering costs are unmeasured and explicitly outside that sum. The original root-selected two-hour engineering window is not reset by this packet. No ArtifactPlane publication or new authority is claimed.
