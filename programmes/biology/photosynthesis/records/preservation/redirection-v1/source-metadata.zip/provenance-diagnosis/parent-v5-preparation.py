"""Explicit 9RUB reconstruction and isolated KCX parameter construction.

These functions do not construct an OpenMM Context. Native preparation is
invoked by the issued worker; the source inventory remains separately readable.
"""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from decimal import Decimal
from hashlib import sha256
from io import StringIO
from itertools import product
from pathlib import Path
from typing import Any, ClassVar

from icf_yolo.kernel.serialization import CanonicalRecord, validate_sha256

KCX_TYPES = {
    "N": "kN",
    "CT": "kT",
    "C": "kC",
    "O2": "kQ",
    "H1": "k1",
    "HC": "kH",
    "H": "kh",
    "O": "kO",
}
VARIANTS = ("WT", "M100T", "D206E")
PREPARATIONS = ("HID91", "HIE91")
REFERENCE_SHA256 = "d7edfcdad62964ce96ec766ca4bd83e115c19ee257585c9014f07b7d325e48d0"
STRUCTURE_SHA256 = "33242f8e519c2e032c5a83de33a6350eb5c38cef42b5a14e1f8ecfb9230575dd"


@dataclass(frozen=True, slots=True)
class ReconstructionAuditV1(CanonicalRecord):
    SCHEMA: ClassVar[str] = "icf-yolo/rubisco/m1-v5-reconstruction-audit/v1"
    variant: str
    preparation: str
    source_sha256: str
    coordinate_sha256: str
    protein_residues: int
    omitted_zero_occupancy_atoms: tuple[str, ...]
    mutation_and_repair_sites: tuple[tuple[str, int, str, str], ...]
    active_site_residues: tuple[tuple[str, str, int], ...]
    observed_heavy_atom_count: int
    physical_biological_units: int = 0

    def __post_init__(self) -> None:
        if (
            self.variant not in VARIANTS
            or self.preparation not in PREPARATIONS
            or self.protein_residues != 916
            or self.physical_biological_units != 0
            or not 6000 <= self.observed_heavy_atom_count <= 7500
        ):
            raise ValueError("M1 reconstruction changes its explicit approximation")
        validate_sha256(self.source_sha256)
        validate_sha256(self.coordinate_sha256)


def reconstruct_coordinates(
    structure: bytes,
    reference: bytes,
    variant: str,
    preparation: str,
) -> tuple[bytes, ReconstructionAuditV1]:
    """Map measured heavy atoms; Amber subsequently supplies missing atoms.

    The synthetic output numbering preserves original protein positions and
    assigns each ligand/metal to its covalently associated active-site chain.
    """
    from Bio.Data.PDBData import protein_letters_3to1
    from Bio.PDB.MMCIF2Dict import MMCIF2Dict
    from openmm import app, unit  # type: ignore[import-untyped]

    if (
        sha256(structure).hexdigest() != STRUCTURE_SHA256
        or sha256(reference).hexdigest() != REFERENCE_SHA256
        or variant not in VARIANTS
        or preparation not in PREPARATIONS
    ):
        raise ValueError("M1 structure, reference or assigned preparation differs")
    sequence = "".join(reference.decode("ascii").splitlines()[1:])
    if len(sequence) != 466 or sequence[90] != "H" or sequence[99] != "M" or sequence[205] != "D":
        raise ValueError("M1 assay-reference numbering is not established")
    cif = MMCIF2Dict(StringIO(structure.decode("ascii")))  # type: ignore[no-untyped-call]
    occupancy = dict(zip(cif["_atom_site.id"], cif["_atom_site.occupancy"], strict=True))
    pdb = app.PDBxFile(StringIO(structure.decode("ascii")))
    coordinates = pdb.positions.value_in_unit(unit.angstrom)
    chains = list(pdb.topology.chains())
    proteins = [c for c in chains if c.id in ("A", "B")]
    if len(proteins) != 2:
        raise ValueError("M1 requires the original two protein chains")
    carbamates: dict[str, Any] = {}
    for a, b in pdb.topology.bonds():
        if b.residue.name == "LYS":
            a, b = b, a
        if a.residue.name == "LYS" and b.residue.name == "FMT":
            if a.name != "NZ" or a.residue.id != "191" or b.name != "C":
                raise ValueError("Unexpected covalent activation mapping")
            carbamates[a.residue.chain.id] = b.residue
    if set(carbamates) != {"A", "B"}:
        raise ValueError("Both Lys191 carbamates must be covalently identified")
    ligands = [r for r in pdb.topology.residues() if r.name == "RUB"]
    metals = [r for r in pdb.topology.residues() if r.name == "MG"]
    if len(ligands) != 2 or len(metals) != 2:
        raise ValueError("Both RuBP and Mg molecules must be retained")
    lines: list[str] = []
    omitted: list[str] = []
    edits: list[tuple[str, int, str, str]] = []
    sites: list[tuple[str, str, int]] = []
    serial = 0

    def add(
        atom: Any, chain: str, resid: int, residue_name: str, atom_name: str | None = None
    ) -> None:
        nonlocal serial
        if atom.element is None or atom.element.symbol == "H":
            raise ValueError("Original 9RUB must provide only named heavy elements")
        if Decimal(occupancy[atom.id]) == 0:
            omitted.append(f"{atom.residue.chain.id}.{atom.residue.id}.{atom.name}")
            return
        if Decimal(occupancy[atom.id]) != 1:
            raise ValueError("Unspecified partial occupancy alternative")
        serial += 1
        x, y, z = coordinates[atom.index]
        name = atom_name or atom.name
        lines.append(
            f"ATOM  {serial:5d} {name:>4s} {residue_name:3s} {chain}{resid:4d}    "
            f"{x:8.3f}{y:8.3f}{z:8.3f}  1.00  0.00          {atom.element.symbol:>2s}  "
        )

    for chain in proteins:
        kept = [r for r in chain.residues() if 2 <= int(r.id) <= 459]
        if [int(r.id) for r in kept] != list(range(2, 460)):
            raise ValueError("Unexpected internal deletion in the common chain interval")
        for residue in kept:
            number = int(residue.id)
            expected = "D" if number == 91 else sequence[number - 1]
            if protein_letters_3to1.get(residue.name) != expected:
                raise ValueError(f"Unexpected sequence discrepancy at {chain.id}:{number}")
            name = "HIE" if residue.name == "HIS" else residue.name
            if number == 91:
                name = preparation[:3]
            if variant == "M100T" and number == 100:
                name = "THR"
            if variant == "D206E" and number == 206:
                name = "GLU"
            edit = (
                number == 91
                or (variant == "M100T" and number == 100)
                or (variant == "D206E" and number == 206)
            )
            if edit:
                edits.append((chain.id, number, residue.name, name))
            if number == 191:
                name = "KCX"
            for atom in residue.atoms():
                if edit and atom.name not in ("N", "CA", "C", "O", "CB"):
                    continue
                add(atom, chain.id, number, name)
            if number == 191:
                for atom in carbamates[chain.id].atoms():
                    add(
                        atom,
                        chain.id,
                        number,
                        "KCX",
                        {"C": "CX", "O1": "OQ1", "O2": "OQ2"}[atom.name],
                    )
        lines.append("TER")
        # The archived numbering identifies the paired ligand without a
        # coordinate-dependent nearest-neighbor selection.
        ligand_number = "600" if chain.id == "A" else "700"
        ligand = next(r for r in ligands if r.id == ligand_number)
        metal_chain = "D" if chain.id == "A" else "G"
        metal = next(r for r in metals if r.chain.id == metal_chain)
        for residue, number in ((ligand, 600), (metal, 601)):
            for atom in residue.atoms():
                add(atom, chain.id, number, residue.name)
            lines.append("TER")
            sites.append((chain.id, residue.name, number))
    lines.extend(("END", ""))
    output = "\n".join(lines).encode("ascii")
    return output, ReconstructionAuditV1(
        variant,
        preparation,
        STRUCTURE_SHA256,
        sha256(output).hexdigest(),
        916,
        tuple(sorted(omitted)),
        tuple(edits),
        tuple(sites),
        serial,
    )


def isolated_kcx_parameters(
    published_frcmod: bytes,
    published_prep: bytes,
    amber_directory: Path,
) -> tuple[bytes, bytes, tuple[tuple[str, int], ...]]:
    """Retain Amber parameters globally; add only KCX-namespaced keys.

    Mixed peptide-boundary terms use the corresponding base Amber types.
    Fully internal KCX keys then receive the published custom parameters.
    No previously installed protein type or parameter is overwritten.
    """
    from parmed.amber import AmberParameterSet  # type: ignore[import-untyped]

    base = AmberParameterSet(
        str(amber_directory / "dat/leap/parm/parm10.dat"),
        str(amber_directory / "dat/leap/parm/frcmod.ff14SB"),
    )
    custom = AmberParameterSet(StringIO(published_frcmod.decode("ascii")))
    if set(custom.atom_types) != set(KCX_TYPES):
        raise ValueError("Published KCX type inventory differs")
    out = AmberParameterSet()
    for original, renamed_type in KCX_TYPES.items():
        atom_type = deepcopy(custom.atom_types[original])
        atom_type.name = renamed_type
        out.atom_types[renamed_type] = atom_type
    counts = []
    for field in ("bond_types", "angle_types", "dihedral_types", "improper_periodic_types"):
        target = getattr(out, field)
        for key, value in getattr(base, field).items():
            choices = [
                (token, KCX_TYPES[token]) if token in KCX_TYPES else (token,) for token in key
            ]
            for renamed in product(*choices):
                if renamed != key:
                    target[renamed] = deepcopy(value)
        for key, value in getattr(custom, field).items():
            renamed = tuple(KCX_TYPES.get(token, token) for token in key)
            target[renamed] = deepcopy(value)
        if any(not any(token in KCX_TYPES.values() for token in key) for key in target):
            raise ValueError("KCX parameter expansion overwrites an ordinary protein term")
        counts.append((field, len(target)))
    buffer = StringIO()
    out.write(
        buffer, title="M1 isolated KCX; published internal terms and Amber peptide boundaries"
    )
    parameter_bytes = buffer.getvalue().encode("ascii")
    if len(parameter_bytes) > 4 * 1024**2:
        raise ValueError("KCX parameter expansion exceeds its bound")
    lines = []
    charge = Decimal(0)
    names = []
    for line in published_prep.decode("ascii").splitlines():
        tokens = line.split()
        if len(tokens) == 11 and tokens[0].isdigit() and tokens[2] != "DU":
            if tokens[2] not in KCX_TYPES:
                raise ValueError("Unspecified KCX residue atom type")
            tokens[2] = KCX_TYPES[tokens[2]]
            charge += Decimal(tokens[-1])
            names.append(tokens[1])
            line = "  ".join(tokens)
        lines.append(line)
    if len(names) != 23 or len(set(names)) != 23 or abs(charge + 1) > Decimal("0.00001"):
        raise ValueError("KCX atom or charge census differs")
    return parameter_bytes, ("\n".join(lines) + "\n").encode("ascii"), tuple(counts)


def leap_commands() -> bytes:
    """Closed native command roster; captured loader text is never executed."""
    return b"""source leaprc.protein.ff14SB
source leaprc.water.tip3p
addAtomTypes {
 { "kN" "N" "sp2" } { "kT" "C" "sp3" } { "kC" "C" "sp2" }
 { "kQ" "O" "sp2" } { "k1" "H" "sp3" } { "kH" "H" "sp3" }
 { "kh" "H" "sp3" } { "kO" "O" "sp2" }
 { "c3" "C" "sp3" } { "c" "C" "sp2" } { "os" "O" "sp3" }
 { "o" "O" "sp2" } { "oh" "O" "sp3" } { "p5" "P" "sp3" }
 { "h1" "H" "sp3" } { "ho" "H" "sp3" }
}
loadAmberParams kcx-isolated.frcmod
loadAmberPrep kcx-isolated.prepin
loadAmberParams rubp.frcmod
loadAmberPrep rubp.prepi
model = loadPdb reconstructed.pdb
check model
solvateBox model TIP3PBOX 10.0
addIons model Na+ 0
addIons model Cl- 0
check model
saveAmberParm model prepared.prmtop prepared.inpcrd
quit
"""
