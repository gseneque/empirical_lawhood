"""Bounded native-free provenance arithmetic on authenticated retained bytes."""
from __future__ import annotations
import ast
import base64
from collections import defaultdict
from decimal import Decimal
from hashlib import sha256
import importlib.abc
import io
from itertools import product
import json
import math
from pathlib import Path
import re
import resource
import stat
import struct
import sys
import time
import zipfile

class NoNative(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname.split('.')[0] in {'numpy','scipy','parmed','openmm','simtk','ash','geometric','pyscf','Bio'}:
            raise ImportError('native/optional science imports forbidden')
        return None
sys.meta_path.insert(0,NoNative())
ROOT=Path(__file__).parent
CORE=Path('/tmp/empirical-lawhood-rubisco-20261009/public-inputs/followup-rr-amber-core-v1')
V3=Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution/rr-qmmm-retained-reference-v3')
PARENT=Path('/home/chevre/gs-ml/icf-yolo-rubisco-r02s-20260925/src/icf_yolo/adapters/simulators/rubisco_m1_v5')
ENVELOPE=Path('/media/chevre/SEMIOS/icf-yolo/programmes/rubisco-el/r02s-m1-pilot-v5/runs/rubisco-r02s-m1-native-v5.pilot.production/outputs/rubisco-r02s-m1-native-v5.native-protocol/native-result.canonical.json')
MIB=1024**2
START=time.monotonic();resource.setrlimit(resource.RLIMIT_CPU,(120,120));resource.setrlimit(resource.RLIMIT_AS,(2*1024*MIB,)*2)
inputs=[]

def need(value,message):
    if not value:raise ValueError(message)

def read(path,maximum=8*MIB,expected=None):
    path=Path(path);need(path.is_file() and not path.is_symlink() and path.stat().st_size<=maximum,'bounded original member')
    raw=path.read_bytes();h=sha256(raw).hexdigest()
    if expected is not None:need(h==expected,'original member identity differs: '+str(path))
    inputs.append({'path':str(path),'bytes':len(raw),'sha256':h})
    return raw

def j(path,**kwargs):return json.loads(read(path,**kwargs))
def emit(name,value):
    raw=(json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode();need(len(raw)<=8*MIB,'bounded observation')
    with (ROOT/name).open('xb') as f:f.write(raw)
    return {'name':name,'bytes':len(raw),'sha256':sha256(raw).hexdigest()}

def flags(raw,wanted):
    out={};current=None;width=None
    for line in raw.decode('ascii').splitlines():
        if line.startswith('%FLAG '):current=line[6:].strip();continue
        if line.startswith('%FORMAT('):
            match=re.fullmatch(r'%FORMAT\(\d+([a-zA-Z])(\d+)(?:\.\d+)?\)',line)
            need(match is not None,'fixed width Amber flag format');width=int(match[2]);continue
        if line.startswith('%') or current not in wanted:continue
        need(width is not None,'source flag width')
        out.setdefault(current,[]).extend(line[i:i+width].strip() for i in range(0,len(line),width) if line[i:i+width].strip())
    need(set(out)==set(wanted),'complete selected native flags')
    return out

def exclusions(tokens,natoms,retain):
    counts=list(map(int,tokens['NUMBER_EXCLUDED_ATOMS']));values=list(map(int,tokens['EXCLUDED_ATOMS_LIST']));need(len(counts)==natoms and sum(counts)==len(values),'full native exclusion denominator')
    cursor=0;pairs=set()
    for i,n in enumerate(counts):
        for value in values[cursor:cursor+n]:
            need(0<=value<=natoms,'native exclusion range')
            if value and i<retain and value-1<retain: pairs.add(tuple(sorted((i,value-1))))
        cursor+=n
    return pairs

def inpcrd(raw):
    lines=raw.decode('ascii').splitlines();n=int(lines[1].strip());need(n==116767,'whole original coordinate denominator')
    tokens=[line[i:i+12] for line in lines[2:] for i in range(0,len(line),12) if line[i:i+12].strip()]
    need(len(tokens)==3*n+6,'complete source coordinate fields/box')
    xyz=[tuple(float(x) for x in tokens[3*i:3*i+3]) for i in range(n)]
    need(all(math.isfinite(v) for row in xyz for v in row),'finite original coordinate tokens')
    return xyz,{'atom_count':n,'full_coordinate_fields':3*n,'box_tokens':tokens[3*n:]}

def npy(raw,n):
    need(raw[:6]==b'\x93NUMPY' and raw[6:8]==b'\x01\x00','selected original NPY grammar')
    size=struct.unpack('<H',raw[8:10])[0];header=ast.literal_eval(raw[10:10+size].decode('ascii'))
    need(header=={'descr':'<f8','fortran_order':False,'shape':(n,3)},'native source NPY dtype/order/shape')
    payload=raw[10+size:];need(len(payload)==n*3*8,'complete native source NPY byte denominator')
    xyz=[tuple(10*v for v in row) for row in struct.iter_unpack('<ddd',payload)]
    need(all(math.isfinite(v) for row in xyz for v in row),'finite archived coordinates')
    return xyz,{'header':header,'native_unit':'nm per producing source','observation_unit':'Angstrom; native source float times10','atoms':n}

def pdb(raw):
    rows=[]
    for line in raw.decode('ascii').splitlines():
        if line.startswith(('ATOM  ','HETATM')):
            rows.append({'atom':line[12:16].strip(),'component':line[17:20].strip(),'chain':line[21],'residue':int(line[22:26]),'coordinates':tuple(float(line[a:b]) for a,b in [(30,38),(38,46),(46,54)]),'element':line[76:78].strip()})
    need(len(rows)==len({(r['chain'],r['residue'],r['atom']) for r in rows}),'unique reconstructed atom names')
    return rows

def contacts(xyz,excluded=(),types=None,lookup=None,acoef=None,bcoef=None):
    """Every unordered r<.75 pair is in the27 neighbor cells; no sampling."""
    size=.75;cells=defaultdict(list);pairs=[];candidate=distance=excluded_candidates=zeroA=0
    for i,row in enumerate(xyz):cells[tuple(math.floor(v/size) for v in row)].append(i)
    for i,row in enumerate(xyz):
        cell=tuple(math.floor(v/size) for v in row)
        for delta in product((-1,0,1),repeat=3):
            key=tuple(x+d for x,d in zip(cell,delta,strict=True))
            for k in cells.get(key,()):
                if k>=i:continue
                candidate+=1;pair=(k,i)
                if pair in excluded:excluded_candidates+=1;continue
                distance+=1;ds=sum((v-w)**2 for v,w in zip(row,xyz[k],strict=True))
                if ds>=size*size:continue
                entry={'indices_0based':[k,i],'distance_angstrom':math.sqrt(ds),'nonexcluded':True}
                if types is not None:
                    ix=lookup[(types[k]-1)*25+types[i]-1]-1
                    A=acoef[ix];B=bcoef[ix];entry.update(source_types_1based=[types[k],types[i]],source_AB_index_1based=ix+1,source_A=A,source_B=B)
                    if A>0:
                        radius=math.sqrt(ds);entry['source_LJ_kcal_per_mol']=A/radius**12-B/radius**6
                    else:zeroA+=1
                pairs.append(entry)
    return {'atom_denominator':len(xyz),'all_unordered_pairs':len(xyz)*(len(xyz)-1)//2,'grid_cell_width_angstrom':size,'grid_neighbor_cells':27,'strict_selected_distance_angstrom':size,'grid_candidate_pairs':candidate,'excluded_candidate_pairs':excluded_candidates,'actual_nonexcluded_distance_comparisons':distance,'near_contact_denominator':len(pairs),'near_contacts_with_zero_source_A':zeroA,'pairs':sorted(pairs,key=lambda p:p['indices_0based'])}

inspection=j(CORE/'source-inspection-v1a.json',expected='6ef61c8e0d07bf4bd7d37ba34062a497cc961aa4f0490fe91dc5b7251713058e')
core=j(CORE/'dry-core-source-projection-v1a.json',expected='bfbaa57a1b9d466e311c23c37616cd54771ac170d7fc361ef7769a4004040c5f')
core_register=j(CORE/'rr-amber-core-register-v1.json',expected='a6deb1386faa51e39669208fecb79a68a859888f60c6fcfaf689cfbc8c1c3ec1')
for row in core_register['registered_members_excluding_self']:
    raw=read(CORE/row['name']);need(len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],'complete closed core byte census')
raw=read(ENVELOPE,64*MIB,'8dbc9e528e341cee554128bcedc9876f2f3141c2e4b62a22b737f9b5bcef855a')
envelope=json.loads(raw);archive=base64.b64decode(envelope['value']['prepared_archive_base64'],validate=True)
need(len(archive)==41295643 and sha256(archive).hexdigest()=='a22c4fb687e88ff36d92d06378f3b3176b565fd1281b83cccad52454b0f1a653','whole original42 member archive identity')
z=zipfile.ZipFile(io.BytesIO(archive));roster={row['name']:row for row in inspection['archive']['census']};need(set(z.namelist())==set(roster) and len(roster)==42,'complete original archive denominator')
selected={};archive_census=[]
for info in z.infolist():
    raw=z.read(info.filename);row=roster[info.filename];need(len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],'all original member length/CRC/hash')
    archive_census.append({'name':info.filename,'bytes':len(raw),'sha256':row['sha256'],'CRC_verified_by_zipfile':True})
    if info.filename.startswith('WT-HID91/') or info.filename.startswith('WT-HIE91/'):selected[info.filename]=raw
emit('authenticated-parent-archive-census.json',{'envelope':inputs[-1],'archive_bytes':len(archive),'archive_sha256':sha256(archive).hexdigest(),'expanded_bytes':sum(row['bytes'] for row in archive_census),'members':archive_census})
want={'POINTERS','ATOM_NAME','RESIDUE_LABEL','RESIDUE_POINTER','ATOM_TYPE_INDEX','NUMBER_EXCLUDED_ATOMS','EXCLUDED_ATOMS_LIST','NONBONDED_PARM_INDEX','LENNARD_JONES_ACOEF','LENNARD_JONES_BCOEF','BONDS_INC_HYDROGEN','BONDS_WITHOUT_HYDROGEN'}
originalflags=flags(selected['WT-HID91/prepared.prmtop'],want)
n=int(originalflags['POINTERS'][0]);need(n==116767,'authentic original full topology116767')
types=list(map(int,originalflags['ATOM_TYPE_INDEX'][:13828]));lookup=list(map(int,originalflags['NONBONDED_PARM_INDEX']));A=list(map(float,originalflags['LENNARD_JONES_ACOEF']));B=list(map(float,originalflags['LENNARD_JONES_BCOEF']))
need(len(lookup)==625 and len(A)==len(B)==325,'full source25 type table slots')
old_ex=exclusions(originalflags,n,13828);oldcoords,coordmetadata=inpcrd(selected['WT-HID91/prepared.inpcrd'])
need(all(tuple(Decimal(str(v)) for v in row)==tuple(Decimal(v) for v in source[10:13]) for row,source in zip(oldcoords[:13828],core['atoms'],strict=True)),'all13828 original native coordinate tokens join exact core')
need(originalflags['ATOM_NAME'][:13828]==[a[2] for a in core['atoms']] and types==[a[6] for a in core['atoms']],'all13828 original atom names/types join core exactly')
reconstructed=pdb(selected['WT-HID91/reconstructed.pdb']);relaxed,relaxmetadata=npy(selected['WT-HID91/relaxed.npy'],n)
reconstruction_byid={(a['chain'],a['residue'],a['atom']):a for a in reconstructed}
residues={row[0]:row for row in core['residues']}
for a in core['atoms']:
    a.append({'chain':residues[a[1]][4],'residue':residues[a[1]][5],'component':residues[a[1]][1]})
# Native deposited records include zero-occupancy rows; positive records only
# provide the original observed heavy-geometry screen, not a full new topology.
mapping=j(CORE/'9RUB-native-atom-mapping-original.json',expected='caa36c34be4eb61cc6b804e6130f4e0845b27f95fa74117db02229ac5d787985')
columns=mapping['CIF_atom_site_columns_in_source_order_then_PDB_witnesses'];native=[dict(zip(columns,row,strict=True)) for row in mapping['rows']]
positive=[r for r in native if Decimal(r['occupancy'])>0];nativecoords=[tuple(float(r[a]) for a in ['Cartn_x','Cartn_y','Cartn_z']) for r in positive]
translation=list(map(float,core['inherited_coordinate_translation_angstrom']))
reconstructed_inherited=0;reconstruction_deltas=[]
for i,atom in enumerate(core['atoms']):
    key=(atom[-1]['chain'],atom[-1]['residue'],atom[2])
    if key in reconstruction_byid:
        src=reconstruction_byid[key];d=[oldcoords[i][axis]-src['coordinates'][axis]-translation[axis] for axis in range(3)]
        if max(map(abs,d))<=1e-7:reconstructed_inherited+=1
        else:reconstruction_deltas.append({'physical_atom_1based':i+1,'identity':key,'delta_from_source_translation':d})
# Complete held plan and actual force witnesses are authenticated by v3 census.
v3census=j(V3/'closed-census.json',expected='92c6c63cc5dad115cdf2e8e34cd129e82bc6cad2fd4ab006370201a3c5efaaa3')
for row in v3census['members_excluding_self']:
    raw=read(V3/row['name'],16*MIB);need(len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],'complete v3 physical byte census')
plan_join=j(V3/'retained-plan/original-join.json');parts=[]
for i,row in enumerate(plan_join['ordered_chunks']):
    raw=read(V3/'retained-plan'/f'plan.part-{i:04d}');need(len(raw)==row['bytes'] and sha256(raw).hexdigest()==row['sha256'],'held plan source chunks')
    parts.append(raw)
planraw=b''.join(parts);need(len(planraw)==plan_join['whole_bytes'] and sha256(planraw).hexdigest()==plan_join['whole_sha256'],'whole heldplan identity');plan=json.loads(planraw)
held=[tuple(map(float,row[2])) for row in plan['physical_atoms']];need(len(held)==13828,'whole held physical denominator')
changed=[{'index_0based':i,'physical_atom_id':plan['physical_atoms'][i][0],'identity':core['atoms'][i][-1],'source_name':core['atoms'][i][2],'held_name':plan['physical_atoms'][i][6],'old':oldcoords[i],'held':held[i],'displacement_angstrom':math.dist(oldcoords[i],held[i])} for i in range(13828) if oldcoords[i]!=held[i]]
rawderived=read(V3/'retained-preparation/derived.prmtop');derivedflags=flags(rawderived,want);need(int(derivedflags['POINTERS'][0])==13828,'whole derived topology13828')
derived_ex=exclusions(derivedflags,13828,13828)
rawforces=[]
for stage in ('before-ash-masks','after-ash-masks'):
    join=j(V3/'reference-work/native-force-observations'/(stage+'.join.json'));pieces=[read(V3/'reference-work/native-force-observations'/row['name']) for row in join['ordered_chunks']];raw=b''.join(pieces)
    need(len(raw)==join['whole_bytes'] and sha256(raw).hexdigest()==join['whole_sha256'],'complete actual force snapshot');rawforces.append(json.loads(raw))
before,after=rawforces;before_ex={tuple(sorted(row)) for row in before['custom_lj']['exclusions']};after_ex={tuple(sorted(row)) for row in after['custom_lj']['exclusions']};need(before_ex==derived_ex,'complete derived excluded pairs match actual nativebefore all sourcepairs')
q=set(plan['real_qm_full_indices_0based']);need(after_ex==derived_ex|{(a,b) for a in q for b in q if a<b},'complete actualpostmask source exclusions unionQM-only')
results={
 'original_native_positive_heavy_geometry':contacts(nativecoords),
 'reconstructed_source_heavy_geometry':contacts([a['coordinates'] for a in reconstructed]),
 'original_parent_prepared_dry':contacts(oldcoords[:13828],old_ex,types,lookup,A,B),
 'held_reactive_reference':contacts(held,after_ex,types,lookup,A,B),
 'archived_parent_relaxed_dry':contacts(relaxed[:13828],old_ex,types,lookup,A,B),
}
for key,val in results.items():
    if key.endswith('geometry'):continue
    for pair in val['pairs']:
        pair['identities']=[core['atoms'][i][-1]|{'atom':core['atoms'][i][2],'geometry_origin':core['atoms'][i][13]} for i in pair['indices_0based']]
        pair['both_fixed_MM']=all(i not in q for i in pair['indices_0based'])
original_pairs=results['original_parent_prepared_dry']['pairs'];held_pairs=results['held_reactive_reference']['pairs']
need([row['indices_0based'] for row in original_pairs]==[row['indices_0based'] for row in held_pairs]==[[1345,10583],[1346,10588],[3674,8258]],'complete severe contact set original and held equal')
traces=[]
for pair in original_pairs:
    a,b=pair['indices_0based'];traces.append({'indices_0based':[a,b],'identities':pair['identities'],'original_source_coordinates':[oldcoords[a],oldcoords[b]],'held_reference_coordinates':[held[a],held[b]],'original_distance_angstrom':math.dist(oldcoords[a],oldcoords[b]),'held_distance_angstrom':math.dist(held[a],held[b]),'relaxed_distance_angstrom':math.dist(relaxed[a],relaxed[b]),'original_excluded':(a,b) in old_ex,'derived_excluded':(a,b) in derived_ex,'actual_before_mask_excluded':(a,b) in before_ex,'actual_after_mask_excluded':(a,b) in after_ex,'present_in_reconstructed_heavy_pdb':[ (core['atoms'][i][-1]['chain'],core['atoms'][i][-1]['residue'],core['atoms'][i][2]) in reconstruction_byid for i in [a,b]]})
h91={chain:[a for a in reconstructed if a['chain']==chain and a['residue']==91] for chain in ['A','B']}
native91=[{k:r[k] for k in ['id','auth_asym_id','auth_seq_id','auth_comp_id','auth_atom_id','type_symbol','occupancy','Cartn_x','Cartn_y','Cartn_z']} for r in native if r['auth_asym_id'] in ['A','B'] and r['auth_seq_id']=='91']
relaxation=json.loads(selected['WT-HID91/relaxation.json']);oldcases=envelope['value'].get('cases',[])
parent_sources=[]
for name,expected in [('preparation.py','90f98f2a0888ba30b7d3e9b6510c41f522585ad8e59bcf578fda406560215fa0'),('native.py','808c461ab657e3385e8a72b596bd1f8d9d16e84193ff591c3b7d5df9fe7d1ad5')]:
    b=read(PARENT/name,expected=expected);parent_sources.append(inputs[-1]);
    with (ROOT/('parent-v5-'+name)).open('xb') as f:f.write(b)
source_search=[]
for worktree in ['/home/chevre/gs-ml/icf-yolo','/home/chevre/gs-ml/icf-yolo-rubisco-r02s-20260922','/home/chevre/gs-ml/icf-yolo-rubisco-r02s-20260925']:
    for p in sorted((Path(worktree)/'src/icf_yolo/adapters/simulators').glob('rubisco*/preparation.py')):
        b=read(p);s=b.decode();source_search.append({'file':inputs[-1],'H91_repair_deletes_existing_sidechain':('number == 91' in s and 'atom.name not in ("N", "CA", "C", "O", "CB")' in s),'local_clash_admission_present':any(t in s.lower() for t in ['clash','overlap','steric'])})
bodycost={'CPU_seconds':time.process_time(),'wall_seconds':time.monotonic()-START,'measurement_scope':'native-free diagnostic process body before report/source closure; full outer resource file includes startup/tail. Prior reading and final closure tails separately unknown.'}
report={'role':'NATIVE_FREE_SOURCE_PROVENANCE_DIAGNOSIS_NOT_NEW_MOLECULAR_RESULT','status':'DEFECT_LOCALIZED_TO_INHERITED_PARENT_PRE_RELAXATION_H91_COMPLETION','selected_hypotheses':[
 {'id':'H1','claim':'Inherited parent H91 reconstruction/pre-relaxation defect','disposition':'SUPPORTED','evidence':'All three severe positive-LJ fixed-MM contacts already occur byte-identically in original parent prepared.inpcrd dry core. Deposited 9RUB Asp91 sidechains are intentionally removed; reconstructed HID/HIE skeleton retains only N/CA/C/O/CB and parent Amber fills the ring. Native source archive includes later whole-system minimization and relaxed.npy; EL core deliberately selected pre-relaxation coordinates.'},
 {'id':'H2','claim':'EL coordinate or atom-index mapping mismatch','disposition':'REFUTED_FOR_COMPLETE13828_SOURCE_JOIN_AND_REPORTED_CONTACTS','evidence':'All13828 original coordinate/name/type rows join core exactly; held changes are fully enumerated and do not touch the three contact atoms. Source atom identity/chain joins and observed original contacts persist.'},
 {'id':'H3','claim':'Derived topology/donor/chain reconstruction defect creates these contacts','disposition':'REFUTED_FOR_REPORTED_CONTACTS_AND_FULL_SEVERE_CONTACT_DENOMINATOR','evidence':'Derived/native pre-mask exclusions match completely; postmask adds onlyQM-QM pairs. Critical atoms were not donor target B287 nor active/QM atoms. Complete original/held severe contact sets are identical.'}],
 'source_inputs':inputs,'authenticated_archive_member_census':'authenticated-parent-archive-census.json','original_full_source_atoms':n,'retained_dry_atoms':13828,'original_native_heavy_mapping_rows':len(native),'native_positive_occupancy_heavy_rows':len(positive),'reconstructed_heavy_rows':len(reconstructed),'prepared_core_source_join_exact':True,'native_inherited_heavy_join':{'7028_exact_rigid_translation_claim_preserved_from_authentic_core':core['inherited_native_heavy_count'],'reconstructed_rows_matching_source_translation':reconstructed_inherited,'reconstruction_mapping_disagreements':reconstruction_deltas},
 'complete_contact_denominators':results,'three_contact_stage_traces':traces,'complete_held_vs_parent_coordinate_changes':changed,'exclusion_provenance':{'source_original_pairs':len(old_ex),'source_derived_pairs':len(derived_ex),'actual_before_pairs':len(before_ex),'actual_after_pairs':len(after_ex),'original_to_derived_removed_pairs':sorted(old_ex-derived_ex),'original_to_derived_added_pairs':sorted(derived_ex-old_ex),'full_native_before_matches_derived':True,'full_native_after_exactQM_union':True},
 'H91_D91_construct_conflict':{'native_deposited_atom_rows':native91,'reconstructed_H91_skeleton':h91,'P04718_H91_reference_choice':'Declared computational reconstruction; native deposited Asp91 and assay-reference His91 are distinct source/construct choices. Neither is a certified Liggins His6WT or H287 own-WT assay parent. A source-correction decision must keep those identities explicit.'},
 'archived_relaxed_geometry':{'metadata':relaxmetadata,'source_member_sha256':sha256(selected['WT-HID91/relaxed.npy']).hexdigest(),'relaxation_record':relaxation,'source_producing_operation':'existing parent whole-solvated-system LocalEnergyMinimizer,500maxiterations per strengths1000/100/0; PME/0.9nm cutoff/HBond constraints. Source only; no native force/convergence reassessment.','native_input_stage':'prepared.inpcrd is before minimization; relaxed.npy is separately archived and actual parent native path uses it before warmup/sampling.','reuse_limit':'Existing exact relaxed coordinates may support a separately selected source/preparation comparison; replacing the current immutable fixed coordinates or assuming reactive/species qualification is not an authorized correction here. Different solvent/boundary/constraint model and all changed coordinates require a new source and scientific protocol.'},
 'parent_source_search':source_search,'bound_parent_v5_source_files':parent_sources,'coordinate_metadata':coordmetadata,'native_effects':{'optional_native_imports':0,'contexts':0,'solvers':0,'optimizers':0,'new_native_processes':0,'new_chemical_constructors':0,'fits':0,'acquisition':0},'body_resources':bodycost,
 'disposition':'PARK_CURRENT_REFERENCE; evidenced inherited preparation/selection problem, no ad-hoc coordinate/exclusion patch or native continuation. Reopening requires an explicit source-domain construct choice and bounded physically justified common preparation, with complete source/exclusion/geometry conformance and rejected-return custody.'}
emit('observation.json',report)
print(json.dumps({'status':report['status'],'original_severe_contacts':len(original_pairs),'held_severe_contacts':len(held_pairs),'archived_relaxed_severe_contacts':results['archived_parent_relaxed_dry']['near_contact_denominator'],'original_to_held_changed_coordinate_atoms':len(changed),'contact_relaxed_distances':[p['relaxed_distance_angstrom'] for p in traces],'CPU_body_seconds':bodycost['CPU_seconds'],'wall_body_seconds':bodycost['wall_seconds']}))
