"""Close an ordinary diagnostic packet; no scientific custody authority."""
from hashlib import sha256
import json
from pathlib import Path
import re
import time
ROOT=Path(__file__).parent
records=[]
for p in sorted(ROOT.glob('*resource*.txt')):
    text=p.read_text()
    def value(label):
        match=re.search(r'^\s*'+re.escape(label)+r': (\S+)',text,re.M)
        return float(match.group(1)) if match else None
    user=value('User time (seconds)');system=value('System time (seconds)')
    records.append({'name':p.name,'bytes':p.stat().st_size,'sha256':sha256(p.read_bytes()).hexdigest(),'CPU_seconds':user+system if user is not None and system is not None else None,'user_seconds':user,'system_seconds':system,'exit_status':value('Exit status')})
summary={'role':'SOFTWARE_PROVENANCE_DIAGNOSTIC_RESOURCES_NOT_NATIVE_SCIENCE','processes':records,'complete_outer_CPU_seconds':sum(r['CPU_seconds'] for r in records),'measurement_denominator':'Six selected diagnostic process outer startup-to-exit windows only; earlier source reading and closure engineering costs unmeasured. Native effects all zero. No root window reset.'}
(ROOT/'resource-summary.json').write_bytes((json.dumps(summary,sort_keys=True,indent=2)+'\n').encode())
rows=[]
for p in sorted(ROOT.iterdir()):
    if p.is_symlink() or not p.is_file():raise ValueError('only bounded ordinary regular diagnostic members')
    b=p.read_bytes()
    if len(b)>8*1024**2:raise ValueError('member bound')
    rows.append({'name':p.name,'bytes':len(b),'sha256':sha256(b).hexdigest()})
register={'schema':'ordinary-complete-source-provenance-register-v1','role':'SOURCE_PROVENANCE_SOFTWARE_AUDIT_NOT_ARTIFACTPLANE','status':'PASS_WITH_RETAINED_SOFTWARE_REFUSALS','native_effects':0,'members_excluding_self':rows,'physical_files_including_self':len(rows)+1,'physical_bytes_including_self':0,'maximum_bytes':16*1024**2}
for _ in range(20):
    raw=(json.dumps(register,sort_keys=True,indent=2)+'\n').encode(); total=sum(r['bytes'] for r in rows)+len(raw)
    if register['physical_bytes_including_self']==total:break
    register['physical_bytes_including_self']=total
else:raise ValueError('fixed point')
if total>register['maximum_bytes']:raise ValueError('packet bound')
with (ROOT/'closed-register.json').open('xb') as f:f.write(raw)
for r in rows:
    p=ROOT/r['name'];b=p.read_bytes()
    if len(b)!=r['bytes'] or sha256(b).hexdigest()!=r['sha256']:raise ValueError('closure hash')
    p.chmod(0o444)
(ROOT/'closed-register.json').chmod(0o444);ROOT.chmod(0o555)
print(json.dumps({'status':register['status'],'physical_files':len(rows)+1,'physical_bytes':total,'register_sha256':sha256(raw).hexdigest(),'observation_sha256':sha256((ROOT/'observation.json').read_bytes()).hexdigest(),'supplement_sha256':sha256((ROOT/'supplement-observation-v4.json').read_bytes()).hexdigest(),'measured_outer_CPU_seconds':summary['complete_outer_CPU_seconds']}))
