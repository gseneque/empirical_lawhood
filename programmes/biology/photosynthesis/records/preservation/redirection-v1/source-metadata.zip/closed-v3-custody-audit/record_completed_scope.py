"""Seal exact completed read-only audit scope after optional checker refusal."""
from decimal import Decimal, localcontext
from hashlib import sha256
import json
from pathlib import Path
import stat

AUDIT=Path('/tmp/rubisco-qmmm-retained-reference-independent-audit-v3')
ROOT=Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution/rr-qmmm-retained-reference-v3')
HELPERS=Path('/tmp/rubisco-qmmm-reference-from-retained-v3')

def raw(p):
    p=Path(p)
    if p.is_symlink() or not p.is_file():raise ValueError('regular original source required')
    return p.read_bytes()

def j(p):return json.loads(raw(p))
def binding(p):
    b=raw(p);return {'path':str(p),'bytes':len(b),'sha256':sha256(b).hexdigest()}
def timefile(p):return dict(line.split('=',1) for line in raw(p).decode().splitlines() if '=' in line)

config=j(HELPERS/'execution-config-v3.json');summary=j(ROOT/'measured-summary.json')
worker=j(ROOT/'reference-work/worker-report.json');reference=j(ROOT/'reference-work/reference-observations/reference-report.json')
files=[p for p in ROOT.rglob('*') if p.is_file()]
assert len(files)==177 and sum(p.stat().st_size for p in files)==89852484
assert len(list(ROOT.rglob('*.manifest.json')))==25
assert all(stat.S_IMODE(p.stat().st_mode)==0o444 for p in files)
source=j(config['retained_reload_witness']['path']);c4root=ROOT/'reference-work/source-table-control';c4=j(c4root/'source-table-control-report.json')
with localcontext() as ctx:
    ctx.prec=80
    index=source['native_lj_tables']['NONBONDED_PARM_INDEX'][1]-1
    A=Decimal(str(source['native_lj_tables']['LENNARD_JONES_ACOEF'][index]))*Decimal('4.184')*Decimal('.1')**12
    B=Decimal(str(source['native_lj_tables']['LENNARD_JONES_BCOEF'][index]))*Decimal('4.184')*Decimal('.1')**6
    errors=[];energies=[];forces=[]
    for label,r in [('baseline',Decimal('.4')),('minus',Decimal('.399999')),('plus',Decimal('.400001'))]:
        v=j(c4root/(label+'-unverified-native-return-tokens.json'))
        e=Decimal(v['energy_kj_per_mol_token']);f=[[Decimal(x) for x in row] for row in v['forces_kj_per_mol_nm_tokens']]
        de=-12*A/r**13+6*B/r**7
        expectations=[(e,A/r**12-B/r**6),(f[0][0],de),(f[1][0],-de),*((x,Decimal(0)) for row in f for x in row[1:])]
        errors.extend(abs(x-y)/max(Decimal(1),abs(x),abs(y)) for x,y in expectations)
        energies.append(e);forces.append(f)
    derivative=(energies[2]-energies[1])/Decimal('.000002');fderror=abs(derivative+forces[0][1][0])/max(Decimal(1),abs(derivative),abs(forces[0][1][0]))
    assert max(errors)<=Decimal('1e-10') and fderror<=Decimal('1e-8')
    c4errors={'maximum_source_analytic_scaled_error':str(max(errors)),'central_FD_scaled_error':str(fderror)}
outer=timefile(HELPERS/'outer-resource-v3.txt');cpu=Decimal(outer['user_cpu_seconds'])+Decimal(outer['system_cpu_seconds']);wc=Decimal(str(summary['process']['complete_waited_worker_cpu_seconds'])).quantize(Decimal('.000001'));pc=cpu-wc
old=config['old_cost_and_exposure']
roots=[]
for text in config['cumulative_directories']:
    p=Path(text);rs=[q for q in p.rglob('*') if q.is_file()];roots.append({'root':text,'files':len(rs),'bytes':sum(q.stat().st_size for q in rs)})
assert len(roots)==38 and sum(row['bytes'] for row in roots)==787643240 and sum(row['files'] for row in roots)==3426
stderr=raw(AUDIT/'verification-stderr-final.txt').decode()
assert 'line 480' in stderr and 'initial full source geometry no optimizer displacement' in stderr
# Actual executed final source is sequential: all required custody/cost/table/C4
# assertions and raw plan/capture/ack joins precede this extra exact-coordinate
# assertion. Neither successful gradient parsing nor final audit PASS is claimed.
final_source=raw(AUDIT/'audit-final.py').decode();failure_line=final_source.splitlines()[479]
assert 'initial full source geometry no optimizer displacement' in failure_line
checks={'required_packet_byte_mode_census':'PASS','actual_existing_ExternalArtifactPlane_verify_manifest_calls_current':25,'actual_closed_ancestor_sets_verified':11,'selected_source_archive_members_exact_bytes_verified':2464,'complete_reached_raw_members_verified':51,'raw_coverage_partition':{'new-genuine-closure-archive-member':34,'existing-genuine-callback-raw-ZIP-member':15,'byte-identical-existing-genuine-publication':2},'complete_resource_ledger_reconciled':'PASS','complete625_source_table_pairs_each_stage_and_masks':'PASS','C4_live_matrix_and_three_source_energy_force_oracles':'PASS','single_callback_plan_raw_input_capture_and_ack_bytejoins':'PASS','optional_exact_all_initial_physical_coordinates':'CHECKER_REFUSED; all fixed exact, active coordinates allow an optimizer conversion roundoff','following_independent_native_gradient_parse':'UNEXECUTED'}
report={'role':'ORDINARY_INDEPENDENT_COMPLETED_CUSTODY_COST_AND_C4_AUDIT_NOT_NEW_SCIENCE','status':'REQUIRED_CLOSURE_CHECKS_PASS_WITH_EXTRA_CHECKER_REFUSAL','full_extended_checker_pass':False,'actual_method':'Own final audit-final.py invoked genuine existing ArtifactPlane and all sequential required assertions before an inapplicable optional exact-active-coordinate assumption. No scientific producer/helper or native module imported/called. Final failure and both predecessors retained exactly. No further full checker/science execution selected.',
'packet':{'root':str(ROOT),'files':177,'bytes':89852484,'genuine_publications':25,'census':binding(ROOT/'closed-census.json')},'source_config':binding(HELPERS/'execution-config-v3.json'),'scientific_protocol':config['protocol'],'checks':checks,
'C4':{'status':'PASS','native_counters':c4['native_counters'],'independent_repeated_raw_arithmetic':c4errors,'scope':'Isolated source-table representation conformance; not enzyme geometry or rates.'},
'native_outcome':{'status':worker['native_case_status'],'retained_topology_loads':worker['retained_native_topology_loads_observed'],'coupling_attempts':worker['retained_coupling_attempts'],'coupling_returns':worker['retained_couplings_returned'],'method_counters':worker['native_effect_counters'],'callback_reservations':worker['attempted_callback_reservations'],'actual_xtb_processes':worker['native_processes_started'],'accepted_full_physical_results':reference['full_physical_evaluation_returns'],'physical_refusal':reference['refusal'],'fresh_gradient':reference['fresh_full_coupled_gradient'],'uncaptured_total_energy_gradient':'UNIDENTIFIED; native methods returned but physical guard refused before saving returned total operands. Cause cannot be inferred from native callback alone.','internal_native_force_kernel_counts':'UNIDENTIFIED; Context/MM/coupled method counters retained separately.'},
'costs':{'worker_cpu_seconds':str(wc),'complete_parent_cpu_seconds_from_outer':str(pc),'outer_cpu_seconds_rounded':str(cpu),'outer_wall_seconds_rounded':outer['elapsed_seconds'],'prior_worker_cpu_seconds':old['complete_worker_cpu_seconds'],'prior_parent_cpu_seconds':old['complete_parent_cpu_seconds'],'cumulative_worker_cpu_seconds':str(Decimal(old['complete_worker_cpu_seconds'])+wc),'cumulative_parent_cpu_seconds':str(Decimal(old['complete_parent_cpu_seconds'])+pc),'cumulative_outer_cpu_seconds_rounded':str(Decimal(old['complete_outer_cpu_seconds_rounded'])+cpu),'cumulative_callback_reservations':34,'cumulative_actual_coupled_xtb_processes':33,'older_electrostatic_xtb_processes':39,'scope':'Measured native assignment scopes only, separate from this software audit, engineering/acquisition and unmeasured tails.'},
'cumulative_selected_output':{'distinct_roots':len(roots),'files':sum(row['files'] for row in roots),'bytes':sum(row['bytes'] for row in roots),'remaining_to_1GiB':1024**3-sum(row['bytes'] for row in roots),'roots':roots,'this_new_audit_root_scope':'Separate explicitly selected software witness, outside these38 native-output roots; its own complete census is in closed-audit.json.'},
'software_audit_attempts':[{'source':binding(AUDIT/name),'outer_resource':binding(AUDIT/tname),'costs':timefile(AUDIT/tname),'stderr':binding(AUDIT/sname)} for name,tname,sname in [('audit.py','outer-resource.txt','verification-stderr.txt'),('audit-corrected.py','outer-resource-corrected.txt','verification-stderr-corrected.txt'),('audit-final.py','outer-resource-final.txt','verification-stderr-final.txt')]],
'limits':['Required complete custody/cost and independent C4 arithmetic passed; the larger source checker itself refused and is not labelled a full PASS.','Independent native-gradient code after the final optional assertion did not execute. Exact full native captures and process receipts are authenticated; no repeated native solve.','MM/MM SCEE divisors not independently redecoded; original constructor guards remain source witness. Matrix/type/charge/exclusion/ASH bonded masks were independently checked.','No geometry/species/force stationarity/kinetics/EL claim. No full accepted physical returned snapshot exists. No new computation after this audit closure.']}
with (AUDIT/'observation.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':report['status'],'packet_files':177,'packet_bytes':89852484,'actual_plane_current_manifests':25,'C4_source_arithmetic':c4errors,'cumulative_bytes':787643240,'cumulative_worker_cpu':report['costs']['cumulative_worker_cpu_seconds'],'cumulative_parent_cpu':report['costs']['cumulative_parent_cpu_seconds']}))
