"""Read-only custody/cost audit. No producing helper or science API is called."""
from __future__ import annotations

import hashlib
import importlib.abc
import io
import json
import math
import gzip
import re
from pathlib import Path
import resource
import stat
import sys
import time
import zipfile
from decimal import Decimal, localcontext
from fractions import Fraction


class BlockNativeScience(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'ash', 'openmm', 'simtk', 'parmed', 'pyscf', 'geometric'}:
            raise ImportError('native science forbidden in independent custody audit: ' + fullname)
        return None


sys.meta_path.insert(0, BlockNativeScience())
ROOT = Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution/rr-qmmm-retained-reference-v3')
HELPERS = Path('/tmp/rubisco-qmmm-reference-from-retained-v3')
OUT = Path('/tmp/rubisco-qmmm-retained-reference-independent-audit-v3')
CENSUS_SHA = '92c6c63cc5dad115cdf2e8e34cd129e82bc6cad2fd4ab006370201a3c5efaaa3'
CONFIG_SHA = 'a1633431db55b3e466c2618f9bf32c2e47141e60912e99cf8cb6f8b00589d93c'
PROTOCOL_SHA = '96b42f8c322ea7f27e735c58a742801872a710e6e5de31d83a4afc3cf54c7d83'
MIB = 1024 * 1024
START = time.monotonic()
resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
resource.setrlimit(resource.RLIMIT_AS, (4 * 1024 * MIB,) * 2)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def data(path, maximum=32 * MIB):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'nonregular bound source: ' + str(path))
    require(path.stat().st_size <= maximum, 'member bound: ' + str(path))
    return path.read_bytes()


def bound(row, maximum=32 * MIB):
    raw = data(row['path'], maximum)
    require(len(raw) == row['bytes'] and digest(raw) == row['sha256'], 'source digest differs')
    return raw


def regular_files(root):
    require(root.is_dir() and not root.is_symlink(), 'root type')
    result = []
    for path in root.rglob('*'):
        require(not path.is_symlink(), 'symbolic member')
        mode = path.stat().st_mode
        require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), 'special member')
        if stat.S_ISREG(mode):
            result.append(path)
    return tuple(sorted(result))


def safe_name(name):
    p = Path(name)
    require(not p.is_absolute() and '..' not in p.parts and p.as_posix() == name, 'unsafe member')


def check_census(root, expected_sha, expected_files=None, expected_publications=None):
    raw = data(root / 'closed-census.json')
    require(digest(raw) == expected_sha, 'closed census digest')
    census = json.loads(raw)
    rows = census['members_excluding_self']
    names = [r['name'] for r in rows]
    require(len(names) == len(set(names)), 'duplicate census member')
    actual = regular_files(root)
    require({p.relative_to(root).as_posix() for p in actual} == set(names) | {'closed-census.json'}, 'complete census denominator')
    for row in rows:
        safe_name(row['name'])
        bound({**row, 'path': str(root / row['name'])})
    require(all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in actual), 'read-only file mode')
    require(all(stat.S_IMODE(p.stat().st_mode) == 0o555 for p in (root, *[p for p in root.rglob('*') if p.is_dir()])), 'read-only directory mode')
    manifests = tuple(sorted(root.rglob('*.manifest.json')))
    if expected_files is not None:
        require(len(actual) == expected_files, 'selected ancestor file count')
    if expected_publications is not None:
        require(len(manifests) == expected_publications, 'selected ancestor receipt count')
    from empirical_lawhood.infrastructure.artifacts import ExternalArtifactPlane, GuardedExternalRoot, LocalFilesystemInspector
    from empirical_lawhood.infrastructure.task_receipts import decode_artifact_manifest
    from empirical_lawhood.runtime.artifacts import ExternalRootContract
    stored_raw = data(root / 'storage-contract.json')
    stored = json.loads(stored_raw)['value']
    stored['allowed_filesystem_types'] = tuple(stored['allowed_filesystem_types'])
    contract = ExternalRootContract(**stored)
    require(contract.canonical_bytes() == stored_raw, 'authentic typed canonical root contract')
    plane = ExternalArtifactPlane(GuardedExternalRoot(contract, inspector=LocalFilesystemInspector()))
    for p in manifests:
        plane.verify_manifest(decode_artifact_manifest(data(p)))
    return {'root': str(root), 'files': len(actual), 'bytes': sum(p.stat().st_size for p in actual),
            'publications': len(manifests), 'census_sha256': digest(raw)}, census


def join_bytes(path):
    raw = data(path)
    join = json.loads(raw)
    chunks = join['ordered_chunks']
    require(1 <= len(chunks) <= 8, 'bounded chunks')
    parts = []
    for row in chunks:
        relative = row.get('relative', row.get('name'))
        safe_name(relative)
        base = ROOT if 'relative' in row else path.parent
        piece = data(base / relative, 8 * MIB)
        require(len(piece) == row['bytes'] and digest(piece) == row['sha256'], 'chunk digest')
        parts.append(piece)
    result = b''.join(parts)
    require(len(result) == join['whole_bytes'] and digest(result) == join['whole_sha256'], 'whole joined identity')
    return result


def checked_zip(raw, maximum=256 * MIB, count=4096):
    z = zipfile.ZipFile(io.BytesIO(raw))
    infos = z.infolist()
    require(len(infos) <= count and len(infos) == len({i.filename for i in infos}), 'archive census')
    require(sum(i.file_size for i in infos) <= maximum and z.testzip() is None, 'archive expanded bytes/CRC')
    for info in infos:
        safe_name(info.filename)
        require(not info.is_dir() and info.file_size <= 32 * MIB, 'archive member bound')
    return z


def parse_outer(path):
    raw = data(path)
    result = {}
    for line in raw.decode().splitlines():
        if '=' in line:
            k, v = line.split('=', 1)
            result[k] = v
    return result


config_raw = data(HELPERS / 'execution-config-v3.json')
require(digest(config_raw) == CONFIG_SHA, 'frozen configuration identity')
config = json.loads(config_raw)
require(config['scientific_protocol_frozen'] is True, 'frozen assignment')
require(digest(bound(config['protocol'])) == PROTOCOL_SHA, 'frozen scientific protocol')
current, census = check_census(ROOT, CENSUS_SHA, expected_files=177, expected_publications=25)
ancestors = []
for row in config['closed_ancestors']:
    bound(row['census'])
    result, _ = check_census(Path(row['census']['path']).parent, row['census']['sha256'],
                             row['physical_files'], row['publications'])
    ancestors.append({**result, 'label': row['label']})

source_index = json.loads(data(ROOT / 'sources/producing-source-index.json'))
require(source_index['selected_sources'] == config['selected_sources'], 'selected archive source identity')
archive = checked_zip(join_bytes(ROOT / 'sources/producing-code.zip.join.json'))
source_members = source_index['archive_members']
require(len(source_members) == len(config['selected_sources']) == 2464, 'complete source denominator')
require(set(archive.namelist()) == {r['name'] for r in source_members}, 'archive complete roster')
for i, (row, source) in enumerate(zip(source_members, config['selected_sources'], strict=True)):
    raw = bound(source)
    require(row['name'] == f'source-{i:05d}/' + Path(source['path']).name, 'archive ordered source join')
    require(row['bytes'] == len(raw) and row['sha256'] == digest(raw) and archive.read(row['name']) == raw, 'archived original source equality')

coverage = json.loads(data(ROOT / 'raw/complete-physical-source-coverage.json'))
reached = regular_files(ROOT / 'reference-work') + (ROOT / 'worker-stdout.txt', ROOT / 'worker-stderr.txt')
require({r['path'] for r in coverage} == {str(p) for p in reached} and len(coverage) == len(reached) == 51, 'complete reached raw denominator')
archives = {}
coverage_kinds = {}
for row in coverage:
    raw = bound(row)
    c = row['coverage']; kind = c['kind']
    coverage_kinds[kind] = coverage_kinds.get(kind, 0) + 1
    publication = c['publication']
    payload_path = ROOT / publication['relative']
    payload = data(payload_path)
    require(len(payload) == publication['payload_bytes'] and digest(payload) == publication['payload_sha256'], 'genuine raw payload join')
    require(digest(data(Path(str(payload_path) + '.manifest.json'))) == publication['manifest_sha256'], 'raw publication manifest identity')
    if kind == 'byte-identical-existing-genuine-publication':
        require(raw == payload, 'retained bridge exact genuine publication bytes')
    else:
        require(kind in {'new-genuine-closure-archive-member','existing-genuine-callback-raw-ZIP-member'}, 'explicit selected raw coverage kind')
        if str(payload_path) not in archives: archives[str(payload_path)] = checked_zip(payload, maximum=32*MIB, count=64)
        require(archives[str(payload_path)].read(c['zip_member']) == raw, 'exact original physical bytes retained')
require(coverage_kinds == {'new-genuine-closure-archive-member':34,'existing-genuine-callback-raw-ZIP-member':15,'byte-identical-existing-genuine-publication':2}, 'complete selected raw capture partition')
require(len(data(ROOT / 'worker-stderr.txt')) > 0, 'actual nonempty native optimizer diagnostics retained')

summary = json.loads(data(ROOT / 'measured-summary.json'), parse_float=Decimal)
worker = json.loads(data(ROOT / 'reference-work/worker-report.json'))
require(summary['worker_report'] == json.loads(data(ROOT / 'reference-work/worker-report.json'), parse_float=Decimal), 'summary authentic whole worker report')
require(summary['operational_refusal'] is None and summary['selected_reference_status'] == 'REFERENCE_REPAIR_REFUSED', 'assessment refusal distinct from operational failure')
require(worker['refusal'] is None, 'native constructor/caller itself returned')
require(worker['retained_native_topology_loads_observed'] == 1 and worker['retained_coupling_attempts'] == 1 and worker['retained_couplings_returned'] == 1, 'actual native load/coupling denominator')
require(worker['new_native_preparations'] == worker['new_control_callbacks'] == worker['new_capacity_callbacks'] == 0, 'no repeat controls/preparation')
require(worker['attempted_callback_reservations'] == worker['native_processes_started'] == worker['attempted_Popen_audit_event_count'] == 1 and len(worker['executor_observations']) == 1, 'one new objective/process evidence')
require(all(v == 1 for v in worker['native_effect_counters'].values()) and len(worker['native_effect_counters']) == 6, 'one actual Context/MM/coupled attempt/return')
require(worker['coupled_source_admission_attempts'] == worker['new_coupled_source_admissions'] == worker['exposed_context_reconstruction_attempts'] == worker['new_exposed_context_reconstructions'] == 1, 'exposed software intake accurately counted')
require(worker['final_source_closure_refusal'] is None, 'source closure')
reference = json.loads(data(ROOT/'reference-work/reference-observations/reference-report.json'))
require(set(worker['reference']) == set(reference)|{'ordinary_report_binding'} and all(worker['reference'][k] == v for k,v in reference.items()) and reference['status'] == 'REFERENCE_REPAIR_REFUSED', 'whole physical assessment refusal and added ordinary binding retained')
require(bound(worker['reference']['ordinary_report_binding']) == data(ROOT/'reference-work/reference-observations/reference-report.json'), 'actual ordinary report hash binding')
require(reference['refusal'] == {'type':'ValueError','message':'finite bounded physical operand required'}, 'exact retained physical refusal')
require(reference['full_physical_evaluation_returns'] == 0 and reference['coupled_evaluation_entries'] == 1 and reference['fresh_full_coupled_gradient'] == 'UNENTERED', 'returned native methods did not imply accepted physical assessment')
require(len(reference['evaluation_roster']) == 1 and reference['evaluation_roster'][0]['status'] == 'REFUSED', 'complete sole physical evaluation roster')
require(not (ROOT/'reference-work/reference-observations/evaluation-001-result.json.gz').exists(), 'no fabricated full coupled gradient result')
outer = parse_outer(HELPERS / 'outer-resource-v3.txt')
require(outer['exit_code'] == '0', 'normal outer wait')
outer_cpu = Decimal(outer['user_cpu_seconds']) + Decimal(outer['system_cpu_seconds'])
worker_cpu = summary['process']['complete_waited_worker_cpu_seconds']
worker_microseconds = worker_cpu.quantize(Decimal('0.000001'))
parent_complete = outer_cpu - worker_microseconds
require(summary['process']['complete_descendant_cpu_accounting'] is True and summary['process']['forced_worker_group_kill'] is False, 'normally waited complete tree')
require(summary['process']['conservative_worker_cpu_charge_seconds'] == worker_cpu, 'normal measured cost charge')
require(worker['waited_child_CPU_seconds_before_serialization'] > 0, 'actual waited native child CPU retained')
journals = [json.loads(line, parse_float=Decimal) for line in data(HELPERS / 'outer-stderr-v3.txt').decode().splitlines()]
require(len(journals) == 2 and journals[0]['event'] == 'PARENT_ENTRY' and journals[-1]['event'] == 'PARENT_EXIT', 'whole parent journals')
require(journals[-1]['exception'] is None and journals[-1]['stage'] == 'PACKET_CLOSED', 'normal closed parent exit')
require(journals[-1]['known_waited_worker_cpu_seconds'] == worker_cpu, 'worker/journal exact CPU token')
parent_snapshot = journals[-1]['own_cpu_seconds_before_exit_record'] + journals[-1]['waited_child_cpu_seconds_before_exit_record'] - worker_cpu
require(abs(parent_snapshot - journals[-1]['complete_parent_cpu_seconds_before_exit_record']) < Decimal('.0001'), 'whole recorded parent reconciliation; adjacent getrusage snapshots')
require(parent_complete >= journals[-1]['complete_parent_cpu_seconds_before_exit_record'] - Decimal('.01'), 'complete outer includes exit/startup tail within time rounding')

old = config['old_cost_and_exposure']
for key in ('old_qmmm_final_summary', 'preparation_summary', 'preparation_outer_resource', 'preparation_preentry_outer_resource'):
    bound(old[key])
prep = json.loads(bound(old['preparation_summary']), parse_float=Decimal)
prep_outer = parse_outer(old['preparation_outer_resource']['path'])
preentry = parse_outer(old['preparation_preentry_outer_resource']['path'])
prep_outer_cpu = Decimal(prep_outer['user_cpu_seconds']) + Decimal(prep_outer['system_cpu_seconds'])
preentry_cpu = Decimal(preentry['user_cpu_seconds']) + Decimal(preentry['system_cpu_seconds'])
prep_worker_cpu = prep['process']['complete_waited_worker_cpu_seconds'].quantize(Decimal('.000001'))
old_worker = prep['prior_cost_and_exposure']['complete_worker_cpu_seconds'] + prep_worker_cpu
old_parent = prep['prior_cost_and_exposure']['complete_parent_cpu_seconds'] + preentry_cpu + prep_outer_cpu - prep_worker_cpu
v1_summary = json.loads(bound(old['retained_reference_v1_summary']), parse_float=Decimal)
v1_worker = v1_summary['process']['complete_waited_worker_cpu_seconds'].quantize(Decimal('.000001'))
v1_outer = parse_outer(old['retained_reference_v1_outer_resource']['path'])
bound(old['retained_reference_v1_outer_resource'])
v1_outer_cpu = Decimal(v1_outer['user_cpu_seconds']) + Decimal(v1_outer['system_cpu_seconds'])
old_worker += v1_worker
old_parent += v1_outer_cpu - v1_worker
v2_summary = json.loads(bound(old['retained_reference_v2_summary']), parse_float=Decimal)
v2_worker = v2_summary['process']['complete_waited_worker_cpu_seconds'].quantize(Decimal('.000001'))
v2_outer = parse_outer(old['retained_reference_v2_outer_resource']['path'])
bound(old['retained_reference_v2_outer_resource'])
v2_outer_cpu = Decimal(v2_outer['user_cpu_seconds']) + Decimal(v2_outer['system_cpu_seconds'])
old_worker += v2_worker
old_parent += v2_outer_cpu - v2_worker
require(old_worker == Decimal(old['complete_worker_cpu_seconds']) and old_parent == Decimal(old['complete_parent_cpu_seconds']), 'old complete cost ledger independently reconciled')
require(old_worker + old_parent == Decimal(old['complete_outer_cpu_seconds_rounded']), 'whole old outer total')
require(old['callback_reservations'] == 33 and old['actual_qmmm_native_processes'] == 32, 'retained exposed old denominator')
require(old_worker + worker_microseconds < 1000 and old_parent + parent_complete < 200, 'complete carried CPU caps')
require(outer_cpu < 830 and Decimal(outer['elapsed_seconds']) < 1200, 'whole newly assigned time bounds')

cumulative_rows = []
for text in config['cumulative_directories']:
    root = Path(text)
    files = regular_files(root)
    cumulative_rows.append({'root': text, 'files': len(files), 'bytes': sum(p.stat().st_size for p in files)})
all_bytes = sum(r['bytes'] for r in cumulative_rows)
require(all_bytes < 1024 * MIB and current['bytes'] < 320 * MIB, 'complete current output bound')
require((HELPERS / 'empty-python-cache').is_dir() and not list((HELPERS / 'empty-python-cache').iterdir()) and stat.S_IMODE((HELPERS / 'empty-python-cache').stat().st_mode) == 0o555, 'sealed unused empty cache prefix')

# Independent source/table/mask arithmetic follows before final observation.
def raw_force_stage(stage):
    root = ROOT/'reference-work/native-force-observations'
    join_raw = data(root/(stage+'.join.json'))
    join = json.loads(join_raw)
    require(join['stage'] == stage and 1 <= len(join['ordered_chunks']) <= 4, 'selected force stage/chunks')
    pieces = []
    for row in join['ordered_chunks']:
        safe_name(row['name'])
        raw = bound({**row, 'path': str(root/row['name'])}, 8*MIB)
        pieces.append(raw)
    raw = b''.join(pieces)
    require(len(raw) == join['whole_bytes'] <= 32*MIB and digest(raw) == join['whole_sha256'], 'force ordered whole identity')
    return json.loads(raw), {'stage': stage, 'bytes': len(raw), 'sha256': digest(raw), 'chunks': len(pieces)}


before, before_join = raw_force_stage('before-ash-masks')
after, after_join = raw_force_stage('after-ash-masks')
require(worker['native_force_observations'] == [json.loads(data(ROOT/'reference-work/native-force-observations'/f'{s}.join.json'))
        for s in ('before-ash-masks', 'after-ash-masks')], 'whole worker stage observation joins')
source = json.loads(bound(config['retained_reload_witness']))
types = source['retained_native_ATOM_TYPE_INDEX']
tables = source['native_lj_tables']
require(source['native_POINTERS'][:2] == [13828,25] and len(types) == 13828, 'authenticated saved25-type denominator')
lookup = tables['NONBONDED_PARM_INDEX']
a = tables['LENNARD_JONES_ACOEF']
b = tables['LENNARD_JONES_BCOEF']
require(len(lookup) == 625 and len(a) == len(b) == 325, 'complete original source table dimensions')
require(all(type(t) is int and 1 <= t <= 25 for t in types) and set(types) == set(range(1,24)), 'all occupied native types1-23 with unused24/25 retained')
max_a_error = max_b_error = Decimal(0)
for snapshot in (before, after):
    custom = snapshot['custom_lj']
    require(custom['energy_expression'] == '(a/r6)^2-b/r6; r6=r^6;a=acoef(type1, type2);b=bcoef(type1, type2);', 'actual selected native expression')
    require(custom['particles'] == [[float(t-1)] for t in types], 'actual full source-native particle type order')
    require(custom['counts'] == {'particles':13828,'exclusions':len(custom['exclusions']),'tables':2,'per_particle_parameters':1,
        'global_parameters':0,'computed_values':0,'energy_parameter_derivatives':0,'interaction_groups':0}, 'complete actual custom census')
    require(custom['per_particle_parameters'] == ['type'] and not any(custom[k] for k in
        ('global_parameters','computed_values','energy_parameter_derivatives','interaction_groups')), 'actual zero unselected parameter families')
    require(custom['nonbonded_method'] == custom['force_group'] == 0 and not any(custom[k] for k in
        ('use_switching_function','use_long_range_correction','uses_periodic_boundary_conditions')), 'actual nonperiodic unswitched no-cutoff field')
    fa, fb = custom['tabulated_functions']
    require(fa[:4] == ['acoef','Discrete2DFunction',25,25] and fb[:4] == ['bcoef','Discrete2DFunction',25,25], 'actual native discrete functions25x25')
    require(len(fa[4]) == len(fb[4]) == 625, 'actual complete625-value functions')
    with localcontext() as ctx:
        ctx.prec=80
        for i in range(25):
            for j in range(25):
                index=lookup[25*i+j]-1
                require(0 <= index < 325 and lookup[25*j+i] == index+1, 'source symmetric pair index')
                position=i+25*j
                native_a=Decimal(str(fa[4][position]))
                native_b=Decimal(str(fb[4][position]))
                source_a=Decimal(str(a[index]))*Decimal('4.184')*Decimal('.1')**12
                source_b=Decimal(str(b[index]))*Decimal('4.184')*Decimal('.1')**6
                if source_a == 0:
                    require(native_a == 0, 'zero source A preserved exactly')
                else:
                    err=abs(native_a*native_a-source_a)/abs(source_a)
                    max_a_error=max(max_a_error,err)
                    require(err <= Decimal('1e-13'), 'independent squared-A source unit conversion')
                if source_b == 0:
                    require(native_b == 0, 'zero source B preserved exactly')
                else:
                    err=abs(native_b-source_b)/abs(source_b)
                    max_b_error=max(max_b_error,err)
                    require(err <= Decimal('1e-13'), 'independent B source unit conversion')
    require(len(snapshot['particles']) == 13828 and all(row[1:] == [1.0,0.0] for row in snapshot['particles']), 'no additional ordinary particle-LJ contribution')
    ordinary = {tuple(sorted(row[:2])):row[2:] for row in snapshot['exceptions']}
    pairs = [tuple(sorted(pair)) for pair in custom['exclusions']]
    require(len(ordinary) == len(snapshot['exceptions']) and len(pairs) == len(set(pairs)) and set(ordinary) == set(pairs), 'exact ordinary exception/custom exclusion pair agreement')
require(before['force_roster'] == after['force_roster'] and before['nonbonded_properties'] == after['nonbonded_properties'], 'same native force domain')
require(before['particles'] == after['particles'], 'all native particle parameters preserved across ASH masks')
held_join_raw = data(ROOT/'retained-plan/original-join.json')
require(held_join_raw == bound(config['reference_plan_join']), 'retained plan exact original join bytes')
held_join = json.loads(held_join_raw)
held_parts = []
for i,row in enumerate(held_join['ordered_chunks']):
    raw = bound({**row,'path':str(ROOT/'retained-plan'/f'plan.part-{i:04d}')},8*MIB)
    held_parts.append(raw)
held_plan_raw = b''.join(held_parts)
require(len(held_plan_raw) == held_join['whole_bytes'] and digest(held_plan_raw) == held_join['whole_sha256'], 'source-bound retained copied plan whole identity')
joined_plan = json.loads(held_plan_raw)
q = set(joined_plan['real_qm_full_indices_0based'])
require(len(q) == 76 and len(joined_plan['classical_charge_fractions']) == 13828, 'source-bound physical76QM roster')
selected_charges = [float(Fraction(*pair)) for pair in joined_plan['classical_charge_fractions']]
require([row[0] for row in before['particles']] == selected_charges and all(selected_charges[i] == 0 for i in q), 'exact source-rational-to-float classical charges/QM zeros')
original_pairs={tuple(sorted(pair)) for pair in before['custom_lj']['exclusions']}
quantum_pairs={(i,j) for i in q for j in q if i < j}
expected_pairs=original_pairs|quantum_pairs
require({tuple(sorted(pair)) for pair in after['custom_lj']['exclusions']} == expected_pairs, 'source exclusions union all physicalQM-QM pairs only')
require(after['custom_lj']['exclusions'][:len(before['custom_lj']['exclusions'])] == before['custom_lj']['exclusions'], 'source exclusion order preserved')
for key,value in before['custom_lj'].items():
    if key in ('counts','exclusions'):
        continue
    require(after['custom_lj'][key] == value, 'actual table/type/force properties preserved')
previous={tuple(sorted(row[:2])):row[2:] for row in before['exceptions']}
current_exceptions={tuple(sorted(row[:2])):row[2:] for row in after['exceptions']}
for pair,row in current_exceptions.items():
    if pair in quantum_pairs:
        require(row == [0.0,0.0,0.0], 'exact removed QM-QM ordinary exception')
    else:
        require(pair in previous and row[1:] == previous[pair][1:], 'cross/MM original exception LJ preserved')
        if pair[0] in q or pair[1] in q:
            require(row[0] == 0.0, 'QM-containing exception charge product removed')
masked_counts={}
for key,arity,threshold in (('bonds',2,2),('angles',3,2),('torsions',4,3)):
    require(len(before[key]) == len(after[key]), 'bonded full term denominator')
    count=0
    for old_row,new_row in zip(before[key],after[key],strict=True):
        remove=sum(i in q for i in old_row[:arity])>=threshold
        expected=old_row[:-1]+[0.0 if remove else old_row[-1]]
        require(new_row == expected, 'independent selected ASH bonded mask/boundary preservation')
        count+=int(remove)
    masked_counts[key]=count
force_audit={'before':before_join,'after':after_join,'full_native_types':25,'occupied_native_types':list(range(1,24)),
    'complete_table_entries_per_function':625,'source_triangular_AB_entries':325,'native_particles':13828,
    'real_QM_atoms':76,'custom_exclusions_before':len(original_pairs),'custom_exclusions_after':len(expected_pairs),
    'added_QM_only_exclusions':len(expected_pairs-original_pairs),'masked_bonded_terms':masked_counts,
    'maximum_relative_squared_A_unit_conversion_error':str(max_a_error),'maximum_relative_B_unit_conversion_error':str(max_b_error),
    'method':'Independent complete raw source/table/particle/charge/order arithmetic and native before/after mask checks, not producer API calls.',
    'C4_status':'PASS; independently checked below','kinetic_or_geometry_qualification':False}


# Independent representation control replay, using raw native tokens and source A/B.
c4root=ROOT/'reference-work/source-table-control'
c4=json.loads(data(c4root/'source-table-control-report.json'))
require(c4 == worker['source_table_control'] and c4['status']=='PASS' and c4['failure'] is None,'complete actual C4 report')
require(c4['native_counters']=={'context_attempts':1,'context_returns':1,'energy_force_attempts':3,'energy_force_returns':3,'xtb_callbacks':0},'actual C4 effect counts')
actual_live=json.loads(bound(c4['actual_live_force_witness']))
setup=json.loads(bound(c4['control_setup']))
c4source=json.loads(bound(c4['source_witness']))
require(c4source==source,'same exact authenticated source witness semantics')
require(actual_live['energy_expression']==after['custom_lj']['energy_expression'] and actual_live['particles']==after['custom_lj']['particles'],'full live C4 native expression and atom type order')
require(actual_live['exclusions']==after['custom_lj']['exclusions'],'full live C4 exclusion census/order')
for observed,expected in zip(actual_live['tabulated_functions'],after['custom_lj']['tabulated_functions'],strict=True):
    require([observed['name'],observed['class'],observed['nx'],observed['ny'],observed['values']]==expected,'complete live C4/actual system source table join')
require(setup['tables']==actual_live['tabulated_functions'] and setup['custom_expression']==actual_live['energy_expression'],'clone complete source matrix/expression')
require(setup['charges_e']==[0.,0.] and setup['ordinary_LJ_epsilons']==[0.,0.] and setup['exclusions']==[] and setup['platform']=='Reference','tiny two-particle zero Coulomb isolated custom-table control')
chosen=next((i,j,lookup[25*(i-1)+(j-1)]-1) for i in sorted(set(types)) for j in sorted(set(types))
            if i<j and a[lookup[25*(i-1)+(j-1)]-1]>0 and b[lookup[25*(i-1)+(j-1)]-1]>0)
require(c4['selected_pair']['source_types_1based']==list(chosen[:2]) and setup['types_0based']==[chosen[0]-1,chosen[1]-1],'deterministic source-only first distinct occupied types')
require(chosen==(1,2,1),'selected actual source pair denominator')
c4_max=Decimal(0);native_c4_energies=[];native_c4_forces=[]
with localcontext() as ctx:
    ctx.prec=80
    sourceA=Decimal(str(a[chosen[2]]))*Decimal('4.184')*Decimal('.1')**12
    sourceB=Decimal(str(b[chosen[2]]))*Decimal('4.184')*Decimal('.1')**6
    for ordinal,(label,r) in enumerate((('baseline',Decimal('.4')),('minus',Decimal('.399999')),('plus',Decimal('.400001')))):
        tokens=json.loads(data(c4root/(label+'-unverified-native-return-tokens.json')))
        parsed=json.loads(data(c4root/(label+'-raw-native-energy-forces.json')))
        require(tokens['label']==label and parsed['label']==label and tokens['coordinates_nm']==[[0.,0.,0.],[float(r),0.,0.]],'native raw selected label/position')
        E=Decimal(tokens['energy_kj_per_mol_token'])
        F=[[Decimal(x) for x in row] for row in tokens['forces_kj_per_mol_nm_tokens']]
        require(len(F)==2 and all(len(row)==3 and all(x.is_finite() for x in row) for row in F) and E.is_finite(),'complete finite raw C4 returns')
        require(E==Decimal(str(parsed['energy_kj_per_mol'])) and F==[[Decimal(str(x)) for x in row] for row in parsed['forces_kj_per_mol_nm']],'original native token/parsed witness equality')
        expected_E=sourceA/r**12-sourceB/r**6
        dE=-12*sourceA/r**13+6*sourceB/r**7
        expected_F=[[dE,Decimal(0),Decimal(0)],[-dE,Decimal(0),Decimal(0)]]
        for actual,expected in [(E,expected_E),*((v,w) for row,wrow in zip(F,expected_F,strict=True) for v,w in zip(row,wrow,strict=True))]:
            err=abs(actual-expected)/max(Decimal(1),abs(actual),abs(expected));c4_max=max(c4_max,err)
            require(err<=Decimal('1e-10'),'independent raw C4 source energy/negative-gradient oracle')
        require(c4['evaluation_roster'][ordinal]['status']=='RETURNED' and c4['evaluation_roster'][ordinal]['energy_kj_per_mol']==float(E),'whole C4 returned roster')
        native_c4_energies.append(E);native_c4_forces.append(F)
    fd=(native_c4_energies[2]-native_c4_energies[1])/Decimal('.000002')
    df=-native_c4_forces[0][1][0]
    fd_err=abs(fd-df)/max(Decimal(1),abs(fd),abs(df))
    require(fd_err<=Decimal('1e-8'),'independent actual central FD versus native force')
    require(fd==Decimal(c4['finite_difference']['distance_derivative_kj_per_mol_nm']) and fd_err==Decimal(c4['finite_difference']['scaled_error']),'producer C4 finite-difference arithmetic exactly reproduced')
c4journal=[json.loads(line) for line in data(c4root/'entry-return-journal.jsonl').splitlines()]
require([x['event'] for x in c4journal]==['SOURCE_GUARD_ENTRY','SOURCE_GUARD_RETURN','CONTEXT_ENTRY','CONTEXT_RETURN','SOURCE_GUARD_ENTRY','SOURCE_GUARD_RETURN',*['ENERGY_FORCE_ENTRY','ENERGY_FORCE_RETURN']*3,'SOURCE_GUARD_ENTRY','SOURCE_GUARD_RETURN'],'actual C4 entry/return/source-guard ordering')
require(c4journal[5]['stage']=='after-context-before-forces' and all(x['elapsed_seconds']<=y['elapsed_seconds'] for x,y in zip(c4journal,c4journal[1:])),'postContext source check before native force work')
c4_audit={'status':'PASS','actual_contexts':1,'actual_energy_force_attempts_and_returns':3,'quantum_callbacks':0,'source_types_1based':list(chosen[:2]),'source_AB_index_1based':chosen[2]+1,'maximum_independent_analytic_scaled_error':str(c4_max),'independent_FD_scaled_error':str(fd_err),'scope':'Native representation conformance; no enzyme stationarity, geometry or rates.'}

# One actual source-bound callback; no producer parser is called.
planzip=checked_zip(data(ROOT/'callback-custody/reference-v2/call-0001.plan.zip'),maximum=8*MIB,count=8)
rawzip=checked_zip(data(ROOT/'callback-custody/reference-v2/call-0001.raw.zip'),maximum=8*MIB,count=32)
plan=json.loads(planzip.read('plan.json'));capture=json.loads(rawzip.read('capture.json'))
call=ROOT/'reference-work/cases/reference-v2/calls/call-0001'
require(plan['execution_id']==capture['execution_id']=='call-0001' and plan['identity']==capture['plan_identity'],'complete raw/request identity')
require(capture['returncode']==0 and capture['operational_refusal'] is None and capture['native_failure_files']==[],'one normally returned native capture')
require(plan['output_locator']==capture['output_locator']==str(call),'exact selected source callback locator')
expectedargv=[config['binary']['path'],'input.coord','--gfn','2','--vparam',config['parameters']['path'],'--chrg','-6','--uhf','0','--etemp','300','--acc','0.05','--iterations','250','--input','xcontrol.inp','--parallel','1','--norestart','--verbose','--grad']
require(plan['argv']==capture['program_argv']==worker['executor_observations'][0]['argv']==expectedargv,'actual native program args/settings')
require(plan['binary_sha256']==config['binary']['sha256'] and plan['parameter_sha256']==config['parameters']['sha256'],'fixed native executable/parameter identities')
for row in plan['inputs']:
    raw=planzip.read(row['name'])
    require(len(raw)==row['bytes'] and digest(raw)==row['sha256'] and data(call/Path(row['name']).name)==raw,'actual prepublished native input equality')
for row in capture['files']:
    raw=rawzip.read('files/'+row['name'])
    require(len(raw)==row['bytes'] and digest(raw)==row['sha256'] and data(call/row['name'])==raw,'complete published raw original file equality')
for field,filename in [('gradient_sha256','gradient'),('pcgrad_sha256','pcgrad'),('stdout_sha256','stdout.txt'),('stderr_sha256','stderr.txt')]:
    require(capture[field]==digest(data(call/filename)),'native gradient/PC/full stream hash linkage')
require(set(planzip.namelist())=={'plan.json',*(row['name'] for row in plan['inputs'])} and set(rawzip.namelist())=={'capture.json',*('files/'+row['name'] for row in capture['files'])},'complete no-undeclared native archive census')
bridge=ROOT/'reference-work/cases/reference-v2/bridge'
for kind,pubname in [('', 'call-0001.plan.zip'),('capture-','call-0001.raw.zip')]:
    request=json.loads(data(bridge/('call-0001.'+kind+'request.json')))
    ack=json.loads(data(bridge/('call-0001.'+kind+'ack.json')))
    manifest=data(ROOT/'callback-custody/reference-v2'/(pubname+'.manifest.json'))
    require(ack['manifest_sha256']==digest(manifest),'genuine manifest acknowledgment before native parse/return')

inputrow=reference['evaluation_roster'][0]['input_snapshot'];inputraw=gzip.decompress(bound(inputrow))
require(len(inputraw)==inputrow['expanded_bytes'] and digest(inputraw)==inputrow['expanded_sha256'],'bounded original full physical input snapshot')
physical_input=json.loads(inputraw)
require(physical_input['physical_atom_ids']==[f'amber:{i}' for i in range(1,13829)] and len(physical_input['coordinates_angstrom'])==13828,'actual physical source ID order/full denominator')
coords=physical_input['coordinates_angstrom']
require(all(tuple(row)==tuple(float(x) for x in sourceatom[2]) for row,sourceatom in zip(coords,joined_plan['physical_atoms'],strict=True)),'initial full source geometry no optimizer displacement')
qindices=joined_plan['real_qm_full_indices_0based'];mmindices=[i for i in range(13828) if i not in q]
require(len(qindices)==76 and len(mmindices)==13752 and reference['fixed_physical_count']==13778,'common physical/QM/MM/fixed denominator')
coordlines=data(call/'input.coord').decode().splitlines();require(coordlines[0]=='$coord' and coordlines[-1]=='$end' and len(coordlines)==83,'81 complete QM coordinate rows')
qxyz=[];elems=[]
for line in coordlines[1:-1]:
    tok=line.split();require(len(tok)==4,'QM coordinate token shape');xyz=tuple(Decimal(x.replace('D','E')) for x in tok[:3]);require(all(x.is_finite() for x in xyz),'finite native positions');qxyz.append(xyz);elems.append(tok[3].capitalize())
require(plan['qm_atom_ids']==[f'qm-{i:04d}' for i in range(1,82)] and plan['formal_charge']==-6 and plan['unpaired_electrons']==0 and plan['all_electron_count']==382 and plan['valence_electron_count']==266,'exact 81-atom electron ledger')
for i,index in enumerate(qindices):
    require(elems[i]==joined_plan['physical_atoms'][index][1] and max(abs(qxyz[i][j]*Decimal('.52917726')-Decimal(str(coords[index][j]))) for j in range(3))<=Decimal('1e-10'),'QM/source coordinate and element mapping')
for i,link in enumerate(joined_plan['generated_links']):
    require(elems[76+i]=='H' and max(abs(qxyz[76+i][j]*Decimal('.52917726')-Decimal(link[4][j])) for j in range(3))<=Decimal('1e-10'),'five generated caps preserve held geometry tolerance')
completeids=[f'pc-{i:05d}' for i in range(1,len(mmindices)+1)]
zeroids=[completeids[i] for i,index in enumerate(mmindices) if selected_charges[index]==0]
nonzero=[(completeids[i],index) for i,index in enumerate(mmindices) if selected_charges[index]!=0]
require(plan['complete_field_ids']==completeids and plan['excluded_exact_zero_field_ids']==zeroids and len(zeroids)==5 and plan['native_field_ids']==[x[0] for x in nonzero],'full13752 field rows/exact five-zero filter/order')
pcem=data(call/'pointcharges').decode().splitlines();require(pcem[0]=='13747' and len(pcem)==13748,'all native nonzero point-charge rows')
qsum=Fraction()
for line,(_,index) in zip(pcem[1:],nonzero,strict=True):
    tok=line.split();require(len(tok)==5 and tok[-1]=='99','complete fixed native hardness source field')
    qvalue=Decimal(tok[0]);qsum+=Fraction(qvalue)
    require(abs(qvalue-Decimal(str(selected_charges[index])))<=Decimal('1e-16'),'selected rational-to-float field charge realization')
    require(max(abs(Decimal(tok[j+1])*Decimal('.52917726')-Decimal(str(coords[index][j]))) for j in range(3))<=Decimal('1e-10'),'full MM source coordinate ordering')
require(qsum==Fraction(plan['serialized_field_charge_sum']),'complete exact serialized native charge sum')
require(data(call/'xcontrol.inp')==b'$embedding\n es=true\n input=pointcharges\n gradient=pcgrad\n$scc\n iterations=250\n temp=300\n$end\n','exact unrestricted embedded gradient control')
stdout=data(call/'stdout.txt').decode();stderr=data(call/'stderr.txt').decode()
require(stderr.splitlines()==['normal termination of xtb'],'complete single official normal termination witness')
require(re.findall(r'xtb version\s+(\d+\.\d+\.\d+)\s+\(([a-f0-9]+)\)',stdout)==[('6.7.1','edcfbbe')],'actual binary release/build identity')
require(re.findall(r'^\s*program call\s*:\s*(.+)$',stdout,re.M)[0].split()==expectedargv,'actual echoed native command')
require(not re.search(r'FAILED TO CONVERGE|SCF not converged|abnormal termination|\[ERROR\]',stdout+'\n'+stderr,re.I),'native no convergence refusal')
solves=re.findall(r'convergence criteria satisfied after\s+(\d+)\s+iterations',stdout)
require(solves==['67'],'one actual converged67-iteration SCC objective')
grad=data(call/'gradient').decode().splitlines();require(grad[0]=='$grad' and grad[-1]=='$end' and len(grad)==165,'complete81-coordinate81-gradient raw gradient')
header=re.search(r'SCF energy\s*=\s*(\S+)\s+\|dE/dxyz\|\s*=\s*(\S+)',grad[1]);require(header is not None,'native gradient energy/norm header')
qmenergy=Decimal(header[1]);reportednorm=Decimal(header[2]);qgrad=[]
for i,(line,witness) in enumerate(zip(grad[2:83],qxyz,strict=True)):
    tok=line.split();require(len(tok)==4 and tok[3].capitalize()==elems[i],'native writer full element order')
    require(max(abs(Decimal(tok[j])-witness[j])*Decimal('.52917726') for j in range(3))<=Decimal('1e-10'),'gradient writer witnesses exact evaluation positions')
for line in grad[83:164]:
    tok=line.split();require(len(tok)==3,'native gradient3 components');row=[Decimal(x.replace('D','E')) for x in tok];require(all(x.is_finite() for x in row),'finite native partial QM forces');qgrad.append(row)
with localcontext() as ctx:
    ctx.prec=80
    nativeqnorm=sum(v*v for row in qgrad for v in row).sqrt()
require(abs(nativeqnorm-reportednorm)<=Decimal('5.0001e-7'),'native rounded gradient norm witness')
stdoutE=re.findall(r'^\s*\|\s+TOTAL ENERGY\s+(\S+)\s+Eh\s+\|',stdout,re.M)
require(len(stdoutE)==1 and abs(qmenergy-Decimal(stdoutE[0]))<=Decimal('1e-10'),'header/stdout energy agreement')
pcgrad=[]
for line in data(call/'pcgrad').decode().splitlines():
    tok=line.split();require(len(tok)==3,'PCgradient3 components');row=[Decimal(x.replace('D','E')) for x in tok];require(all(x.is_finite() for x in row),'finite complete native PCgrad');pcgrad.append(row)
require(len(pcgrad)==13747,'native PC gradient complete denominator')
process=json.loads(data(call/'process-observation.json'))
require(process==worker['executor_observations'][0] and process['returncode']==0 and process['operational_refusal'] is None and process['native_started'] is True,'actual executor/process observation whole join')
require(worker['attempted_Popen_audit_events'][0]['argv']==expectedargv,'actual audited spawn matches selected request')
events=[json.loads(line) for line in data(ROOT/'reference-work/native-effect-journal.jsonl').splitlines()]
require([(row['kind'],row['status']) for row in events]==[('coupled_run','ENTERED'),('MM_run','ENTERED'),('classical_create_simulation','ENTERED'),('classical_create_simulation','RETURNED'),('source_closure_after_simulation','VERIFIED'),('MM_run','RETURNED'),('coupled_run','RETURNED')],'actual coupled/MM/Context/source check order')
callback_audit={'status':'ONE_NORMAL_CONVERGED_NATIVE_GRADIENT; FULL_PHYSICAL_ASSESSMENT_REFUSED','plan_identity':plan['identity'],'qm_atoms':81,'full_field_atoms':13752,'native_nonzero_field_atoms':13747,'omitted_zero_rows':5,'all_electron_count':382,'valence_electron_count':266,'formal_charge':-6,'native_SCC_iterations':67,'QM_energy_hartree':str(qmenergy),'partial_QM_gradient_L2_Eh_native_Bohr':str(nativeqnorm),'QM_gradient_components':243,'native_PCgradient_components':41241,'raw_hashes':{name:digest(data(call/name)) for name in ['input.coord','pointcharges','stdout.txt','stderr.txt','gradient','pcgrad']},'partial_gradient_scope':'One initial native QM/field component, not a fresh final gradient or coupled stationarity certificate. Returned complete total E/gradient operands failed the preselected physical guard before retention; their numerical values cannot independently be determined from the retained callback alone.'}

usage=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
report={'role':'INDEPENDENT_READ_ONLY_CUSTODY_SOURCE_AND_COST_AUDIT_NOT_NEW_SCIENCE','status':'PASS',
 'method':'Own full byte/mode census, actual existing ExternalArtifactPlane verifies every typed manifest, independent raw ZIP/source/matrix/mask/native-gradient/C4/cost arithmetic. No producing helper, native science import, constructor or evaluator.',
 'inputs':{'packet_census_sha256':CENSUS_SHA,'frozen_config_sha256':CONFIG_SHA,'frozen_protocol_sha256':PROTOCOL_SHA},
 'packet':current,'ancestors':ancestors,'producing_source_count':len(source_members),'complete_reached_raw_files':len(coverage),'raw_coverage_partition':coverage_kinds,'worker_stderr_bytes':len(data(ROOT/'worker-stderr.txt')),
 'force_and_mask_audit':force_audit,'C4_independent_native_raw_audit':c4_audit,'single_callback_audit':callback_audit,
 'cumulative_output_bytes_at_audit':all_bytes,'cumulative_directories':cumulative_rows,
 'native_outcome':{'status':worker['native_case_status'],'physical_refusal':reference['refusal'],'retained_topology_loads':1,'coupling_attempts':1,'coupling_returns':1,'method_counters':worker['native_effect_counters'],'C4_counters':c4['native_counters'],'callback_reservations':1,'native_processes':1,'accepted_full_physical_results':0,'fresh_full_coupled_gradient':'UNENTERED','new_exposed_source_admissions':1,'new_exposed_context_reconstructions':1,'new_native_preparations':0,'internal_force_kernel_counts':'UNIDENTIFIED; counters bind Context/MM/coupled methods, not internal kernels'},
 'costs':{'prior_worker_cpu_seconds':str(old_worker),'prior_parent_cpu_seconds':str(old_parent),'worker_cpu_seconds_original_token':str(worker_cpu),'worker_cpu_seconds_microsecond_summary':str(worker_microseconds),'outer_cpu_seconds_rounded':str(outer_cpu),'outer_wall_seconds_rounded':outer['elapsed_seconds'],'complete_parent_cpu_seconds_from_outer':str(parent_complete),'cumulative_worker_cpu_seconds':str(old_worker+worker_microseconds),'cumulative_parent_cpu_seconds':str(old_parent+parent_complete),'cumulative_outer_cpu_seconds_rounded':str(old_worker+old_parent+outer_cpu),'callback_reservations_total':34,'actual_coupled_xTB_processes_total':33,'scope':'Actual assigned native scopes only; independent audit/development/acquisition/other engineering costs remain separate, not assumed zero; GNU outer time .01s rounding.'},
 'software_audit_costs':{'self_cpu_before_report':usage.ru_utime+usage.ru_stime,'waited_custody_metadata_child_cpu_before_report':children.ru_utime+children.ru_stime,'wall_before_report':time.monotonic()-START,'scope':'New software-only audit outside all scientific assignment clocks; outer GNU time includes interpreter startup/report tail.'},
 'software_imports':sorted(name for name in sys.modules if name.split('.')[0] in {'numpy','h5py','scipy','ash','openmm','simtk','parmed','pyscf','geometric'}),
 'limitations':['C4 proves isolated native source-table representation and three sampled force values only. It does not qualify enzyme geometry or rates.','One actual initial QM/MM method returned, but physical numeric admission refused before saving complete coupled E/gradient. No accepted optimization or fresh full force/geometry result exists.','Independent audit does not rederive every MM/MM exception SCEE divisor from the original bonded decoder; retained constructor source guards cover that mapping. All recorded source matrices, source charge order, exclusions, LJ preservation and ASH bonded masks were independently checked.','No scientific producer helper or source/reference constructor called by reviewer. Source/receipt/cost custody creates no EL, rate, species or transport authority.']}
with (OUT/'observation.json').open('x') as f:json.dump(report,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'status':report['status'],'packet':current,'raw_files':len(coverage),'C4_independent_FD_error':str(fd_err),'cumulative_bytes':all_bytes,'cumulative_worker_cpu':report['costs']['cumulative_worker_cpu_seconds'],'cumulative_parent_cpu':report['costs']['cumulative_parent_cpu_seconds']}))
