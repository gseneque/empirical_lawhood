"""Construct explicit prospective/frozen retained-reference selection, no science."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

REPO = Path('/home/chevre/gs-ml/empirical_lawhood')
HELPER = Path('/tmp/rubisco-qmmm-reference-from-retained-v3')
ARTIFACT = Path('/tmp/empirical-lawhood-rubisco-20261009/retained-execution')
PREP = ARTIFACT / 'rr-qmmm-preparation-conformance-v2'
V8 = ARTIFACT / 'rr-qmmm-native-repair-v8'
V5 = ARTIFACT / 'rr-qmmm-native-repair-v5'
OWNER = Path('/tmp/rubisco-qmmm-work-v11')
PREVIOUS = ARTIFACT / 'rr-qmmm-retained-reference-v1'
PREVIOUS_V2 = ARTIFACT / 'rr-qmmm-retained-reference-v2'
AUDIT = Path('/tmp/rubisco-qmmm-retained-reference-independent-audit-v1')
AUDIT_V2 = Path('/tmp/rubisco-qmmm-retained-reference-independent-audit-v2')
PREPARATION_AUDIT = Path('/tmp/rubisco-qmmm-preparation-v2-audit')
TABLE_CONTROL = Path('/tmp/rubisco-qmmm-source-table-control-v1')


def binding(path):
    p = Path(path)
    assert p.is_absolute() and p.is_file() and not p.is_symlink(), str(p)
    raw = p.read_bytes()
    return {'path': str(p), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--freeze', action='store_true')
    args = parser.parse_args()
    old = json.loads(Path('/tmp/rubisco-qmmm-work-v8/execution-config-v8.json').read_bytes())
    prep = json.loads(Path('/tmp/rubisco-qmmm-preparation-check-v2/execution-config-v2.json').read_bytes())
    native_work = ARTIFACT / 'rr-qmmm-retained-reference-v3' / 'reference-work'
    cache = HELPER / 'empty-python-cache'
    assert cache.is_dir() and cache.stat().st_mode & 0o777 == 0o555 and not list(cache.iterdir())
    helpers = {
        'launcher': HELPER / 'launcher.py',
        'worker': HELPER / 'worker.py',
        'native_coupling': OWNER / 'native_coupling.py',
        'source_guard': Path(old['worker_helper']['path']),
        'custody_reference': Path(old['custody_reference']['path']),
        'custody_bridge': Path(old['bridge_helper']['path']),
        'bounded_executor': Path('/tmp/rubisco-qmmm-work-v8/bounded_executor.py'),
        'reference_assessment': Path('/tmp/rubisco-qmmm-work-v8/reference_assessment.py'),
        'qm_owner': Path(old['qm_owner']['path']),
        'geometry_helper': Path(old['geometry_helper']['path']),
        'source_table_control': TABLE_CONTROL / 'source_table_control.py',
    }
    protocol = REPO / 'docs/rubisco-inquiry/rr-qmmm-retained-reference-protocol-v3b.md'
    if args.freeze:
        assert protocol.stat().st_mode & 0o777 == 0o444
        assert b'Prospective draft' not in protocol.read_bytes()
        for p in helpers.values():
            if not p.is_relative_to(REPO):
                assert p.stat().st_mode & 0o777 == 0o444, str(p)
    rows = {row['path']: binding(row['path']) for row in prep['selected_sources']
            if Path(row['path']).is_relative_to(REPO / 'src')}
    extras = [*helpers.values(), protocol, REPO / 'uv.lock', REPO / 'pyproject.toml',
        OWNER / 'test_native_coupling.py', OWNER / 'test_retained_preparation.py',
        OWNER / 'test_table_lj.py', OWNER / 'inspect_source_representation.py',
        OWNER / 'source-representation-inspection.json', OWNER / 'README.md',
        TABLE_CONTROL / 'test_source_table_control.py',
        HELPER / 'test_harness.py', HELPER / 'prepare_harness.py', HELPER / 'README.md',
        Path('/tmp/rubisco-qmmm-work-v5/native_coupling.py'), Path(__file__).resolve(),
        Path('/tmp/rubisco-qmmm-retained-reference-config-v3/build_config.py'),
        HELPER / 'config-generation-refusal-v3.json',
        REPO / 'docs/rubisco-inquiry/rr-qmmm-retained-reference-protocol-v3.md',
        Path('/tmp/rubisco-qmmm-work-v10/native_coupling.py'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v1/launcher.py'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v1/worker.py'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v1/execution-config-v1.json'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v2/launcher.py'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v2/worker.py'),
        Path('/tmp/rubisco-qmmm-reference-from-retained-v2/execution-config-v2.json'),
        REPO / 'docs/rubisco-inquiry/rr-qmmm-retained-reference-protocol-v1.md',
        REPO / 'docs/rubisco-inquiry/rr-qmmm-retained-reference-protocol-v2.md',
        *[p for p in AUDIT.iterdir() if p.is_file()],
        *[p for p in AUDIT_V2.iterdir() if p.is_file()],
        *[p for p in PREPARATION_AUDIT.iterdir() if p.is_file()],
        REPO / 'docs/rubisco-inquiry/rr-qmmm-native-repair-protocol-v1.md',
        REPO / 'docs/rubisco-inquiry/rr-qmmm-native-repair-protocol-v8.md',
        REPO / 'docs/rubisco-inquiry/rr-qmmm-preparation-conformance-protocol-v1.md',
        REPO / 'docs/rubisco-inquiry/rr-qmmm-preparation-conformance-protocol-v2.md',
        Path('/tmp/rubisco-qmmm-preparation-check-v2/launcher.py'),
        Path('/tmp/rubisco-qmmm-preparation-check-v1/launcher.py'),
        Path('/tmp/rubisco-qmmm-preparation-v2-plane-audit.py'),
        Path('/tmp/rubisco-qmmm-preparation-v2-plane-observation.json'),
        Path(old['profile']['path']), Path(old['held_reference_v2']['path']),
        *[Path(row['path']) for row in old['coupled_sources']]]
    for p in extras:
        rows[str(p)] = binding(p)
    ancestors = []
    for i in range(1, 9):
        p = ARTIFACT / f'rr-qmmm-native-repair-v{i}'
        ancestors.append({'label': f'v{i}', 'census': binding(p / 'closed-census.json'),
            'publications': len(list(p.rglob('*.manifest.json'))),
            'physical_files': sum(path.is_file() for path in p.rglob('*'))})
    ancestors.append({'label': 'preparation-v2', 'census': binding(PREP / 'closed-census.json'),
        'publications': 11, 'physical_files': 70})
    ancestors.append({'label': 'retained-reference-v1', 'census': binding(PREVIOUS / 'closed-census.json'),
        'publications': 23, 'physical_files': 120})
    ancestors.append({'label': 'retained-reference-v2', 'census': binding(PREVIOUS_V2 / 'closed-census.json'),
        'publications': 23, 'physical_files': 126})
    cumulative = [str(Path(row['census']['path']).parent) for row in ancestors]
    cumulative += [str(Path('/tmp') / f'rubisco-qmmm-work-v{i}') for i in range(1, 12)]
    cumulative += ['/tmp/rubisco-qmmm-preparation-check-v1', '/tmp/rubisco-qmmm-preparation-check-v2',
        '/tmp/rubisco-xtb-control-work-v2', '/tmp/rubisco-xtb-geometry-review',
        '/tmp/rubisco-qmmm-reference-from-retained-v1',
        '/tmp/rubisco-qmmm-reference-from-retained-v2',
        '/tmp/rubisco-qmmm-retained-reference-config-v2',
        '/tmp/rubisco-qmmm-retained-reference-config-v1', str(AUDIT), str(AUDIT_V2), str(PREPARATION_AUDIT), str(TABLE_CONTROL),
        str(HELPER), str(Path(__file__).resolve().parent), '/tmp/rubisco-qmmm-retained-reference-config-v3', str(native_work.parent)]
    assert len(cumulative) == len(set(cumulative))
    original_selection = json.loads(Path('/tmp/rubisco-qmmm-reference-from-retained-v1/execution-config-v1.json').read_bytes())
    assert set(original_selection['cumulative_directories']) <= set(cumulative), 'complete original physical denominator required'
    v2_selection = json.loads(Path('/tmp/rubisco-qmmm-reference-from-retained-v2/execution-config-v2.json').read_bytes())
    assert set(v2_selection['cumulative_directories']) <= set(cumulative), 'complete preceding physical denominator required'
    env = dict(old['worker_environment'])
    env.update({'TMPDIR': str(native_work), 'MPLCONFIGDIR': str(native_work / 'selected-matplotlib-cache'),
        'XDG_CACHE_HOME': str(native_work / 'selected-cache'), 'PYTHONPYCACHEPREFIX': str(cache)})
    old_cost = {'old_windows_closed': True, 'complete_worker_cpu_seconds': '150.076026',
        'complete_parent_cpu_seconds': '163.643974', 'complete_outer_cpu_seconds_rounded': '313.72',
        'callback_reservations': 33, 'actual_qmmm_native_processes': 32,
        'older_electrostatic_native_processes': 39,
        'complete_old_cpu_scope': 'Original QM/MM v1-v8, preparation v1 zero-worker refusal, preparation v2, retained-reference v1 CustomNonbondedForce admission refusal and v2 ordinary construction-audit size refusal after returned coupling; exact outer rounding retained. Engineering/acquisition/checker tails are not included or assumed zero.',
        'conservative_interruption_charge_policy': 'Historical conservative ceilings remain in exact ancestor configurations; independently complete measured descendants remain separately evidenced.',
        'scope': 'New finite retained-reference assignment; all prior windows closed and same source/reference remains exposed.',
        'old_qmmm_final_summary': binding(V8 / 'measured-summary.json'),
        'preparation_summary': binding(PREP / 'measured-summary.json'),
        'preparation_outer_resource': binding(Path('/tmp/rubisco-qmmm-preparation-check-v2/outer-resource-v2.txt')),
        'preparation_preentry_outer_resource': binding(Path('/tmp/rubisco-qmmm-preparation-check-v1/outer-resource-v1.txt')),
        'retained_reference_v1_summary': binding(PREVIOUS / 'measured-summary.json'),
        'retained_reference_v1_census': binding(PREVIOUS / 'closed-census.json'),
        'retained_reference_v1_outer_resource': binding(Path('/tmp/rubisco-qmmm-reference-from-retained-v1/outer-resource-v1.txt')),
        'retained_reference_v1_independent_observation': binding(AUDIT / 'observation.json'),
        'retained_reference_v2_summary': binding(PREVIOUS_V2 / 'measured-summary.json'),
        'retained_reference_v2_census': binding(PREVIOUS_V2 / 'closed-census.json'),
        'retained_reference_v2_independent_observation': binding(AUDIT_V2 / 'observation.json'),
        'retained_reference_v2_outer_resource': binding(Path('/tmp/rubisco-qmmm-reference-from-retained-v2/outer-resource-v2.txt'))}
    for row in old_cost.values():
        if isinstance(row, dict) and 'path' in row:
            rows[row['path']] = row
    config = {
        'scientific_protocol_frozen': args.freeze,
        'assigned_references': 1,
        'artifact_root': str(ARTIFACT), 'packet_name': native_work.parent.name,
        'helper_root': str(HELPER), 'el_source_root': str(REPO / 'src'),
        'native_python': old['native_python'], 'native_site_packages': old['native_site_packages'],
        'worker_environment': env, 'python_cache_prefix': str(cache),
        'profile': binding(old['profile']['path']), 'protocol': binding(protocol),
        **{key: binding(p) for key, p in helpers.items()},
        'derived_prmtop': binding(PREP / 'preparation-work/probe/preparation-scratch/reference-v2-derived.prmtop'),
        'retained_preparation_report': binding(PREP / 'preparation-work/probe/probe-report.json'),
        'retained_reload_witness': binding(PREP / 'preparation-work/probe/witnesses/derived-reloaded-native-witness.json'),
        'retained_preparation_census': binding(PREP / 'closed-census.json'),
        'reference_plan_join': binding(V8 / 'native-work/reference-topology-plan.json.join.json'),
        'retained_completed_summary': binding(V5 / 'measured-summary.json'),
        'retained_completed_controls': binding(V5 / 'native-work/native-controls/control-report.json'),
        'coupled_sources': [binding(row['path']) for row in old['coupled_sources']],
        'held_reference_v2': binding(old['held_reference_v2']['path']),
        'binary': old['binary'], 'parameters': old['parameters'],
        'closed_ancestors': ancestors, 'cumulative_directories': cumulative,
        'old_cost_and_exposure': old_cost,
        'source_delta': {'old_control_coupling': binding('/tmp/rubisco-qmmm-work-v5/native_coupling.py'),
            'preceding_coupling': binding(OWNER / 'native_coupling.py'),
            'new_coupling': binding(OWNER / 'native_coupling.py'),
            'meaning': 'Operational compact structured-output chunks/joins only; frozen v11 native coupling, C4, parameters and reference assessment are byte-identical to v2. Prior coupling returned but C4 and enzyme objectives stayed unentered. No native Hamiltonian, criterion or biological-evidence change.'},
        'native_case_output_bytes': 192 * 1024**2,
        'selected_sources': list(rows.values()),
        'software_checks': {'coupling_and_retained_loader': {'passed': 105, 'seconds': 0.63, 'ruff': 'PASS',
            'kind': 'Focused synthetic/source tests; no authentic admission or native physics.'},
            'source_table_control': {'passed': 13, 'seconds': 0.10, 'ruff': 'PASS',
                'kind': 'Synthetic host tests and independent Decimal source oracles; zero native execution.'},
            'inherited_v2_root_combined': {'passed': 142, 'seconds': 1.14, 'ruff': 'PASS', 'scope': 'Historical v2 source test result; not a new v3 check'},
            'harness': {'passed': 29, 'seconds': 0.42, 'ruff': 'PASS',
                'kind': 'Pure software doubles and harmless stdlib cache-read controls; no authentic construction, ArtifactPlane publication or native physics.'}},
    }
    # Import only the stdlib caller to select its exact finite allocation.
    import importlib.util
    spec = importlib.util.spec_from_file_location('draft_config_harness', helpers['launcher'])
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    config['bounds'] = harness.BOUNDS
    config['monitor_interval_seconds'] = harness.MONITOR_INTERVAL_SECONDS
    config['selected_source_table_control'] = harness.C4_SELECTION
    target = HELPER / ('execution-config-v3.json' if args.freeze else 'execution-config-draft-v3.json')
    raw = (json.dumps(config, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()
    with target.open('xb') as stream:
        stream.write(raw)
    print(json.dumps({'path': str(target), 'bytes': len(raw), 'sha256': sha256(raw).hexdigest(),
        'frozen': args.freeze, 'selected_sources': len(rows)}, sort_keys=True))


if __name__ == '__main__':
    main()
