"""Bounded caller/worker plan custody; no effects at import.

Only the parent publishes through EL's existing ArtifactPlane. The worker
waits for the source-bound acknowledgement before each selected native call.
This local inquiry helper does not issue tasks or confer outcome authority.
"""
from hashlib import sha256
import io
import json
from pathlib import Path
import zipfile


MAXIMUM_PLAN_BYTES = 8*1024**2


def rawjson(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()


def write_new(path, raw):
    import os
    if len(raw) > MAXIMUM_PLAN_BYTES:
        raise ValueError('bounded custody member exceeded')
    temporary = path.with_name(path.name+'.pending')
    with temporary.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    # Publish an already complete inode without replacing any old request or
    # acknowledgement. Readers must never see a partly written JSON file.
    os.link(temporary, path)
    temporary.unlink()


def plan_payload(plan):
    rows = []
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, raw in plan.input_files:
            if Path(name).name != name:
                raise ValueError('native plan member must be a basename')
            info = zipfile.ZipInfo('inputs/'+name, date_time=(2026, 10, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
            rows.append({'name': 'inputs/'+name, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
        metadata = {'role': 'selected unrestricted single-point request; no kinetic or qualification claim',
            'identity': plan.identity, 'execution_id': plan.execution_id,
            'output_locator': plan.output_locator, 'argv': plan.program_argv,
            'binary_sha256': plan.binary_sha256, 'parameter_sha256': plan.parameter_sha256,
            'formal_charge': plan.formal_charge, 'unpaired_electrons': plan.unpaired_electrons,
            'all_electron_count': plan.all_electron_count, 'valence_electron_count': plan.valence_electron_count,
            'qm_atom_ids': tuple(atom.atom_id for atom in plan.atoms),
            'complete_field_ids': tuple(row.atom_id for row in plan.field_rows),
            'native_field_ids': plan.native_field_ids,
            'excluded_exact_zero_field_ids': plan.excluded_exact_zero_field_ids,
            'serialized_field_charge_sum': str(plan.native_serialized_field_charge_sum),
            'field_rounding_delta': str(plan.native_field_rounding_delta),
            'inputs': rows, 'reserved_native_objectives': 1}
        archive.writestr('plan.json', rawjson(metadata))
    result = output.getvalue()
    if len(result) > MAXIMUM_PLAN_BYTES:
        raise ValueError('bounded zipped single-point plan exceeded')
    return result


def await_plan_publication(plan, bridge_root, *, whole_deadline, maximum_wait_seconds=30):
    import time
    root = Path(bridge_root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('explicit selected custody bridge root required')
    raw = plan_payload(plan)
    digest = sha256(raw).hexdigest()
    request = root/(plan.execution_id+'.request.json')
    payload = root/(plan.execution_id+'.plan.zip')
    acknowledgement = root/(plan.execution_id+'.ack.json')
    write_new(payload, raw)
    write_new(request, rawjson({'execution_id': plan.execution_id,
        'plan_identity': plan.identity, 'payload_bytes': len(raw), 'payload_sha256': digest,
        'output_locator': plan.output_locator}))
    started = time.monotonic()
    while not acknowledgement.exists():
        if time.monotonic() >= whole_deadline or time.monotonic()-started >= maximum_wait_seconds:
            raise ValueError('plan publication unavailable before native entry')
        time.sleep(.02)
    if acknowledgement.is_symlink() or not acknowledgement.is_file() or acknowledgement.stat().st_size > 65536:
        raise ValueError('bounded regular custody acknowledgement required')
    observed = json.loads(acknowledgement.read_bytes())
    if (observed.get('execution_id') != plan.execution_id or observed.get('plan_identity') != plan.identity
            or observed.get('payload_sha256') != digest or observed.get('genuine_publication_verified') is not True
            or type(observed.get('manifest_sha256')) is not str or len(observed['manifest_sha256']) != 64):
        raise ValueError('exact selected plan publication acknowledgement differs')
    return observed


def publish_pending(bridge_root, publish, *, locator_root):
    """Parent callback publishes and verifies using the real existing plane."""
    root = Path(bridge_root)
    published = []
    for path in sorted(root.glob('*.request.json')):
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
            raise ValueError('bounded regular plan request required')
        key = path.name.removesuffix('.request.json')
        ack = root/(key+'.ack.json')
        if ack.exists():
            continue
        request = json.loads(path.read_bytes())
        if request.get('execution_id') != key:
            raise ValueError('custody request key differs')
        locator = Path(request['output_locator'])
        if locator.parent != Path(locator_root) or locator.name != key or locator.exists():
            raise ValueError('plan custody request outside unused selected native locator')
        payload = root/(key+'.plan.zip')
        if payload.is_symlink() or not payload.is_file() or payload.stat().st_size > MAXIMUM_PLAN_BYTES:
            raise ValueError('bounded regular plan payload required')
        raw = payload.read_bytes()
        if len(raw) != request['payload_bytes'] or sha256(raw).hexdigest() != request['payload_sha256']:
            raise ValueError('plan payload source differs before publication')
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            if len(archive.infolist()) > 5 or sum(info.file_size for info in archive.infolist()) > 16*1024**2:
                raise ValueError('plan archive expanded bound exceeded')
            if archive.testzip() is not None:
                raise ValueError('plan archive source CRC differs')
            metadata = json.loads(archive.read('plan.json'))
            if metadata['identity'] != request['plan_identity'] or metadata['output_locator'] != request['output_locator']:
                raise ValueError('plan source/request identity differs')
            names = tuple(row['name'] for row in metadata['inputs'])
            if (not 1 <= len(names) <= 3 or len(set(names)) != len(names)
                    or any(not name.startswith('inputs/') or Path(name).name != name[7:] for name in names)
                    or len(archive.namelist()) != len(names)+1
                    or set(archive.namelist()) != {'plan.json', *names}):
                raise ValueError('complete declared plan archive census differs')
            for row in metadata['inputs']:
                member = archive.read(row['name'])
                if len(member) != row['bytes'] or sha256(member).hexdigest() != row['sha256']:
                    raise ValueError('full single-point input join differs')
        # The injected parent function must return its authenticated actual
        # manifest byte identity, after writing and verify_manifest.
        manifest = publish(key, raw)
        if type(manifest) is not str or len(manifest) != 64:
            raise ValueError('parent must supply authenticated manifest SHA-256')
        acknowledgement = {**request, 'manifest_sha256': manifest,
            'genuine_publication_verified': True}
        write_new(ack, rawjson(acknowledgement))
        published.append(acknowledgement)
    return published


def await_capture_publication(plan, capture, bridge_root, *, whole_deadline):
    """Retain complete raw directory and await actual caller custody before parse."""
    import time
    root = Path(bridge_root)
    work = Path(plan.output_locator)
    rows = []
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(work.rglob('*')):
            if path.is_symlink():
                raise ValueError('raw capture contains refused symbolic source; retain directory as operational refusal')
            if not path.is_file():
                if path.is_dir():
                    continue
                raise ValueError('raw capture contains refused nonregular source; retain directory as operational refusal')
            if path.stat().st_size > 16*1024**2:
                raise ValueError('raw capture original member exceeds selected bound')
            raw = path.read_bytes()
            name = path.relative_to(work).as_posix()
            rows.append({'name': name, 'bytes': len(raw), 'sha256': sha256(raw).hexdigest()})
            archive.writestr('files/'+name, raw)
        metadata = {'role': 'original single-attempt raw capture; before scientific parsing',
            'plan_identity': plan.identity, 'execution_id': plan.execution_id,
            'output_locator': plan.output_locator, 'program_argv': capture.program_argv,
            'returncode': capture.returncode, 'operational_refusal': capture.operational_refusal,
            'native_failure_files': capture.native_failure_files,
            'stdout_sha256': sha256(capture.stdout).hexdigest(),
            'stderr_sha256': sha256(capture.stderr).hexdigest(),
            'gradient_sha256': None if capture.gradient_bytes is None else sha256(capture.gradient_bytes).hexdigest(),
            'pcgrad_sha256': None if capture.pcgrad_bytes is None else sha256(capture.pcgrad_bytes).hexdigest(),
            'files': rows}
        archive.writestr('capture.json', rawjson(metadata))
    payload = output.getvalue()
    key = plan.execution_id
    digest = sha256(payload).hexdigest()
    write_new(root/(key+'.capture.zip'), payload)
    write_new(root/(key+'.capture-request.json'), rawjson({'execution_id': key,
        'plan_identity': plan.identity, 'output_locator': plan.output_locator,
        'payload_bytes': len(payload), 'payload_sha256': digest}))
    ack = root/(key+'.capture-ack.json')
    started = time.monotonic()
    while not ack.exists():
        if time.monotonic() >= whole_deadline or time.monotonic()-started >= 30:
            raise ValueError('raw publication unavailable before scientific parse')
        time.sleep(.02)
    if ack.is_symlink() or not ack.is_file() or ack.stat().st_size > 65536:
        raise ValueError('bounded regular raw custody acknowledgement required')
    observed = json.loads(ack.read_bytes())
    if (observed.get('execution_id') != plan.execution_id
            or observed.get('plan_identity') != plan.identity or observed.get('payload_sha256') != digest
            or observed.get('genuine_publication_verified') is not True
            or type(observed.get('manifest_sha256')) is not str or len(observed['manifest_sha256']) != 64):
        raise ValueError('raw custody acknowledgement differs')
    return observed


def publish_pending_captures(bridge_root, publish, *, locator_root):
    root = Path(bridge_root)
    published = []
    for path in sorted(root.glob('*.capture-request.json')):
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
            raise ValueError('bounded regular capture request required')
        key = path.name.removesuffix('.capture-request.json')
        ack = root/(key+'.capture-ack.json')
        if ack.exists():
            continue
        request = json.loads(path.read_bytes())
        work = Path(request['output_locator'])
        if request.get('execution_id') != key or work.parent != Path(locator_root) or work.name != key or work.is_symlink() or not work.is_dir():
            raise ValueError('raw custody source outside selected existing native locator')
        payload = root/(key+'.capture.zip')
        if payload.is_symlink() or not payload.is_file() or payload.stat().st_size > MAXIMUM_PLAN_BYTES:
            raise ValueError('bounded regular raw capture payload required')
        raw = payload.read_bytes()
        if len(raw) != request['payload_bytes'] or sha256(raw).hexdigest() != request['payload_sha256']:
            raise ValueError('raw capture payload differs before publication')
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            if len(archive.infolist()) > 64 or sum(info.file_size for info in archive.infolist()) > 32*1024**2 or archive.testzip() is not None:
                raise ValueError('bounded complete native capture archive refused')
            metadata = json.loads(archive.read('capture.json'))
            if (metadata['execution_id'] != key or metadata['plan_identity'] != request['plan_identity']
                    or metadata['output_locator'] != str(work)):
                raise ValueError('raw capture source/request identity differs')
            names = tuple(row['name'] for row in metadata['files'])
            if (len(set(names)) != len(names) or any(Path(n).is_absolute() or '..' in Path(n).parts for n in names)
                    or len(archive.namelist()) != len(names)+1
                    or set(archive.namelist()) != {'capture.json', *('files/'+n for n in names)}):
                raise ValueError('complete declared raw capture archive census differs')
            physical = tuple(p.relative_to(work).as_posix() for p in sorted(work.rglob('*')) if p.is_file())
            if (tuple(sorted(names)) != physical
                    or any(p.is_symlink() or not (p.is_file() or p.is_dir()) for p in work.rglob('*'))):
                raise ValueError('complete original raw physical denominator differs')
            for row in metadata['files']:
                member = archive.read('files/'+row['name'])
                original = work/row['name']
                if original.stat().st_size > 16*1024**2:
                    raise ValueError('original raw capture member overbound')
                native = original.read_bytes()
                if (len(member) != row['bytes'] or sha256(member).hexdigest() != row['sha256']
                        or native != member):
                    raise ValueError('original raw bytes/source/capture join differs')
            by_name = {r['name']: r for r in metadata['files']}
            for name in ('stdout', 'stderr', 'gradient', 'pcgrad'):
                expected = metadata[name+'_sha256']
                filename = name+'.txt' if name in ('stdout', 'stderr') else name
                if expected is not None and by_name.get(filename, {}).get('sha256') != expected:
                    raise ValueError('typed capture/raw member byte identity differs')
        manifest = publish(key, raw)
        if type(manifest) is not str or len(manifest) != 64:
            raise ValueError('authenticated actual capture manifest required')
        acknowledgement = {**request, 'manifest_sha256': manifest,
                           'genuine_publication_verified': True}
        write_new(ack, rawjson(acknowledgement))
        published.append(acknowledgement)
    return published
