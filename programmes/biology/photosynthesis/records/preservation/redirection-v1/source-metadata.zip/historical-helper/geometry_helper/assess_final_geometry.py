"""Independent cold final-coordinate screens for the selected six Rr cases.

This private ordinary-record helper performs no construction, native execution
or custody admission. Its caller must authenticate the exact retained initial
JSON and final native operands. Geometry/contact math follows the independent
initial science replay (SHA5195535e...d0af), not the production constructor.
All formal inventories refer to the INITIAL declared hypothesis. No final
Lewis species, unconstrained minimum, free energy or kinetics is certified.
"""

from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation, localcontext
from itertools import product
from math import acos, atan2, degrees, floor, fsum, hypot, isfinite, sqrt

ANGSTROM_PER_BOHR = Decimal('0.52917726')  # selected native legacy value
INITIAL_PROTOCOL = '00db4578dc01e1e4f53b978f332e54f04e1c80b27493d7c5e3e24266d7ebcb69'
COLUMNS = ('atom_id', 'author_chain', 'author_position', 'component', 'atom_name',
           'element', 'current_x_decimal', 'current_y_decimal', 'current_z_decimal',
           'parent_atom_index', 'coordinate_and_recipe_origin', 'donor_atom_index')
CUTS = (191, 193, 194, 263, 287)
ANGLES = (('C1', 'C2', 'C3'), ('C1', 'C2', 'O2'), ('C3', 'C2', 'O2'),
          ('C2', 'C3', 'C4'), ('C2', 'C3', 'O3'), ('C4', 'C3', 'O3'))
Z = {'H': 1, 'C': 6, 'N': 7, 'O': 8, 'P': 15, 'S': 16, 'Mg': 12}
EXPECTED = {
    'unedited-reference': (81, 50, 13752, -6, 382,
                          {'C': 21, 'H': 35, 'Mg': 1, 'N': 3, 'O': 19, 'P': 2}),
    'D263N': (83, 52, 13754, -5, 382,
              {'C': 21, 'H': 37, 'Mg': 1, 'N': 4, 'O': 18, 'P': 2}),
    'H287N': (78, 47, 13749, -6, 370,
              {'C': 19, 'H': 34, 'Mg': 1, 'N': 2, 'O': 20, 'P': 2}),
}


def need(condition, message):
    if not condition:
        raise ValueError('independent final geometry: ' + message)


def numeric(value, bound, label):
    need(type(value) in (int, float, Decimal), label + ' numeric type')
    if type(value) is Decimal:
        need(value.is_finite(), label + ' finite')
        need(len(str(value)) <= 128 and value.copy_abs() <= Decimal(str(bound)), label + ' bounded')
    else:
        # Bound integers before float conversion (math.isfinite also converts).
        need(type(value) is int or isfinite(value), label + ' finite')
        need(abs(value) <= bound, label + ' bounded')
    result = float(value)
    need(isfinite(result) and (result != 0 or value == 0), label + ' representable')
    return result


def source_point(row):
    values = []
    for token in row[6:9]:
        need(type(token) is str and 0 < len(token) < 100, 'source decimal text')
        try:
            value = Decimal(token)
        except InvalidOperation as exc:
            raise ValueError('independent final geometry: invalid source decimal') from exc
        values.append(numeric(value, 10000, 'source coordinate'))
    return tuple(values)


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b, strict=True))


def dot(a, b):
    return fsum(x * y for x, y in zip(a, b, strict=True))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def length(a):
    return hypot(*a)


def pair(a, b):
    return tuple(sorted((a, b)))


def unit(a):
    size = length(a)
    return None if size <= 1e-12 else tuple(x / size for x in a)


def enolate_geometry(points):
    """Independent cosine-law/plane oracle; degeneracy retains all diagnostics."""
    failures = []
    axis = sub(points['C3'], points['C2'])
    distance = length(axis)
    if not 1.25 <= distance <= 1.45:
        failures.append('C2-C3-outside-1.25-1.45-A')
    angles = []
    for a, center, b in ANGLES:
        name = '-'.join((a, center, b))
        x = length(sub(points[a], points[center]))
        y = length(sub(points[b], points[center]))
        z = length(sub(points[a], points[b]))
        angle = None if x <= 1e-12 or y <= 1e-12 else degrees(
            acos(max(-1., min(1., (x*x + y*y - z*z) / (2*x*y)))))
        angles.append([name, angle])
        if angle is None:
            failures.append(name + '-degenerate-angle')
        elif not 100 <= angle <= 140:
            failures.append(name + '-outside-100-140-deg')
    normal = unit(cross(axis, sub(points['O2'], points['C2'])))
    displacements = [[n, None if normal is None else dot(sub(points[n], points['C2']), normal)]
                     for n in ('C1', 'C2', 'C3', 'C4', 'O2', 'O3')]
    if normal is None:
        failures.append('degenerate-C2-C3-O2-plane')
    elif max(abs(d) for _, d in displacements) > .20:
        failures.append('local-plane-displacement-above-0.20-A')
    uaxis = unit(axis)
    cis = dihedral = None
    if uaxis is not None:
        u, v = sub(points['O2'], points['C2']), sub(points['O3'], points['C3'])
        u = tuple(u[i] - dot(u, uaxis) * uaxis[i] for i in range(3))
        v = tuple(v[i] - dot(v, uaxis) * uaxis[i] for i in range(3))
        if unit(u) is not None and unit(v) is not None:
            cis = dot(u, v)
            dihedral = degrees(atan2(dot(cross(u, v), uaxis), cis))
    if cis is None:
        failures.append('degenerate-cis-projection')
    elif cis <= 0:
        failures.append('not-cis-by-positive-projected-dot')
    return dict(c2_c3_angstrom=distance, trigonal_angles_degrees=angles,
                plane_displacements_angstrom=displacements,
                signed_o2_c2_c3_o3_dihedral_degrees=dihedral,
                cis_projected_dot_angstrom_squared=cis, failures=failures)


def contact_census(coords, edges, examined, cap_pairs):
    """Whole-current-coordinate census; 3 A limits output, never the MM field."""
    adjacency = {i: set() for i in coords}
    for a, b in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    bins = defaultdict(list)
    for identity, point in coords.items():
        bins[tuple(floor(x / 3) for x in point)].append(identity)
    result = []
    for a in sorted(examined):
        point = coords[a]
        cell = tuple(floor(x / 3) for x in point)
        one = adjacency[a]
        two = set().union(*(adjacency[b] for b in one)) if one else set()
        nearby = []
        for offset in product((-1, 0, 1), repeat=3):
            nearby.extend(bins.get(tuple(cell[i] + offset[i] for i in range(3)), ()))
        for b in sorted(nearby):
            if a == b:
                continue
            distance = length(sub(point, coords[b]))
            if distance > 3:
                continue
            category = ('own-omitted-CA-cap-exemption' if pair(a, b) in cap_pairs else
                        'one-bond-neighbor' if b in one else
                        'two-bond-neighbor' if b in two else
                        'severe-nonbonded-overlap' if distance < .70 else
                        'nonbonded-diagnostic')
            result.append(dict(examined_atom_id=a, other_atom_id=b,
                               distance_angstrom=distance, category=category))
    return result


def gradient_metrics(rows):
    flat = [component for row in rows for component in row]
    norm = hypot(*flat)
    return dict(component_count=len(flat), l2_hartree_per_bohr=norm,
                rms_hartree_per_bohr=norm / sqrt(len(flat)) if flat else 0.,
                max_absolute_component_hartree_per_bohr=max(map(abs, flat), default=0.))


def verify_final_geometry(initial_case, final_atom_ids, final_elements,
                          final_coordinates_bohr, final_gradient_eh_per_bohr,
                          field_count, *, final_energy_eh, optimizer_final_energy_eh):
    """Screen one source-bound case; output is diagnostic, not native/custody authority.

    Caller separately admits normal controls/SCC/optimizer completion and exact
    field bytes. Initial JSON must be the unchanged authenticated child product.
    Ordered native coordinates/gradients may be Decimal, float or int, never bool.
    """
    need(type(initial_case) is dict, 'initial ordinary JSON record')
    variant, view = initial_case.get('variant'), initial_case.get('proton_view')
    need(type(variant) is str and variant in EXPECTED and type(view) is str and
         view in ('V2', 'V3'), 'assigned chemical case')
    count, mobile_count, environment_count, charge, electrons, expected_formula = EXPECTED[variant]
    need(initial_case.get('protocol_sha256') == INITIAL_PROTOCOL and
         initial_case.get('inventory_passed') is True and
         initial_case.get('role') == 'unrelaxed-initial-coupled-inventory-not-a-ready-QM-job',
         'initial interpretation/protocol')
    need(initial_case.get('atom_columns') == list(COLUMNS), 'exact initial atom schema')
    rows = initial_case.get('atom_rows')
    need(type(rows) is list and len(rows) == count + environment_count, 'initial complete atom count')
    atoms, initial_coords = {}, {}
    for row in rows:
        need(type(row) is list and len(row) == 12 and type(row[0]) is str and
             0 < len(row[0]) <= 128 and row[0] not in atoms and
             type(row[3]) is str and type(row[4]) is str and type(row[5]) is str and row[5] in Z and
             row[1] in ('A', 'B') and type(row[2]) is int, 'initial atom identity')
        atoms[row[0]], initial_coords[row[0]] = row, source_point(row)
    def identities(key):
        ids = initial_case.get(key)
        need(type(ids) is list and all(type(i) is str and i in atoms for i in ids) and
             len(ids) == len(set(ids)), key + ' complete identities')
        return ids
    qm_order = identities('quantum_atom_ids')
    environment = set(identities('environment_atom_ids'))
    physical = set(identities('physical_atom_ids'))
    changed = set(identities('changed_atom_ids'))
    qm = set(qm_order)
    caps = {i for i, r in atoms.items() if r[3] == 'CAP'}
    need(len(qm) == count and len(environment) == environment_count and
         qm.isdisjoint(environment) and qm | environment == set(atoms) and
         physical == set(atoms) - caps and len(caps) == 5 and caps <= qm,
         'complete initial physical/QM/MM/cap partition')
    formula = dict(Counter(atoms[i][5] for i in qm))
    need(formula == expected_formula and initial_case.get('formula') ==
         [list(v) for v in sorted(formula.items())] and
         initial_case.get('formal_quantum_charge') == charge and
         initial_case.get('electron_count') == electrons and
         sum(Z[atoms[i][5]] for i in qm) - charge == electrons,
         'initial declared formula/Q/electron inventory')
    need(type(final_atom_ids) in (list, tuple) and list(final_atom_ids) == qm_order and
         type(final_elements) in (list, tuple) and list(final_elements) ==
         [atoms[i][5] for i in qm_order], 'native ordered atom ID/element bijection')
    need(type(field_count) is int and field_count == environment_count - 5,
         'reported native field count after five exact-zero CA omissions')
    def native_rows(values, bound, label):
        need(type(values) in (list, tuple) and len(values) == count, label + ' row count')
        result = []
        for row in values:
            need(type(row) in (list, tuple) and len(row) == 3, label + ' xyz shape')
            result.append(tuple(numeric(v, bound, label) for v in row))
        return result
    bohr = native_rows(final_coordinates_bohr, 20000, 'native Bohr coordinate')
    gradients = native_rows(final_gradient_eh_per_bohr, 1e6, 'native gradient')
    coords = dict(initial_coords)
    factor = float(ANGSTROM_PER_BOHR)
    for identity, point in zip(qm_order, bohr, strict=True):
        coords[identity] = tuple(x * factor for x in point)
    native_energy = numeric(final_energy_eh, 1e6, 'final energy')
    optimizer_energy = numeric(optimizer_final_energy_eh, 1e6, 'optimizer final energy')
    native_energy_decimal = final_energy_eh if type(final_energy_eh) is Decimal else Decimal(str(final_energy_eh))
    optimizer_energy_decimal = optimizer_final_energy_eh if type(optimizer_final_energy_eh) is Decimal else Decimal(str(optimizer_final_energy_eh))
    edges = set()
    supplied_edges = initial_case.get('candidate_bonds')
    need(type(supplied_edges) is list, 'initial complete new graph')
    for edge in supplied_edges:
        need(type(edge) is list and len(edge) == 2 and all(type(i) is str for i in edge) and edge[0] in atoms and
             edge[1] in atoms and edge[0] != edge[1], 'initial graph edge')
        p = pair(*edge)
        need(p not in edges, 'initial graph duplicate')
        edges.add(p)
    adjacency = {i: set() for i in atoms}
    for a, b in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    ligand = {atoms[i][4]: i for i in qm if atoms[i][3] == 'RUB'}
    need(len(ligand) == sum(atoms[i][3] == 'RUB' for i in qm), 'unique substrate atom names')
    need(all(n in ligand for n in ('C1', 'C2', 'C3', 'C4', 'C5', 'O2', 'O3', 'O4')),
         'full retained substrate roles')
    fixed_substrate_names = {'P1', 'P2', 'O1P', 'O2P', 'O3P', 'O4P', 'O5P', 'O6P', 'O1', 'O5'}
    need(fixed_substrate_names <= set(ligand), 'ten fixed substrate roles')
    cbs = {i for i in qm if atoms[i][1] == 'A' and atoms[i][2] in CUTS and atoms[i][4] == 'CB'}
    magnesium = {i for i in qm if atoms[i][5] == 'Mg'}
    cb_h = {j for i in cbs for j in adjacency[i] if j in qm and atoms[j][5] == 'H' and j not in caps}
    fixed = {ligand[n] for n in fixed_substrate_names} | cbs | magnesium | cb_h | caps
    mobile = qm - fixed
    need(len(cbs) == 5 and len(magnesium) == 1 and len(cb_h) == 10 and
         all(sum(j in cb_h for j in adjacency[i]) == 2 for i in cbs) and
         len(fixed) == 31 and len(mobile) == mobile_count and
         {'amber:6901', 'amber:6900'} <= mobile, 'common exact fixed/mobile chemical roles')
    cap_pairs = set()
    metadata = initial_case.get('caps')
    need(type(metadata) is list and len(metadata) == 5, 'five declared cap witnesses')
    seen_caps = set()
    for cap in metadata:
        need(type(cap) is dict and all(type(cap.get(key)) is str for key in
             ('cap_atom_id', 'environment_ca_atom_id', 'quantum_cb_atom_id')), 'cap witness identities')
        c, ca, cb = cap['cap_atom_id'], cap['environment_ca_atom_id'], cap['quantum_cb_atom_id']
        need(c in caps and c not in seen_caps and ca in environment and cb in cbs and
             atoms[c][1:3] == atoms[ca][1:3] == atoms[cb][1:3] and
             atoms[ca][4] == 'CA' and pair(c, cb) in edges and pair(ca, cb) not in edges,
             'unordered own-CA cap exemption/source cut')
        seen_caps.add(c)
        cap_pairs.add(pair(c, ca))
    failures = []
    def fail(code, condition):
        if not condition:
            failures.append(code)
    fixed_displacements = [[i, length(sub(coords[i], initial_coords[i]))] for i in qm_order if i in fixed]
    mobile_displacements = [[i, length(sub(coords[i], initial_coords[i]))] for i in qm_order if i in mobile]
    fail('FIXED_COORDINATE_CHANGED', max(d for _, d in fixed_displacements) <= 1e-10)
    fail('MOBILE_DISPLACEMENT_ABOVE_0.75_A', max(d for _, d in mobile_displacements) <= .75)
    geometry = enolate_geometry({n: coords[ligand[n]] for n in ('C1', 'C2', 'C3', 'C4', 'O2', 'O3')})
    failures.extend('GEOMETRY_UNREADY:' + name for name in geometry['failures'])
    def c4_volume(points):
        center = points[ligand['C4']]
        return dot(cross(sub(points[ligand['C3']], center), sub(points[ligand['C5']], center)),
                   sub(points[ligand['O4']], center))
    initial_volume, final_volume = c4_volume(initial_coords), c4_volume(coords)
    fail('C4_STEREOSIGN_CHANGED_OR_DEGENERATE', abs(initial_volume) > 1e-12 and
         abs(final_volume) > 1e-12 and initial_volume * final_volume > 0)
    oq1 = [i for i, r in atoms.items() if r[1:5] == ['A', 191, 'KCX', 'OQ1']]
    need(len(oq1) == 1 and oq1[0] in qm, 'active KCX proton target')
    proton_targets = [('H_a', 'amber:6901', oq1[0] if view == 'V2' else ligand['O2']),
                      ('H_b', 'amber:6900', ligand['O3'] if view == 'V2' else oq1[0])]
    if variant != 'H287N':
        for chain in ('A', 'B'):
            hs = [i for i, r in atoms.items() if r[1:5] == [chain, 287, 'HID', 'HD1']]
            ns = [i for i, r in atoms.items() if r[1:5] == [chain, 287, 'HID', 'ND1']]
            need(len(hs) == len(ns) == 1, 'both source-physical HID287 nuclei/targets')
            proton_targets.append(('His287-' + chain + '-source-HE2', hs[0], ns[0]))
    else:
        need(not any(r[2] == 287 and r[3] == 'HID' for r in atoms.values()), 'H287N retains no HID287 recipe')
    on_ids = sorted(i for i, r in atoms.items() if r[5] in ('N', 'O'))
    proton_reports = []
    for label, proton, target in proton_targets:
        need(proton in atoms and atoms[proton][5] == 'H' and target in adjacency[proton] and
             len(adjacency[proton]) == 1, 'initial assigned physical proton graph')
        distances = sorted((length(sub(coords[proton], coords[i])), i) for i in on_ids)
        intended = length(sub(coords[proton], coords[target]))
        competition = min((d, i) for d, i in distances if i != target)
        margin = competition[0] - intended
        passed = .85 <= intended <= 1.15 and margin >= .10
        fail('PROTON_STATE_ESCAPED:' + proton, passed)
        proton_reports.append(dict(identity=label, physical_atom_id=proton, intended_target_id=target,
                                   intended_distance_angstrom=intended,
                                   nearest_on_id=distances[0][1], nearest_on_distance_angstrom=distances[0][0],
                                   nearest_competitor_id=competition[1], nearest_competitor_distance_angstrom=competition[0],
                                   intended_margin_angstrom=margin, passed=passed,
                                   competitors=[[i, d] for d, i in distances],
                                   scope='All N/O geometric competition; no chemical-acceptor competence certification'))
    reactive = {pair(ligand['C2'], ligand['C3']), pair(ligand['C2'], ligand['O2']),
                pair(ligand['C3'], ligand['O3'])}
    checked_protons = {p for _, p, _ in proton_targets}
    bond_reports = []
    for a, b in sorted(edges):
        if not {a, b} <= qm or (a, b) in reactive or {a, b} & checked_protons:
            continue
        old, new = length(sub(initial_coords[a], initial_coords[b])), length(sub(coords[a], coords[b]))
        ratio = None if old <= 1e-12 else new / old
        passed = ratio is not None and .75 <= ratio <= 1.25
        fail('NONREACTIVE_BOND_DISTORTED:' + a + ':' + b, passed)
        bond_reports.append(dict(first_atom_id=a, second_atom_id=b, initial_length_angstrom=old,
                                 final_length_angstrom=new, ratio=ratio, passed=passed))
    examined = mobile | changed
    contacts = contact_census(coords, edges, examined, cap_pairs)
    severe = [c for c in contacts if c['category'] == 'severe-nonbonded-overlap']
    failures.extend('SEVERE_NONBONDED_OVERLAP:' + c['examined_atom_id'] + ':' + c['other_atom_id'] for c in severe)
    free_metrics = gradient_metrics([r for i, r in zip(qm_order, gradients, strict=True) if i in mobile])
    fixed_metrics = gradient_metrics([r for i, r in zip(qm_order, gradients, strict=True) if i in fixed])
    full_metrics = gradient_metrics(gradients)
    fail('NONSTATIONARY', free_metrics['l2_hartree_per_bohr'] <= 3e-4)
    # Raw native f24.12 energy tokens are Decimal. Preserve their exact boundary
    # test; subtracting their binary64 projections can reverse the equality case.
    with localcontext() as context:
        context.prec = 512  # bounded operands; independent of caller context
        energy_difference_decimal = abs(native_energy_decimal - optimizer_energy_decimal)
    fail('RECALC_DISAGREEMENT', energy_difference_decimal <= Decimal('0.000001'))
    proton_survived = all(p['passed'] for p in proton_reports)
    return dict(role='independent-final-nuclear-geometry-diagnostics-not-native-convergence-or-kinetics',
                variant=variant, proton_view=view,
                status='DIAGNOSTIC_SCREENS_PASSED' if not failures else 'DIAGNOSTIC_SCREENS_FAILED',
                failures=failures, atom_count=count, fixed_atom_ids=[i for i in qm_order if i in fixed],
                mobile_atom_ids=[i for i in qm_order if i in mobile], scientific_environment_atoms=environment_count,
                reported_native_nonzero_field_atoms=field_count, native_legacy_angstrom_per_bohr=str(ANGSTROM_PER_BOHR),
                enolate_geometry=geometry, fixed_displacements_angstrom=fixed_displacements,
                mobile_displacements_angstrom=mobile_displacements,
                c4_signed_volume_angstrom_cubed=dict(initial=initial_volume, final=final_volume),
                proton_geometry=proton_reports, proton_arrangement_survived=proton_survived,
                nonreactive_bond_lengths=bond_reports,
                reactive_bond_exemptions=[list(p) for p in sorted(reactive)],
                separately_screened_proton_bond_ids=sorted(checked_protons),
                contact_examined_atom_ids=sorted(examined), contacts_within_3_angstrom=contacts,
                severe_overlap_count=len(severe), own_ca_cap_exemptions=[list(p) for p in sorted(cap_pairs)],
                gradient_metrics=dict(free=free_metrics, fixed=fixed_metrics, full=full_metrics),
                energy_agreement=dict(optimizer_final_hartree=optimizer_energy, fresh_final_hartree=native_energy,
                                      optimizer_final_decimal=str(optimizer_energy_decimal),
                                      fresh_final_decimal=str(native_energy_decimal),
                                      absolute_difference_decimal=str(energy_difference_decimal),
                                      absolute_difference_hartree=float(energy_difference_decimal)),
                initial_declared_inventory=dict(formula=initial_case['formula'], formal_quantum_charge=charge,
                                                electron_count=electrons, scope='INITIAL hypothesis inventory only'),
                final_lewis_species_certified=False, unconstrained_minimum_certified=False,
                free_energy_or_barrier_certified=False, final_native_convergence_certified=False,
                field_payload_authenticated_by_this_helper=False, native_calls=0, source_constructors=0)
