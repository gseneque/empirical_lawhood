"""Prospective retained-reference worker. Native entry requires frozen caller."""
import argparse
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time
import traceback
from types import MethodType

MIB = 1024**2


def rawjson(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+"\n").encode()


def read(row, maximum=16*MIB):
    path=Path(row["path"])
    if not path.is_absolute() or path.is_symlink() or not path.is_file() or path.stat().st_size>maximum:
        raise ValueError("bounded exact frozen source required")
    raw=path.read_bytes()
    if len(raw)!=row["bytes"] or sha256(raw).hexdigest()!=row["sha256"]:
        raise ValueError("frozen source identity differs")
    return raw


def load(row,name):
    raw=read(row,128*1024)
    spec=importlib.util.spec_from_file_location(name,row["path"])
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    exec(compile(raw,row["path"],"exec"),module.__dict__)
    return module


def write_new(path,value):
    raw=value if type(value) is bytes else (json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
    if len(raw)>16*MIB:raise ValueError("bounded ordinary worker member required")
    with Path(path).open("xb") as f:f.write(raw)


def write_structured(path,value,*,always_chunk=False):
    """Keep exact JSON semantics with bounded ordinary chunks and whole joins."""
    path=Path(path)
    if path.exists() or Path(str(path)+".join.json").exists() or path.is_symlink():
        raise ValueError("new structured output locator required")
    raw=(json.dumps(value,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
    if len(raw)>32*MIB:
        raise ValueError("bounded complete structured output required")
    if not always_chunk and len(raw)<=8*MIB:
        write_new(path,raw)
        return {"path":str(path),"bytes":len(raw),"sha256":sha256(raw).hexdigest(),"encoding":"compact-json"}
    rows=[]
    for i in range(0,len(raw),8*MIB):
        piece=raw[i:i+8*MIB]
        target=path.with_name(path.name+f".part-{i//(8*MIB):04d}")
        write_new(target,piece)
        rows.append({"name":target.name,"bytes":len(piece),"sha256":sha256(piece).hexdigest()})
    join={"whole_bytes":len(raw),"whole_sha256":sha256(raw).hexdigest(),"ordered_chunks":rows,
          "encoding":"compact-json-ordered-chunks"}
    target=Path(str(path)+".join.json")
    write_new(target,join)
    join_raw=target.read_bytes()
    return {"path":str(target),"bytes":len(join_raw),"sha256":sha256(join_raw).hexdigest(),
            "encoding":"compact-json-ordered-chunks","whole_bytes":len(raw),"whole_sha256":sha256(raw).hexdigest()}


def retain_force_observation(root,stage,snapshot,observations):
    """Retain whole pre-guard native data in bounded ordered ordinary chunks."""
    if stage not in {"before-ash-masks","after-ash-masks"} or type(snapshot) is not dict:
        raise ValueError("exact selected force observation stage and plain mapping required")
    if any(row["stage"]==stage for row in observations):
        raise ValueError("duplicate native force observation stage")
    raw=(json.dumps(snapshot,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
    if len(raw)>32*MIB:
        raise ValueError("bounded whole native force observation required")
    chunks=[]
    for i in range(0,len(raw),8*MIB):
        piece=raw[i:i+8*MIB]
        name=stage+f".part-{i//(8*MIB):04d}"
        write_new(root/name,piece)
        chunks.append({"name":name,"bytes":len(piece),"sha256":sha256(piece).hexdigest()})
    record={"role":"raw live native force observation before admission guards; no successful masking, Context or energy/force evaluation claim",
        "stage":stage,"whole_bytes":len(raw),"whole_sha256":sha256(raw).hexdigest(),"ordered_chunks":chunks}
    write_new(root/(stage+".join.json"),record)
    observations.append(record)
    return record


def instrument_session(session,journal_path,counters,check_sources):
    """Observe genuine methods without replacing force/gradient behavior."""
    if journal_path.exists() or journal_path.is_symlink():
        raise ValueError("new selected native effect journal required")
    with journal_path.open("xb"):
        pass
    def event(kind,status):
        raw=(json.dumps({"kind":kind,"status":status,"monotonic":time.monotonic(),"counters":dict(counters)},sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
        with journal_path.open("ab") as f:
            f.write(raw);f.flush()
    classical=session.theory.mm_theory
    create=classical.create_simulation
    original_mm=classical.run
    original_run=session.theory.run
    if not callable(create) or not callable(original_run) or not callable(original_mm):
        raise ValueError("source-selected native method hooks missing")
    def observed_create(self,*args,**kwargs):
        counters["classical_create_simulation_attempts"]+=1;event("classical_create_simulation","ENTERED")
        try:result=create(*args,**kwargs)
        except BaseException:
            event("classical_create_simulation","REFUSED");raise
        counters["classical_create_simulation_returns"]+=1;event("classical_create_simulation","RETURNED")
        # Native Context setup can lazily map libraries. Refuse any unbound
        # source immediately before the caller resumes MM energy/force work.
        check_sources();event("source_closure_after_simulation","VERIFIED")
        return result
    def observed_mm(self,*args,**kwargs):
        counters["MM_run_attempts"]+=1;event("MM_run","ENTERED")
        try:result=original_mm(*args,**kwargs)
        except BaseException:
            event("MM_run","REFUSED");raise
        counters["MM_run_returns"]+=1;event("MM_run","RETURNED")
        return result
    def observed_run(self,*args,**kwargs):
        counters["coupled_run_attempts"]+=1;event("coupled_run","ENTERED")
        try:result=original_run(*args,**kwargs)
        except BaseException:
            event("coupled_run","REFUSED");raise
        counters["coupled_run_returns"]+=1;event("coupled_run","RETURNED")
        return result
    classical.create_simulation=MethodType(observed_create,classical)
    classical.run=MethodType(observed_mm,classical)
    session.theory.run=MethodType(observed_run,session.theory)
    return counters


def main():
    parser=argparse.ArgumentParser()
    for name in ("config","sha256","work","prefit-sha256","started","deadline"):
        parser.add_argument("--"+name,required=True)
    args=parser.parse_args()
    config_raw=Path(args.config).read_bytes()
    if len(config_raw)>4*MIB or sha256(config_raw).hexdigest()!=args.sha256:
        raise ValueError("frozen configuration differs")
    config=json.loads(config_raw)
    if config.get("scientific_protocol_frozen") is not True:
        raise ValueError("draft cannot enter native reference")
    work=Path(args.work)
    if not work.is_absolute() or work.is_symlink() or not work.is_dir() or any(work.iterdir()):
        raise ValueError("explicit selected unused worker directory required")
    started,deadline=float(args.started),float(args.deadline)
    if deadline!=started+1200 or not 0<started<=time.monotonic()<deadline:
        raise ValueError("selected fresh whole allocation differs")
    resource.setrlimit(resource.RLIMIT_CPU,(800,800))
    resource.setrlimit(resource.RLIMIT_AS,(6*1024**3,)*2)
    resource.setrlimit(resource.RLIMIT_FSIZE,(16*MIB,)*2)
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_NOFILE,(256,256))
    if any(os.environ.get(k)!=v for k,v in config["worker_environment"].items()):
        raise ValueError("realized worker environment differs")
    report={"role":"one exposed retained-reference coupling/repair; no kinetics or qualification",
        "native_case_status":"UNENTERED","controls":"REUSED_UNVERIFIED","capacity":"REUSED_UNVERIFIED",
        "new_control_callbacks":0,"new_capacity_callbacks":0,"new_native_preparations":0,
        "new_original_nonbonded_admissions":0,"new_coupled_source_admissions":0,
        "new_exposed_context_reconstructions":0,"coupled_source_admission_attempts":0,
        "exposed_context_reconstruction_attempts":0,"retained_coupling_attempts":0,
        "retained_couplings_returned":0,"native_case_denominator":1,"refusal":None,
        "native_force_observations":[],
        "source_table_control":{"id":"c4-source-table","status":"UNENTERED"},
        "final_source_closure_refusal":None,"protocol_sha256":config["protocol"]["sha256"],
        "prefit_manifest_sha256":args.prefit_sha256}
    counters={"classical_create_simulation_attempts":0,"classical_create_simulation_returns":0,
              "coupled_run_attempts":0,"coupled_run_returns":0,"MM_run_attempts":0,"MM_run_returns":0}
    entered=[];runtimes=[];guard=profile=harness=None
    def native_audit(event,values):
        if event=="subprocess.Popen":
            if values[0]!=config["binary"]["path"]:
                raise RuntimeError("unselected worker program: "+repr(values[0]))
            entered.append({"program":str(values[0]),"argv":tuple(str(v) for v in values[1]),
                            "cwd":None if values[2] is None else os.fspath(values[2])})
        elif event in {"os.fork","os.forkpty","os.posix_spawn","os.exec"}:
            raise RuntimeError("unselected worker process primitive: "+event)
    sys.addaudithook(native_audit)
    try:
        for row in config["selected_sources"]:read(row)
        read(config["protocol"],128*1024)
        profile=json.loads(read(config["profile"],8*MIB))
        harness=load(config["launcher"],"_retained_reference_worker_harness")
        harness.verify_python_cache(config)
        harness.authenticate_profile(profile)
        guard=load(config["source_guard"],"_retained_reference_source_guard")
        manifest=work.parent/"prefit-barrier.json.manifest.json"
        if manifest.is_symlink() or not manifest.is_file() or sha256(manifest.read_bytes()).hexdigest()!=args.prefit_sha256:
            raise ValueError("genuine preentry manifest byte join differs")
        barrier=json.loads((work.parent/"prefit-barrier.json").read_bytes())
        if barrier["configuration_sha256"]!=args.sha256 or barrier["protocol_sha256"]!=config["protocol"]["sha256"]:
            raise ValueError("preentry config/protocol join differs")
        if harness.validate_scope(config,entered_worker_packet=True)!=work.parent:
            raise ValueError("worker packet does not join entered parent scope")
        for name in ("ash_user_settings.ini",".ncrc",".netcdfrc",".xtbrc"):
            if (Path(os.environ["HOME"])/name).exists() or (Path(os.environ["HOME"])/name).is_symlink():
                raise ValueError("unselected native user settings exist: "+name)
        sys.path.insert(0,config["el_source_root"])
        from empirical_lawhood.adapters.simulators.rubisco_electronic import rr_qmmm_xtb as qm
        if Path(qm.__file__).resolve()!=Path(config["qm_owner"]["path"]):
            raise ValueError("actual EL owner resolves to another checkout")
        executor_module=load(config["bounded_executor"],"_retained_reference_executor")
        bridge=load(config["custody_bridge"],"_retained_reference_worker_bridge")
        coupling=load(config["native_coupling"],"_retained_reference_coupling")
        assessment=load(config["reference_assessment"],"_retained_reference_assessment")
        report["profile_before_native_import"]=guard.loaded_profile(profile,config["selected_sources"])
        libs=coupling.load_bound_native_libraries(protocol_sha256=config["protocol"]["sha256"],site_packages=config["native_site_packages"])
        report["profile_after_native_import"]=guard.loaded_profile(profile,config["selected_sources"])
        controls=json.loads(read(config["retained_completed_controls"]))
        control_summary=json.loads(read(config["retained_completed_summary"]))
        if controls.get("status")!="PASS" or control_summary["worker_report"]["capacity"]["status"]!="PASS":
            raise ValueError("receipt-bound prior controls/capacity missing")
        report["controls"]=controls;report["capacity"]=control_summary["worker_report"]["capacity"]
        report["reused_control_scope"]={"fresh_biological_evidence":False,"new_native_control_contexts":0,
            "new_control_callbacks":0,"new_capacity_callbacks":0,"controls_source":config["retained_completed_controls"],
            "capacity_summary_source":config["retained_completed_summary"]}
        # One ordinary native-free typed source/context restoration supports the
        # unchanged reference_assessment intake; no Amber native preparation.
        from empirical_lawhood.adapters.physical.rubisco_kinetics import rr_coupled_preparation as preparation
        from empirical_lawhood.adapters.simulators.rubisco_electronic import rr_xtb_repair as old
        operands=tuple(read(row) for row in config["coupled_sources"])
        if len(operands)!=7:raise ValueError("complete seven-operand cold source roster required")
        report["coupled_source_admission_attempts"]=1
        source=preparation.decode_rr_coupled_source(*operands[:4],operands[4:])
        report["new_coupled_source_admissions"]=1
        report["exposed_context_reconstruction_attempts"]=1
        job=old.RrXtbRepairInputV1(source,read(config["held_reference_v2"]))
        report["new_exposed_context_reconstructions"]=1
        plan_join=json.loads(read(config["reference_plan_join"]))
        plan=harness.joined_bytes(plan_join,Path(config["reference_plan_join"]["path"]).parent)
        bindings=coupling.RetainedPreparationBindings(reference_manifest_bytes=plan,
            preparation_report_bytes=read(config["retained_preparation_report"]),
            derived_reloaded_witness_bytes=read(config["retained_reload_witness"]),
            derived_prmtop_path=Path(config["derived_prmtop"]["path"]),
            closed_census_sha256=config["retained_preparation_census"]["sha256"])
        cases=work/"cases";cases.mkdir();case=cases/"reference-v2";case.mkdir()
        calls=case/"calls";calls.mkdir();br=case/"bridge";br.mkdir()
        allocation=executor_module.ExecutorAllocation(str(calls),config["binary"]["path"],config["binary"]["sha256"],
            config["parameters"]["path"],config["parameters"]["sha256"],101,800,1200,30,60,6*1024**3,
            16*MIB,config["native_case_output_bytes"])
        executor=executor_module.BoundedExecutor(allocation,capture_type=qm.XtbSinglePointCaptureV1,whole_started_monotonic=started)
        def selected_executor(native_plan):
            if sum(t.callback_reservations for t,_ in runtimes)>101:
                raise ValueError("whole reference objective cap exhausted")
            guard.loaded_profile(profile,config["selected_sources"])
            harness.verify_python_cache(config)
            bridge.await_plan_publication(native_plan,br,whole_deadline=deadline)
            return executor(native_plan)
        def retain(native_plan,capture):
            bridge.await_capture_publication(native_plan,capture,br,whole_deadline=deadline)
        quantum=qm.StrictQmmmXtbTheoryV1(executable_path=allocation.binary,parameter_path=allocation.parameter,
            output_root=str(calls),executor=selected_executor,retain_capture=retain,maximum_callbacks=101)
        runtimes.append((quantum,executor))
        report["retained_coupling_attempts"]=1
        def observed_load(stage,structure):
            if stage!="retained-derived-loaded":
                raise ValueError("unselected native load observation stage")
            report["retained_native_topology_loads_observed"]=report.get("retained_native_topology_loads_observed",0)+1
        force_root=work/"native-force-observations";force_root.mkdir()
        def observed_forces(stage,snapshot):
            retain_force_observation(force_root,stage,snapshot,report["native_force_observations"])
        session=coupling.build_retained_reference_coupling(bindings,quantum,scratch_directory=case/"model",
            protocol_sha256=config["protocol"]["sha256"],native_libraries=libs,observe_native=observed_load,
            observe_forces=observed_forces)
        report["retained_couplings_returned"]=1
        report["native_construction_audit"]=write_structured(work/"reference-native-construction.json",session.audit,always_chunk=True)
        report["profile_after_reference_construction"]=guard.loaded_profile(profile,config["selected_sources"])
        def check_sources():
            guard.loaded_profile(profile,config["selected_sources"])
            harness.verify_python_cache(config)
        instrument_session(session,work/"native-effect-journal.jsonl",counters,check_sources)
        control=load(config["source_table_control"],"_retained_reference_source_table_control")
        report["source_table_control"]={"id":"c4-source-table","status":"ENTERED"}
        report["source_table_control"]=control.run_source_table_control(libs,session,
            json.loads(read(config["retained_reload_witness"])),work/"source-table-control",check_sources)
        if report["source_table_control"].get("status")!="PASS":
            raise ValueError("new source-table native conformance refused before enzyme objective")
        report["native_case_status"]="ENTERED"
        report["reference"]=assessment.run_reference_repair(libs,session,quantum,job,work/"reference-observations",config)
        report["native_case_status"]=report["reference"]["status"]
    except BaseException as exc:
        report["native_case_status"]="REFUSED"
        report["refusal"]={"type":type(exc).__name__,"message":str(exc)}
        write_new(work/"worker-refusal-traceback.txt",traceback.format_exc().encode())
    finally:
        control_result=work/"source-table-control"/"source-table-control-report.json"
        if control_result.is_file():
            try:
                if control_result.stat().st_size>16*MIB or control_result.is_symlink():
                    raise ValueError("bounded actual source-table control report required")
                report["source_table_control"]=json.loads(control_result.read_bytes())
            except BaseException as exc:
                report["source_table_control_report_refusal"]={"type":type(exc).__name__,"message":str(exc)}
        if guard is not None and profile is not None:
            try:
                report["profile_after_work"]=guard.loaded_profile(profile,config["selected_sources"])
                harness.verify_python_cache(config)
            except BaseException as exc:
                report["final_source_closure_refusal"]={"type":type(exc).__name__,"message":str(exc)}
        own=resource.getrusage(resource.RUSAGE_SELF);children=resource.getrusage(resource.RUSAGE_CHILDREN)
        report["own_CPU_seconds_before_serialization"]=own.ru_utime+own.ru_stime
        report["waited_child_CPU_seconds_before_serialization"]=children.ru_utime+children.ru_stime
        report["elapsed_whole_seconds_before_serialization"]=time.monotonic()-started
        report["native_effect_counters"]=counters
        report["native_counter_basis"]="actual classical.create_simulation, classical MM.run, and full coupled theory.run method attempts/returns; MM.run attempts may fail before energy/force kernel; internal getState/force-kernel invocation counts are not separately instrumented"
        report["internal_MM_force_kernel_invocations"]="UNIDENTIFIED; method-entry counters are not kernel counts"
        report["attempted_callback_reservations"]=sum(t.callback_reservations for t,_ in runtimes)
        report["native_processes_started"]=sum(e.started_processes for _,e in runtimes)
        report["attempted_Popen_audit_event_count"]=len(entered)
        report["attempted_Popen_audit_events"]=entered
        report["executor_observations"]=[x for _,e in runtimes for x in e.observations]
        write_structured(work/"worker-report.json",report)


if __name__=="__main__":main()
