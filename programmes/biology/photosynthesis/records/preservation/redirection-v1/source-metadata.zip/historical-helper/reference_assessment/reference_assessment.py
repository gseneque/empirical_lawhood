"""Deferred, finite reference-V2 coupled repair and ordinary diagnostics.

Discovery imports only stdlib. The selected caller owns scientific authority,
native/profile/source admission, resources and custody. This helper neither
certifies a species nor estimates an enzyme rate. Its optimizer is existing
ASH/geomeTRIC; its geometry assessor is the unchanged independently bound one.
"""

from contextlib import contextmanager
from decimal import Decimal, localcontext
import gzip
from hashlib import sha256
import importlib.util
import json
import math
from pathlib import Path
import re
import sys
from types import MethodType


ASH_BOHR_ANGSTROM = Decimal("0.5291772109303")
LEGACY_BOHR_ANGSTROM = Decimal("0.52917726")
MAXIMUM_MEMBER_BYTES = 16 * 1024**2
MAXIMUM_OPTIMIZER_CALLBACKS = 100
MAXIMUM_TOTAL_CALLBACKS = 101
PHYSICAL_ATOMS = 13828
CONVERGENCE_CRITERIA = {
    "convergence_energy": 1e-7,
    "convergence_grms": 1e-5,
    "convergence_gmax": 3e-5,
    "convergence_drms": 1e-3,
    "convergence_dmax": 2e-3,
    "convergence_cmax": 1e-2,
}


def _finite(value):
    if isinstance(value, bool):
        raise ValueError("Boolean is not a physical numeric operand")
    result = float(value)
    if not math.isfinite(result) or abs(result) > 1e8:
        raise ValueError("finite bounded physical operand required")
    return result


def _rows(value, count):
    if len(value) != count:
        raise ValueError("complete physical/native row denominator differs")
    rows = tuple(tuple(_finite(v) for v in row) for row in value)
    if any(len(row) != 3 for row in rows):
        raise ValueError("three Cartesian components per atom required")
    return rows


def _exact_read(binding):
    path = Path(binding["path"])
    if (
        path.is_symlink()
        or not path.is_file()
        or path.stat().st_size > MAXIMUM_MEMBER_BYTES
    ):
        raise ValueError("bounded ordinary exact source required")
    raw = path.read_bytes()
    if len(raw) != binding["bytes"] or sha256(raw).hexdigest() != binding["sha256"]:
        raise ValueError("selected source byte binding differs")
    return raw


def _write_new(path, value, *, compressed=False):
    raw = (
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n"
    ).encode()
    if len(raw) > MAXIMUM_MEMBER_BYTES:
        raise ValueError("expanded observation member exceeds sixteen MiB")
    stored = gzip.compress(raw, compresslevel=6, mtime=0) if compressed else raw
    if len(stored) > MAXIMUM_MEMBER_BYTES:
        raise ValueError("physical observation member exceeds sixteen MiB")
    with path.open("xb") as stream:
        stream.write(stored)
    return {
        "path": str(path),
        "bytes": len(stored),
        "sha256": sha256(stored).hexdigest(),
        "expanded_bytes": len(raw),
        "expanded_sha256": sha256(raw).hexdigest(),
        "encoding": "deterministic-gzip-json" if compressed else "json",
    }


@contextmanager
def _selected_cwd(path):
    import os

    before = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(before)


def _load_geometry(binding):
    _exact_read(binding)
    name = "selected_independent_qmmm_geometry_" + binding["sha256"][:16]
    spec = importlib.util.spec_from_file_location(name, binding["path"])
    if spec is None or spec.loader is None:
        raise ValueError("selected independent geometry module is unavailable")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if not callable(getattr(module, "verify_final_geometry", None)):
        raise ValueError("selected independent geometry entry differs")
    return module.verify_final_geometry


def _gradient_metrics(rows):
    values = tuple(v for row in rows for v in row)
    norm = math.sqrt(math.fsum(v * v for v in values))
    return {
        "components": len(values),
        "l2": norm,
        "rms": norm / math.sqrt(len(values)) if values else 0.0,
        "max_abs_component": max(map(abs, values), default=0.0),
        "unit": "Eh/native-legacy-Bohr",
    }


def _legacy_gradient(rows):
    with localcontext() as context:
        context.prec = 50
        ratio = LEGACY_BOHR_ANGSTROM / ASH_BOHR_ANGSTROM
        return tuple(tuple(float(Decimal(str(v)) * ratio) for v in row) for row in rows)


def _exact_energy_difference(first, second):
    with localcontext() as context:
        context.prec = 50
        return abs(Decimal(str(first)) - Decimal(str(second)))


def _callback_projection(observation):
    if observation is None:
        raise ValueError("selected successful callback observation is absent")
    p, c = observation.plan, observation.capture
    if (
        c.returncode != 0
        or c.operational_refusal
        or c.native_failure_files
        or len(p.atoms) != 81
        or len(p.field_rows) != 13752
        or len(p.native_field_ids) != 13747
        or p.formal_charge != -6
        or p.unpaired_electrons != 0
    ):
        raise ValueError("reference complete selected callback inventory differs")
    return {
        "execution_id": p.execution_id,
        "plan_identity": p.identity,
        "energy_hartree": str(observation.energy_hartree),
        "coordinates_bohr": tuple(
            tuple(str(v) for v in row) for row in p.coordinates_bohr
        ),
        "native_writer_coordinates_bohr": tuple(
            tuple(str(v) for v in row)
            for row in observation.native_gradient_coordinates_bohr
        ),
        "gradient_hartree_per_native_bohr": tuple(
            tuple(str(v) for v in row) for row in observation.qm_gradient_native
        ),
        "ordered_elements": tuple(a.element for a in p.atoms),
        "native_nonzero_field_atoms": len(p.native_field_ids),
        "full_field_atoms": len(p.field_rows),
        "scc_iterations": observation.scc_iterations,
        "raw_gradient_sha256": sha256(c.gradient_bytes).hexdigest(),
        "raw_pcgrad_sha256": sha256(c.pcgrad_bytes).hexdigest(),
        "scope": "actual admitted native QM gradient; partial component of coupled force",
    }


def _intake(session, job, initial):
    context = job.context
    if context.variant != "unedited-reference" or context.proton_view != "V2":
        raise ValueError("only assigned reference-V2 repair is selected")
    physical_ids = tuple(a.atom_id for a in context.physical_atoms)
    if physical_ids != tuple(f"amber:{i}" for i in range(1, PHYSICAL_ATOMS + 1)):
        raise ValueError("complete original source physical order differs")
    original = tuple(
        tuple(float(v) for v in a.coordinates) for a in context.physical_atoms
    )
    active, fixed = (
        tuple(session.active_atom_indices),
        tuple(session.fixed_atom_indices),
    )
    if (
        (len(active), len(fixed)) != (50, 13778)
        or set(active) & set(fixed)
        or set(active) | set(fixed) != set(range(PHYSICAL_ATOMS))
    ):
        raise ValueError("complete fifty-active/fixed-physical denominator differs")
    if _rows(session.fragment.coords, PHYSICAL_ATOMS) != original:
        raise ValueError("native preparation changed selected physical coordinates")
    qindices = tuple(map(int, session.theory.qmatoms))
    link_rows = session.audit["links"]["links"]
    ash_ids = tuple(physical_ids[i] for i in qindices) + tuple(
        row[0] for row in link_rows
    )
    held_ids = tuple(initial["quantum_atom_ids"])
    if (
        (len(qindices), len(link_rows), len(ash_ids), len(held_ids)) != (76, 5, 81, 81)
        or len(set(ash_ids)) != 81
        or set(ash_ids) != set(held_ids)
    ):
        raise ValueError("source-held/ASH real-QM/link atom ID bijection differs")
    expected_ids = tuple(a.atom_id for a in context.quantum_atoms)
    if held_ids != expected_ids:
        raise ValueError("held initial projection does not match sealed source context")
    held_elements = tuple(a.element for a in context.quantum_atoms)
    ash_index = {identity: i for i, identity in enumerate(ash_ids)}
    reorder = tuple(ash_index[identity] for identity in held_ids)
    generated = tuple(tuple(map(float, row[5])) for row in link_rows)
    if len(generated) != 5 or any(len(row) != 3 for row in generated):
        raise ValueError("complete initially generated cap witnesses are absent")
    return (
        physical_ids,
        original,
        active,
        fixed,
        held_ids,
        held_elements,
        reorder,
        generated,
    )


def _assemble_diagnostics(
    geometry_verifier,
    initial,
    held_ids,
    held_elements,
    reorder,
    fresh_callback,
    last_opt_callback,
    fresh_energy,
    last_opt_energy,
    full_gradient,
    active,
    fixed,
    final,
    original,
    caps_fixed,
):
    native_coords = tuple(
        tuple(Decimal(v) for v in fresh_callback["coordinates_bohr"][i])
        for i in reorder
    )
    native_gradient = tuple(
        tuple(Decimal(v) for v in fresh_callback["gradient_hartree_per_native_bohr"][i])
        for i in reorder
    )
    if tuple(fresh_callback["ordered_elements"][i] for i in reorder) != held_elements:
        raise ValueError("actual native row element/held ID mapping differs")
    geometry = geometry_verifier(
        initial,
        held_ids,
        held_elements,
        native_coords,
        native_gradient,
        fresh_callback["native_nonzero_field_atoms"],
        final_energy_eh=Decimal(fresh_callback["energy_hartree"]),
        optimizer_final_energy_eh=Decimal(last_opt_callback["energy_hartree"]),
    )
    # Keep the entire genuine QM-force diagnostic. Only its NONSTATIONARY
    # classification is replaced by the declared total coupled-force test.
    geometry_failures = [
        code for code in geometry["failures"] if code != "NONSTATIONARY"
    ]
    legacy_gradient = _legacy_gradient(full_gradient)
    free = _gradient_metrics(tuple(legacy_gradient[i] for i in active))
    fixed_force = _gradient_metrics(tuple(legacy_gradient[i] for i in fixed))
    total_force = _gradient_metrics(legacy_gradient)
    energy_delta = _exact_energy_difference(fresh_energy, last_opt_energy)
    physical_exact = all(final[i] == original[i] for i in fixed)
    displacements = tuple(math.dist(final[i], original[i]) for i in fixed)
    checks = {
        "fixed_physical_coordinates_exact": physical_exact,
        "five_generated_caps_exact": caps_fixed,
        "total_coupled_mobile_stationarity": free["l2"] <= 3e-4,
        "total_coupled_energy_agreement": energy_delta <= Decimal("0.000001"),
        "unchanged_geometry_proton_contact_screens": not geometry_failures,
    }
    failures = list(geometry_failures)
    for label, passed in checks.items():
        if not passed:
            failures.append("COUPLED:" + label)
    return {
        "status": "CONSTRAINED_REFERENCE_REPAIR_SCREENS_PASSED"
        if not failures
        else "REFERENCE_REPAIR_SCREENS_FAILED",
        "checks": checks,
        "failures": failures,
        "full_independent_partial_qm_gradient_diagnostic": geometry,
        "geometry_only_failures": geometry_failures,
        "partial_qm_force_classification_excluded_only": "NONSTATIONARY",
        "coupled_gradient_metrics": {
            "mobile50": free,
            "fixed13778": fixed_force,
            "full13828": total_force,
        },
        "fixed_physical_count": len(fixed),
        "maximum_fixed_physical_displacement_angstrom": max(displacements, default=0.0),
        "total_coupled_energy_agreement": {
            "optimizer_hartree": str(last_opt_energy),
            "fresh_hartree": str(fresh_energy),
            "absolute_difference_hartree": str(energy_delta),
            "threshold_hartree": "0.000001",
        },
        "force_source": "full additive coupled physical gradient; no generated-cap row inserted",
        "gradient_conversion": {
            "ash_angstrom_per_bohr": str(ASH_BOHR_ANGSTROM),
            "native_legacy_angstrom_per_bohr": str(LEGACY_BOHR_ANGSTROM),
            "rule": "g_legacy=g_ASH*legacy_AngstromPerBohr/ASH_AngstromPerBohr",
        },
    }


def run_reference_repair(libs, session, quantum, job, observations_path, config):
    """Selected effectful entry; importing this module executes nothing."""
    if config.get("scientific_protocol_frozen") is not True:
        raise ValueError("unfrozen prospective reference repair cannot enter")
    geometry_verifier = _load_geometry(config["geometry_helper"])
    raw_initial = _exact_read(config["held_reference_v2"])
    initial = json.loads(raw_initial)
    intake = _intake(session, job, initial)
    (
        physical_ids,
        original,
        active,
        fixed,
        held_ids,
        held_elements,
        reorder,
        generated,
    ) = intake
    if (
        quantum.maximum_callbacks != MAXIMUM_TOTAL_CALLBACKS
        or quantum.callback_reservations != 0
        or quantum.last_observation is not None
    ):
        raise ValueError(
            "fresh selected one-hundred-and-one-callback reference supplier required"
        )
    if float(libs.ash.constants.bohr2ang) != float(ASH_BOHR_ANGSTROM):
        raise ValueError("selected ASH force units differ")
    output = Path(observations_path)
    if (
        not output.is_absolute()
        or output.exists()
        or output.is_symlink()
        or ".." in output.parts
    ):
        raise ValueError(
            "new explicitly selected absolute observation directory required"
        )
    output.parent.resolve(strict=True)
    output.mkdir(mode=0o700)
    optimization = output / "optimization"
    optimization.mkdir(mode=0o700)
    rows = []
    state = {"phase": "optimization", "last_optimization": None, "fresh": None}
    report = {
        "role": "EXPOSED_REFERENCE_V2_CONSTRAINED_GEOMETRY_REPAIR_NOT_KINETICS_OR_EL_ADVANTAGE",
        "status": "REFERENCE_REPAIR_REFUSED",
        "variant": "unedited-reference",
        "proton_view": "V2",
        "maximum_optimizer_iterations": 60,
        "maximum_optimizer_callbacks": 100,
        "maximum_total_callbacks": 101,
        "coordinate_system": "cart",
        "active_physical_indices": active,
        "fixed_physical_count": len(fixed),
        "physical_atom_ids": physical_ids,
        "held_quantum_atom_ids": held_ids,
        "ash_to_held_quantum_row_indices": reorder,
        "source_held_initial_sha256": sha256(raw_initial).hexdigest(),
        "geometry_helper": dict(config["geometry_helper"]),
        "convergence_criteria": dict(CONVERGENCE_CRITERIA),
        "evaluation_roster": rows,
        "fresh_full_coupled_gradient": "UNENTERED",
        "optimizer": "UNENTERED",
        "scientific_qualification": False,
        "final_species_certified": False,
        "unconstrained_minimum_certified": False,
        "free_energy_or_barrier_certified": False,
        "kinetics_or_el_advantage_certified": False,
    }
    original_run = session.theory.run

    def retained_run(self, *args, **kwargs):
        if args or kwargs.get("Grad") is not True:
            raise ValueError(
                "selected coupled optimizer requires keyword full-gradient calls"
            )
        coordinates = _rows(kwargs.get("current_coords"), PHYSICAL_ATOMS)
        ordinal = len(rows) + 1
        if ordinal > MAXIMUM_TOTAL_CALLBACKS:
            raise ValueError("complete coupled evaluation ceiling exhausted")
        row = {
            "ordinal": ordinal,
            "phase": state["phase"],
            "status": "ENTERED",
            "callback_reservations_before": quantum.callback_reservations,
        }
        rows.append(row)
        row["input_snapshot"] = _write_new(
            output / f"evaluation-{ordinal:03d}-input.json.gz",
            {
                "schema": "ordinary-coupled-physical-evaluation-input-v1",
                "ordinal": ordinal,
                "phase": state["phase"],
                "physical_atom_ids": physical_ids,
                "coordinates_angstrom": coordinates,
            },
            compressed=True,
        )
        try:
            if any(coordinates[i] != original[i] for i in fixed):
                raise ValueError(
                    "fixed physical coordinate changed before coupled callback"
                )
            energy, gradient = original_run(**kwargs)
            energy = _finite(energy)
            gradient = _rows(gradient, PHYSICAL_ATOMS)
            if quantum.callback_reservations != row["callback_reservations_before"] + 1:
                raise ValueError(
                    "one full coupled evaluation does not match one native callback"
                )
            callback = _callback_projection(quantum.last_observation)
            record = {
                "schema": "ordinary-coupled-physical-evaluation-result-v1",
                "ordinal": ordinal,
                "phase": state["phase"],
                "input_snapshot": row["input_snapshot"],
                "total_coupled_energy_hartree": energy,
                "full_physical_gradient_eh_ash_bohr": gradient,
                "native_qm_observation": callback,
            }
            row["result_snapshot"] = _write_new(
                output / f"evaluation-{ordinal:03d}-result.json.gz",
                record,
                compressed=True,
            )
            row["status"] = "RETURNED_FULL_PHYSICAL_GRADIENT"
            row["callback_reservations_after"] = quantum.callback_reservations
            combined = {
                "coordinates": coordinates,
                "energy": energy,
                "gradient": gradient,
                "callback": callback,
                "result_snapshot": row["result_snapshot"],
            }
            state[
                "last_optimization" if state["phase"] == "optimization" else "fresh"
            ] = combined
            return energy, libs.numpy.asarray(gradient)
        except (Exception, SystemExit) as exc:
            row.update(
                status="REFUSED",
                refusal={"type": type(exc).__name__, "message": str(exc)},
                callback_reservations_after=quantum.callback_reservations,
            )
            row["refusal_snapshot"] = _write_new(
                output / f"evaluation-{ordinal:03d}-refusal.json", row
            )
            raise

    session.theory.run = MethodType(retained_run, session.theory)
    quantum.maximum_callbacks = MAXIMUM_OPTIMIZER_CALLBACKS
    try:
        report["optimizer"] = "ENTERED"
        with _selected_cwd(optimization):
            result = libs.ash.Optimizer(
                theory=session.theory,
                fragment=session.fragment,
                charge=-6,
                mult=1,
                coordsystem="cart",
                force_coordsystem=True,
                ActiveRegion=True,
                actatoms=list(active),
                maxiter=60,
                conv_criteria=dict(CONVERGENCE_CRITERIA),
                NumGrad=False,
                TSOpt=False,
                hessian=None,
                printlevel=0,
                MM_PDB_traj_write=False,
                result_write_to_disk=False,
            )
        logfile = optimization / "geometric_OPTtraj.log"
        if (
            logfile.is_symlink()
            or not logfile.is_file()
            or logfile.stat().st_size > MAXIMUM_MEMBER_BYTES
        ):
            raise ValueError("complete bounded native optimizer convergence log absent")
        logbytes = logfile.read_bytes()
        logtext = logbytes.decode("utf8")
        report["optimizer_log"] = {
            "path": str(logfile),
            "bytes": len(logbytes),
            "sha256": sha256(logbytes).hexdigest(),
        }
        if "Converged! =D" not in logtext or re.search(
            r"Maximum iterations reached|Failed to converge", logtext, re.I
        ):
            raise ValueError("native coupled optimizer did not report convergence")
        last = state["last_optimization"]
        final = _rows(session.fragment.coords, PHYSICAL_ATOMS)
        if last is None or final != last["coordinates"]:
            raise ValueError(
                "final optimizer coordinates do not match its last full coupled evaluation"
            )
        if _exact_energy_difference(result.energy, last["energy"]) > Decimal(
            "0.000001"
        ):
            raise ValueError(
                "optimizer returned energy does not match retained last coupled energy"
            )
        if any(final[i] != original[i] for i in fixed):
            raise ValueError("optimizer changed a fixed source physical coordinate")
        final_caps = tuple(
            tuple(map(float, row))
            for row in session.theory.create_linkatoms(libs.numpy.asarray(final))
        )
        if final_caps != generated:
            raise ValueError(
                "optimizer changed a generated cap despite fixed endpoints"
            )
        report["optimizer"] = "CONVERGED_WITH_ALL_FIXED_PHYSICAL_COORDINATES_EXACT"
        report["last_optimization_snapshot"] = last["result_snapshot"]
        quantum.maximum_callbacks = MAXIMUM_TOTAL_CALLBACKS
        state["phase"] = "fresh-final-gradient"
        report["fresh_full_coupled_gradient"] = "ENTERED"
        with _selected_cwd(output):
            session.theory.run(
                current_coords=libs.numpy.asarray(final),
                elems=session.fragment.elems,
                Grad=True,
                charge=-6,
                mult=1,
                label="fresh-full-coupled-gradient",
            )
        fresh = state["fresh"]
        report["fresh_full_coupled_gradient"] = "RETURNED_FULL_PHYSICAL_GRADIENT"
        report["fresh_snapshot"] = fresh["result_snapshot"]
        diagnostics = _assemble_diagnostics(
            geometry_verifier,
            initial,
            held_ids,
            held_elements,
            reorder,
            fresh["callback"],
            last["callback"],
            fresh["energy"],
            last["energy"],
            fresh["gradient"],
            active,
            fixed,
            final,
            original,
            final_caps == generated,
        )
        report["diagnostics_binding"] = _write_new(
            output / "independent-geometry-and-coupled-force-diagnostics.json",
            diagnostics,
        )
        report["diagnostics"] = diagnostics
        report["status"] = diagnostics["status"]
    except (Exception, SystemExit) as exc:
        report["refusal"] = {"type": type(exc).__name__, "message": str(exc)}
        if report["optimizer"] == "ENTERED":
            report["optimizer"] = "REFUSED"
        if report["fresh_full_coupled_gradient"] == "ENTERED":
            report["fresh_full_coupled_gradient"] = "REFUSED"
    finally:
        quantum.maximum_callbacks = MAXIMUM_TOTAL_CALLBACKS
        session.theory.run = original_run
        report["coupled_evaluation_entries"] = len(rows)
        report["full_physical_evaluation_returns"] = sum(
            row["status"] == "RETURNED_FULL_PHYSICAL_GRADIENT" for row in rows
        )
        report["native_callback_reservations"] = quantum.callback_reservations
        report["unmeasured_after_refusal"] = (
            report["fresh_full_coupled_gradient"] == "UNENTERED"
        )
        report["ordinary_report_binding"] = _write_new(
            output / "reference-report.json", report
        )
    return report
