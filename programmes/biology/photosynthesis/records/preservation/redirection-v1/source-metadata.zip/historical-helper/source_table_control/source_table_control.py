"""Deferred, finite native table-LJ control; imports alone have no native effects."""
from __future__ import annotations

from decimal import Decimal, localcontext
from hashlib import sha256
import json
import math
from pathlib import Path
import time
from typing import Any, Callable, Mapping

NTYPES = 25
EXPRESSION = "(a/r6)^2-b/r6; r6=r^6;a=acoef(type1, type2);b=bcoef(type1, type2);"
DISTANCE_NM = Decimal("0.4")
FD_STEP_NM = Decimal("0.000001")
ANALYTIC_SCALED_TOLERANCE = Decimal("0.0000000001")
FD_SCALED_TOLERANCE = Decimal("0.00000001")
MAX_MEMBER_BYTES = 16 * 1024 * 1024
MAX_PARTICLES = 13828
MAX_EXCLUSIONS = 200000


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _number(value: Any) -> float:
    _require(not isinstance(value, bool), "boolean numerical operand")
    result = float(value)
    _require(math.isfinite(result), "nonfinite numerical operand")
    return result


def _decimal(value: Any) -> Decimal:
    _require(not isinstance(value, bool), "boolean numerical operand")
    result = Decimal(str(value))
    _require(result.is_finite(), "nonfinite numerical operand")
    return result


def _json_bytes(value: Any) -> bytes:
    raw = (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    _require(len(raw) <= MAX_MEMBER_BYTES, "ordinary member limit")
    return raw


def _write(path: Path, value: Any) -> dict[str, Any]:
    raw = _json_bytes(value)
    with path.open("xb") as stream:
        stream.write(raw)
    return {"path": str(path), "bytes": len(raw), "sha256": sha256(raw).hexdigest()}


def scaled_error(actual: Any, expected: Any) -> Decimal:
    a, b = _decimal(actual), _decimal(expected)
    return abs(a - b) / max(Decimal(1), abs(a), abs(b))


def source_pair_oracle(a_kcal_angstrom12: Any, b_kcal_angstrom6: Any,
                       distance_nm: Decimal) -> dict[str, Any]:
    """Independent source-coefficient formula, no native table/simulation code."""
    _require(isinstance(distance_nm, Decimal) and distance_nm.is_finite() and distance_nm > 0,
             "positive finite Decimal distance")
    a, b = _decimal(a_kcal_angstrom12), _decimal(b_kcal_angstrom6)
    _require(a > 0 and b > 0, "positive selected source A/B")
    with localcontext() as ctx:
        ctx.prec = 80
        aa = a * Decimal("4.184") * Decimal("0.1") ** 12
        bb = b * Decimal("4.184") * Decimal("0.1") ** 6
        r = distance_nm
        energy = aa / r ** 12 - bb / r ** 6
        derivative = -Decimal(12) * aa / r ** 13 + Decimal(6) * bb / r ** 7
        return {"energy_kj_per_mol": energy,
                "forces_kj_per_mol_nm": ((derivative, Decimal(0), Decimal(0)),
                                         (-derivative, Decimal(0), Decimal(0))),
                "distance_derivative_kj_per_mol_nm": derivative}


def selected_source_pair(source_witness: Mapping[str, Any]) -> dict[str, Any]:
    tables = source_witness["native_lj_tables"]
    pointers = source_witness["native_POINTERS"]
    n = source_witness["native_atom_count"]
    types = source_witness["retained_native_ATOM_TYPE_INDEX"]
    _require(type(n) is int and 2 <= n <= MAX_PARTICLES and len(types) == n,
             "complete occupied source type denominator")
    _require(source_witness["native_named_NTYPES"] == NTYPES and pointers[:2] == [n, NTYPES],
             "source NTYPES/POINTERS census")
    _require(all(type(v) is int and 1 <= v <= NTYPES for v in types), "source type indices")
    lookup, a, b = (tables[k] for k in ("NONBONDED_PARM_INDEX", "LENNARD_JONES_ACOEF", "LENNARD_JONES_BCOEF"))
    _require(len(lookup) == NTYPES ** 2 and len(a) == len(b) == NTYPES * (NTYPES + 1) // 2,
             "complete 25-type source A/B/lookup")
    _require(all(type(v) is int and 1 <= v <= len(a) for v in lookup), "source lookup indices")
    _require(all(_number(v) >= 0 for v in (*a, *b)), "negative/nonfinite source A/B")
    _require(all(lookup[NTYPES * i + j] == lookup[NTYPES * j + i]
                 for i in range(NTYPES) for j in range(NTYPES)), "asymmetric source lookup")
    occupied = sorted(set(types))
    for i, first in enumerate(occupied):
        for second in occupied[i + 1:]:
            index = lookup[NTYPES * (first - 1) + second - 1] - 1
            if a[index] > 0 and b[index] > 0:
                return {"source_types_1based": [first, second], "native_types_0based": [first - 1, second - 1],
                        "occupied_types_1based": occupied, "source_coefficient_index_1based": index + 1,
                        "source_A_kcal_angstrom12": a[index], "source_B_kcal_angstrom6": b[index],
                        "selection": "lexicographically first distinct occupied native types with positive source A/B"}
    raise ValueError("no distinct occupied positive source A/B pair")


def _live_custom_witness(force: Any) -> dict[str, Any]:
    n = force.getNumParticles()
    exclusions = force.getNumExclusions()
    _require(type(n) is int and 2 <= n <= MAX_PARTICLES and type(exclusions) is int
             and 0 <= exclusions <= MAX_EXCLUSIONS, "bounded actual custom force census")
    count = force.getNumTabulatedFunctions()
    _require(type(count) is int and 0 <= count <= 4, "bounded table function census")
    functions = []
    for i in range(count):
        fn = force.getTabulatedFunction(i)
        nx, ny, values = fn.getFunctionParameters()
        _require(type(nx) is int and type(ny) is int and len(values) <= NTYPES ** 2, "bounded actual table shape")
        functions.append({"name": force.getTabulatedFunctionName(i), "class": type(fn).__name__,
                          "nx": nx, "ny": ny, "values": [_number(v) for v in values]})
    return {"energy_expression": force.getEnergyFunction(), "particles": [list(force.getParticleParameters(i)) for i in range(n)],
            "tabulated_functions": functions, "exclusions": [list(force.getExclusionParticles(i)) for i in range(exclusions)],
            "per_particle_parameters": [force.getPerParticleParameterName(i) for i in range(force.getNumPerParticleParameters())],
            "global_parameter_count": force.getNumGlobalParameters(), "computed_value_count": force.getNumComputedValues(),
            "energy_parameter_derivative_count": force.getNumEnergyParameterDerivatives(),
            "interaction_group_count": force.getNumInteractionGroups(), "nonbonded_method": int(force.getNonbondedMethod()),
            "use_switching_function": bool(force.getUseSwitchingFunction()),
            "use_long_range_correction": bool(force.getUseLongRangeCorrection()),
            "uses_periodic_boundary_conditions": bool(force.usesPeriodicBoundaryConditions()), "force_group": int(force.getForceGroup())}


def _check_live_source(witness: Mapping[str, Any], source: Mapping[str, Any]) -> None:
    _require(witness["energy_expression"] == EXPRESSION, "unselected actual custom expression")
    _require(witness["per_particle_parameters"] == ["type"] and
             all(witness[k] == 0 for k in ("global_parameter_count", "computed_value_count", "energy_parameter_derivative_count",
                                           "interaction_group_count", "nonbonded_method", "force_group")) and
             not any(witness[k] for k in ("use_switching_function", "use_long_range_correction", "uses_periodic_boundary_conditions")),
             "unselected actual custom force properties")
    types = source["retained_native_ATOM_TYPE_INDEX"]
    _require(witness["particles"] == [[float(v - 1)] for v in types], "complete actual physical type roster")
    tables = source["native_lj_tables"]
    a, b, lookup = (tables[k] for k in ("LENNARD_JONES_ACOEF", "LENNARD_JONES_BCOEF", "NONBONDED_PARM_INDEX"))
    av, bv = [0.0] * (NTYPES ** 2), [0.0] * (NTYPES ** 2)
    for i in range(NTYPES):
        for j in range(NTYPES):
            index = lookup[NTYPES * i + j] - 1
            av[i + NTYPES * j] = math.sqrt(float(a[index])) * (math.sqrt(4.184) * 0.1 ** 6)
            bv[i + NTYPES * j] = float(b[index]) * (4.184 * 0.1 ** 6)
    expected = [{"name": "acoef", "class": "Discrete2DFunction", "nx": NTYPES, "ny": NTYPES, "values": av},
                {"name": "bcoef", "class": "Discrete2DFunction", "nx": NTYPES, "ny": NTYPES, "values": bv}]
    _require(witness["tabulated_functions"] == expected, "full actual native table differs from independent source conversion")


def run_source_table_control(libs: Any, session: Any, source_witness: Mapping[str, Any],
                             output_directory: Path, check_sources: Callable[[], Any]) -> dict[str, Any]:
    """Explicit effectful C4 entry. Ordinary report does not authorize later science."""
    out = Path(output_directory)
    _require(out.is_absolute() and not out.exists() and not out.is_symlink() and out.parent.is_dir(), "new explicitly selected control directory")
    out.mkdir()
    started = time.monotonic()
    counters = {"context_attempts": 0, "context_returns": 0, "energy_force_attempts": 0, "energy_force_returns": 0, "xtb_callbacks": 0}
    roster = [{"label": label, "distance_nm": str(r), "status": "UNENTERED"}
              for label, r in (("baseline", DISTANCE_NM), ("minus", DISTANCE_NM - FD_STEP_NM), ("plus", DISTANCE_NM + FD_STEP_NM))]
    report: dict[str, Any] = {"role": "NATIVE_TABLE_LJ_REPRESENTATION_CONFORMANCE_NOT_ENZYME_SCIENCE", "status": "REFUSED",
                             "native_counters": counters, "evaluation_roster": roster, "source_checks": [], "failure": None,
                             "criteria": {"analytic_scaled_error": str(ANALYTIC_SCALED_TOLERANCE), "fd_scaled_error": str(FD_SCALED_TOLERANCE),
                                          "scaled_error_definition": "abs(actual-expected)/max(1,abs(actual),abs(expected))", "fd_step_nm": str(FD_STEP_NM)},
                             "source_authority": "caller-authenticated retained native witness and verified live coupling; this helper grants none"}
    journal = out / "entry-return-journal.jsonl"
    with journal.open("xb"):
        pass

    def event(kind: str, **values: Any) -> None:
        with journal.open("ab") as stream:
            stream.write(_json_bytes({"event": kind, "elapsed_seconds": time.monotonic() - started, **values}))

    def guard(stage: str) -> None:
        event("SOURCE_GUARD_ENTRY", stage=stage)
        value = check_sources()
        if value is not None:
            _write(out / (stage + "-source-check.json"), value)
        report["source_checks"].append(stage)
        event("SOURCE_GUARD_RETURN", stage=stage)

    try:
        report["source_witness"] = _write(out / "retained-native-source-witness.json", source_witness)
        pair = selected_source_pair(source_witness)
        report["selected_pair"] = pair
        system = session.theory.mm_theory.system
        custom = [force for force in system.getForces() if type(force).__name__ == "CustomNonbondedForce"]
        _require(len(custom) == 1, "exactly one actual selected custom native force")
        witness = _live_custom_witness(custom[0])
        report["actual_live_force_witness"] = _write(out / "actual-live-custom-force.json", witness)
        _check_live_source(witness, source_witness)
        guard("before-control-context")
        mm, unit = libs.openmm, libs.unit
        tiny = mm.System()
        for _ in range(2):
            tiny.addParticle(12.0)
        cf = mm.CustomNonbondedForce(witness["energy_expression"])
        cf.addPerParticleParameter("type")
        for row in witness["tabulated_functions"]:
            cf.addTabulatedFunction(row["name"], mm.Discrete2DFunction(row["nx"], row["ny"], row["values"]))
        for t in pair["native_types_0based"]:
            cf.addParticle([float(t)])
        cf.setNonbondedMethod(mm.CustomNonbondedForce.NoCutoff)
        cf.setUseLongRangeCorrection(False)
        tiny.addForce(cf)
        ordinary = mm.NonbondedForce()
        ordinary.setNonbondedMethod(mm.NonbondedForce.NoCutoff)
        for _ in range(2):
            ordinary.addParticle(0.0, 1.0, 0.0)
        tiny.addForce(ordinary)
        control_setup = {"particles": 2, "mass_dalton": [12.0, 12.0], "charges_e": [0.0, 0.0], "platform": "Reference",
                         "ordinary_LJ_epsilons": [0.0, 0.0], "custom_expression": witness["energy_expression"],
                         "tables": witness["tabulated_functions"], "types_0based": pair["native_types_0based"],
                         "nonbonded_method": "NoCutoff", "periodic": False, "exclusions": [], "switching": False,
                         "long_range_correction": False, "integrator": "Verlet .001ps; no integration steps"}
        report["control_setup"] = _write(out / "selected-tiny-control-setup.json", control_setup)
        integrator = mm.VerletIntegrator(0.001 * unit.picoseconds)
        platform = mm.Platform.getPlatformByName("Reference")
        counters["context_attempts"] += 1
        event("CONTEXT_ENTRY", platform="Reference")
        context = mm.Context(tiny, integrator, platform)
        counters["context_returns"] += 1
        event("CONTEXT_RETURN", platform="Reference")
        guard("after-context-before-forces")
        all_errors = []
        for row in roster:
            r = Decimal(row["distance_nm"])
            coords = [[0.0, 0.0, 0.0], [float(r), 0.0, 0.0]]
            context.setPositions(unit.Quantity(coords, unit.nanometer))
            counters["energy_force_attempts"] += 1
            row["status"] = "ENTERED"
            event("ENERGY_FORCE_ENTRY", label=row["label"])
            state = context.getState(getEnergy=True, getForces=True)
            counters["energy_force_returns"] += 1
            event("ENERGY_FORCE_RETURN", label=row["label"])
            native_energy = state.getPotentialEnergy().value_in_unit(unit.kilojoule_per_mole)
            native_forces = state.getForces(asNumpy=False).value_in_unit(unit.kilojoule_per_mole / unit.nanometer)
            # String tokens preserve NaN/Inf and malformed vector dimensions
            # before JSON's finite-number and scientific shape admission.
            raw_tokens = {"role": "UNVERIFIED_RETURNED_NATIVE_OPERANDS_BEFORE_NUMERICAL_GUARDS",
                          "label": row["label"], "coordinates_nm": coords,
                          "energy_kj_per_mol_token": str(native_energy),
                          "forces_kj_per_mol_nm_tokens": [[str(v) for v in vector] for vector in native_forces]}
            report.setdefault("raw_native_token_members", []).append(
                _write(out / (row["label"] + "-unverified-native-return-tokens.json"), raw_tokens))
            energy = _number(native_energy)
            forces = [[_number(v) for v in vector] for vector in native_forces]
            _require(len(forces) == 2 and all(len(v) == 3 for v in forces), "complete two-particle forces")
            row.update(status="RETURNED", coordinates_nm=coords, energy_kj_per_mol=energy, forces_kj_per_mol_nm=forces)
            _write(out / (row["label"] + "-raw-native-energy-forces.json"), row)
            oracle = source_pair_oracle(pair["source_A_kcal_angstrom12"], pair["source_B_kcal_angstrom6"], r)
            energy_error = scaled_error(energy, oracle["energy_kj_per_mol"])
            force_errors = [scaled_error(actual, expected) for vector, expected_vector in zip(forces, oracle["forces_kj_per_mol_nm"], strict=True)
                            for actual, expected in zip(vector, expected_vector, strict=True)]
            row["energy_scaled_error"] = str(energy_error)
            row["maximum_force_scaled_error"] = str(max(force_errors))
            all_errors.extend([energy_error, *force_errors])
        baseline, minus, plus = roster
        with localcontext() as ctx:
            ctx.prec = 80
            fd = (Decimal(str(plus["energy_kj_per_mol"])) - Decimal(str(minus["energy_kj_per_mol"]))) / (2 * FD_STEP_NM)
        fd_error = scaled_error(fd, -baseline["forces_kj_per_mol_nm"][1][0])
        report["finite_difference"] = {"distance_derivative_kj_per_mol_nm": str(fd), "negative_native_particle1_x_force": str(-baseline["forces_kj_per_mol_nm"][1][0]), "scaled_error": str(fd_error)}
        report["maximum_analytic_scaled_error"] = str(max(all_errors))
        _require(max(all_errors) <= ANALYTIC_SCALED_TOLERANCE, "native table energy/force source-oracle disagreement")
        _require(fd_error <= FD_SCALED_TOLERANCE, "native table energy finite-difference disagreement")
        report["status"] = "PASS"
    except Exception as exc:
        report["failure"] = {"type": type(exc).__name__, "message": str(exc)}
        event("REFUSAL", **report["failure"])
    finally:
        try:
            guard("after-control-tail")
        except Exception as exc:
            report["status"] = "REFUSED"
            report["tail_source_refusal"] = {"type": type(exc).__name__, "message": str(exc)}
            event("TAIL_SOURCE_REFUSAL", **report["tail_source_refusal"])
        report["elapsed_seconds_before_report"] = time.monotonic() - started
        _write(out / "source-table-control-report.json", report)
    return report
