"""Prospective retained-reference caller; cold import, explicit frozen selection."""
from decimal import Decimal
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import re
import resource
import signal
import subprocess
import sys
import time
import io
import stat
import zipfile

MIB = 1024**2
BOUNDS = {"wall_seconds": 1200, "worker_cpu_seconds": 800,
    "parent_cpu_seconds": 30, "memory_bytes": 6*1024**3,
    "packet_bytes": 320*MIB, "closure_reserve_bytes": 32*MIB,
    "ordinary_member_bytes": 16*MIB, "objective_cap": 101,
    "per_native_cpu_seconds": 30, "per_native_wall_seconds": 60,
    "cumulative_output_bytes": 1024*MIB,
    "cumulative_worker_cpu_seconds": 1000, "cumulative_parent_cpu_seconds": 200,
    "cumulative_objective_cap": 144}
PRIOR_WORKER = Decimal("150.076026")
PRIOR_PARENT = Decimal("163.643974")
PRIOR_RESERVATIONS = 33
MONITOR_INTERVAL_SECONDS = 0.25
C4_SELECTION = {"id":"c4-source-table","status":"UNENTERED","maximum_native_contexts":1,
    "maximum_energy_force_evaluations":3,"maximum_quantum_callbacks":0}
RAW_SCHEMA = "empirical-lawhood/source/checksummed-uninterpreted-public-bytes"
WAITED_WORKER_CPU = 0.0
# Utility function bodies below are copied exactly from frozen preparation-v2.
def rawjson(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+"\n").encode()

def read(binding, maximum=16*MIB):
    path = Path(binding["path"])
    if (not path.is_absolute() or path.is_symlink() or not path.is_file()
            or path.stat().st_size > maximum):
        raise ValueError("bounded exact regular source required")
    raw = path.read_bytes()
    if len(raw) != binding["bytes"] or sha256(raw).hexdigest() != binding["sha256"]:
        raise ValueError("selected source identity differs: "+str(path))
    return raw

def binding(path):
    path = Path(path)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha256(raw).hexdigest()}

def load(row, name):
    raw = read(row, 128*1024)
    spec = importlib.util.spec_from_file_location(name, row["path"])
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(raw, row["path"], "exec"), module.__dict__)
    return module

def files(root):
    root = Path(root)
    if root.is_symlink():
        raise ValueError("symbolic selected root refused")
    found = []
    for path in root.rglob("*"):
        if path.is_symlink() or not (path.is_file() or path.is_dir()):
            raise ValueError("symbolic or nonregular output refused")
        if path.is_file():
            found.append(path)
    return tuple(sorted(found))

def directory_bytes(root):
    return sum(path.stat().st_size for path in files(root)) if Path(root).exists() else 0

def own_cpu():
    value = resource.getrusage(resource.RUSAGE_SELF)
    return value.ru_utime+value.ru_stime

def profile_descriptors(profile):
    """Distinct declarations may bind one physical source consistently."""
    rows = profile["files"]
    if len({row["path"] for row in rows}) != len(rows):
        raise ValueError("duplicate declared native source path")
    physical = {}
    for row in rows:
        location = row["resolved_path"]
        descriptor = (row["bytes"], row["sha256"])
        if location in physical and physical[location] != descriptor:
            raise ValueError("contradictory alias physical source descriptor")
        physical[location] = descriptor
    return {"files": len(rows), "bytes": sum(row["bytes"] for row in rows),
        "distinct_physical_files": len(physical),
        "distinct_physical_bytes": sum(row[0] for row in physical.values()),
        "consistent_alias_declarations": len(rows)-len(physical)}

def authenticate_profile(profile):
    census = profile_descriptors(profile)
    for row in profile["files"]:
        declared = Path(row["path"])
        path = declared.resolve(strict=True)
        if (str(path) != row["resolved_path"] or not path.is_file()
                or path.stat().st_size != row["bytes"]
                or declared.is_symlink() is not row["symlink"]):
            raise ValueError("native profile location, symlink or count differs")
        digest = sha256()
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(MIB), b""):
                digest.update(chunk)
        if digest.hexdigest() != row["sha256"]:
            raise ValueError("native profile source differs: "+str(path))
    return census

def authenticate_closed(row):
    """Authentic retained manifests, no producer/scientific decoding."""
    from empirical_lawhood.infrastructure.artifacts import ExternalArtifactPlane, GuardedExternalRoot, LocalFilesystemInspector
    from empirical_lawhood.infrastructure.task_receipts import decode_artifact_manifest
    from empirical_lawhood.runtime.artifacts import ExternalRootContract
    raw = read(row["census"])
    value = json.loads(raw)
    root = Path(row["census"]["path"]).parent
    roster = {entry["name"]: entry for entry in value["members_excluding_self"]}
    physical = files(root)
    if len(roster) != len(value["members_excluding_self"]) or {p.relative_to(root).as_posix() for p in physical} != set(roster)|{"closed-census.json"}:
        raise ValueError("complete retained ancestor denominator differs")
    for name, entry in roster.items():
        source = {"path": str(root/name), "bytes": entry["bytes"], "sha256": entry["sha256"]}
        read(source, 32*MIB if name == "native-work/original-prepared.prmtop" else 16*MIB)
    if any(path.stat().st_mode & 0o777 != 0o444 for path in physical):
        raise ValueError("ancestor read-only member differs")
    if any(path.stat().st_mode & 0o777 != 0o555 for path in (root, *[p for p in root.rglob("*") if p.is_dir()])):
        raise ValueError("ancestor read-only directory differs")
    stored = json.loads((root/"storage-contract.json").read_bytes())["value"]
    stored["allowed_filesystem_types"] = tuple(stored["allowed_filesystem_types"])
    plane = ExternalArtifactPlane(GuardedExternalRoot(ExternalRootContract(**stored), inspector=LocalFilesystemInspector()))
    manifests = tuple(root.rglob("*.manifest.json"))
    if len(manifests) != row["publications"] or len(physical) != row["physical_files"]:
        raise ValueError("selected ancestor census count differs")
    for path in manifests:
        plane.verify_manifest(decode_artifact_manifest(path.read_bytes()))
    return {"census": row["census"], "physical_files": len(physical),
            "physical_bytes": sum(p.stat().st_size for p in physical),
            "genuine_publications": len(manifests)}

def joined_bytes(join, root):
    rows = join["ordered_chunks"]
    if not 1 <= len(rows) <= 8:
        raise ValueError("bounded complete chunk roster required")
    pieces = []
    for i, row in enumerate(rows):
        name = row.get("name", row.get("relative"))
        if type(name) is not str or Path(name).is_absolute() or ".." in Path(name).parts:
            raise ValueError("safe exact source chunk locator required")
        pieces.append(read({"path": str(Path(root)/name), "bytes": row["bytes"],
            "sha256": row["sha256"]}, 8*MIB))
        if not name.endswith(f"part-{i:04d}"):
            raise ValueError("ordered complete source chunks required")
    result = b"".join(pieces)
    if len(result) > 64*MIB or len(result) != join["whole_bytes"] or sha256(result).hexdigest() != join["whole_sha256"]:
        raise ValueError("complete source chunk join differs")
    return result


def validate_scope(config, *, entered_worker_packet=False):
    if config.get("scientific_protocol_frozen") is not True:
        raise ValueError("draft cannot enter retained reference physics")
    if config.get("bounds") != BOUNDS or any(type(v) is not int for v in config["bounds"].values()):
        raise ValueError("selected exact finite allocation differs")
    if type(config.get("monitor_interval_seconds")) is not float or config["monitor_interval_seconds"]!=MONITOR_INTERVAL_SECONDS:
        raise ValueError("selected exact monitor interval differs")
    if config.get("assigned_references") != 1 or type(config["assigned_references"]) is not int:
        raise ValueError("one retained reference is selected")
    if config.get("selected_source_table_control") != C4_SELECTION or any(
            type(config["selected_source_table_control"][k]) is not int for k in
            ("maximum_native_contexts","maximum_energy_force_evaluations","maximum_quantum_callbacks")):
        raise ValueError("one bounded source-table control must precede enzyme objectives")
    native_bytes=config.get("native_case_output_bytes")
    if type(native_bytes) is not int or not 256*1024<=native_bytes<=BOUNDS["packet_bytes"]-BOUNDS["closure_reserve_bytes"]:
        raise ValueError("selected positive native output allocation must stay within working packet")
    prior = config["old_cost_and_exposure"]
    if (Decimal(prior["complete_worker_cpu_seconds"]) != PRIOR_WORKER
            or Decimal(prior["complete_parent_cpu_seconds"]) != PRIOR_PARENT
            or prior["callback_reservations"] != PRIOR_RESERVATIONS
            or type(prior["callback_reservations"]) is not int
            or prior.get("old_windows_closed") is not True):
        raise ValueError("closed cost/exposure ancestry differs")
    if (PRIOR_WORKER+BOUNDS["worker_cpu_seconds"] > BOUNDS["cumulative_worker_cpu_seconds"]
            or PRIOR_PARENT+BOUNDS["parent_cpu_seconds"] > BOUNDS["cumulative_parent_cpu_seconds"]
            or PRIOR_RESERVATIONS+BOUNDS["objective_cap"] > BOUNDS["cumulative_objective_cap"]):
        raise ValueError("new allocation exceeds cumulative bound")
    if not re.fullmatch(r"[a-z][a-z0-9-]{0,95}", config.get("packet_name", "")):
        raise ValueError("closed lowercase operation identity required")
    root = Path(config["artifact_root"])
    if not root.is_absolute() or root.is_symlink() or not root.is_dir():
        raise ValueError("explicit existing artifact root required")
    out = root/config["packet_name"]
    if type(entered_worker_packet) is not bool:
        raise ValueError("explicit caller/worker selection mode required")
    if out.is_symlink() or (not entered_worker_packet and out.exists()):
        raise ValueError("unused selected packet; no overwrite or retry")
    if entered_worker_packet and not out.is_dir():
        raise ValueError("worker must use actual entered parent packet")
    selected = config["selected_sources"]
    if len({r["path"] for r in selected}) != len(selected):
        raise ValueError("duplicate producing source path")
    for key in ("launcher", "worker", "native_coupling", "source_guard",
                "custody_reference", "custody_bridge", "bounded_executor", "reference_assessment", "qm_owner", "source_table_control"):
        if config[key] not in selected:
            raise ValueError("selected executable helper absent from producing inventory: "+key)
    if config["derived_prmtop"]["bytes"] != 5967591 or config["derived_prmtop"]["sha256"] != "adc479e815481d4174024c28eb1f27ce85ea67bd5af0a646a34bb92982280fcd":
        raise ValueError("authentic prepared topology differs")
    return out


def read_structured_produced(path):
    """Read an exact bounded produced record or its complete ordered join."""
    path=Path(path);join_path=Path(str(path)+".join.json")
    if path.exists() and join_path.exists():
        raise ValueError("ambiguous structured output locators")
    if path.exists():
        return json.loads(read(binding(path),8*MIB))
    if join_path.exists():
        join=json.loads(read(binding(join_path),8*MIB))
        if (join.get("encoding")!="compact-json-ordered-chunks" or join.get("whole_bytes",0)>32*MIB
                or not 1<=len(join.get("ordered_chunks",()))<=4):
            raise ValueError("complete bounded structured output join required")
        expected=[path.name+f".part-{i:04d}" for i in range(len(join["ordered_chunks"]))]
        if [row.get("name") for row in join["ordered_chunks"]]!=expected:
            raise ValueError("structured output exact ordered locator census differs")
        return json.loads(joined_bytes(join,path.parent))
    return None


def verify_python_cache(config):
    path=Path(config["python_cache_prefix"])
    if (not path.is_absolute() or path.is_symlink() or not path.is_dir()
            or path.resolve(strict=True)!=path or any(path.iterdir())
            or stat.S_IMODE(path.stat().st_mode)!=0o555
            or sys.pycache_prefix!=str(path) or sys.dont_write_bytecode is not True
            or os.environ.get("PYTHONPYCACHEPREFIX")!=str(path)
            or os.environ.get("PYTHONDONTWRITEBYTECODE")!="1"):
        raise ValueError("actual empty readonly Python cache-prefix source guard differs")
    return {"path":str(path),"mode":"0555","entries":0,"actual_sys_pycache_prefix":sys.pycache_prefix,"dont_write_bytecode":True}


def selected_directories(config):
    roots = tuple(Path(p) for p in config["cumulative_directories"])
    if not roots or len(roots) != len(set(roots)):
        raise ValueError("complete distinct cumulative directory roster required")
    for root in roots:
        if not root.is_absolute() or root.is_symlink() or ".." in root.parts or root.resolve(strict=False) != root:
            raise ValueError("explicit canonical selected directory required")
    if any(a != b and a.is_relative_to(b) for a in roots for b in roots):
        raise ValueError("overlapping cumulative roots double-count physical outputs")
    required = {Path(config["artifact_root"])/config["packet_name"], Path(config["helper_root"]),
                Path(config["native_coupling"]["path"]).parent}
    required |= {Path(row["census"]["path"]).parent for row in config["closed_ancestors"]}
    if not required <= set(roots):
        raise ValueError("new/ancestral packet and helper outputs absent from cumulative census")
    return roots


def cumulative_inventory(roots):
    rows, total = [], 0
    for root in roots:
        members = []
        if root.exists():
            for path in files(root):
                size = path.stat().st_size
                total += size
                members.append({"name": path.relative_to(root).as_posix(), "bytes": size})
        rows.append({"root": str(root), "files": len(members),
                     "bytes": sum(r["bytes"] for r in members)})
    return total, rows


def monitor_inventory(base_bytes,mutable_roots):
    return base_bytes+sum(directory_bytes(root) for root in mutable_roots)


def validate_immutable_roots(roots,mutable_roots):
    for root in roots:
        if root in mutable_roots:
            continue
        if not root.is_dir() or root.is_symlink():
            raise ValueError("complete selected immutable root must exist")
        dirs=(root,*[p for p in root.rglob("*") if p.is_dir()])
        if (any(stat.S_IMODE(p.stat().st_mode)!=0o555 for p in dirs)
                or any(stat.S_IMODE(p.stat().st_mode)!=0o444 for p in files(root))):
            raise ValueError("cached immutable cumulative roots must be readonly")


def published_raw_coverage(work,out,publications):
    """Reuse only exact file bytes already in genuine callback publications."""
    coverage={}
    published={row["relative"]:row for row in publications}
    def authentic_row(path,payload):
        relative=path.relative_to(out).as_posix()
        row=published.get(relative)
        if (row is None or row["payload_bytes"]!=len(payload)
                or row["payload_sha256"]!=sha256(payload).hexdigest()
                or row["manifest_sha256"]!=sha256(Path(str(path)+".manifest.json").read_bytes()).hexdigest()):
            raise ValueError("existing raw coverage lacks actual verified publication join")
        return row
    raw_root=out/"callback-custody/reference-v2"
    if not raw_root.exists():return coverage
    for path in sorted(raw_root.glob("*.raw.zip")):
        payload=path.read_bytes()
        publication=authentic_row(path,payload)
        if len(payload)>8*MIB:raise ValueError("bounded published native raw capture required")
        with zipfile.ZipFile(io.BytesIO(payload)) as z:
            infos=z.infolist()
            if len(infos)>64 or sum(i.file_size for i in infos)>32*MIB or z.testzip() is not None:
                raise ValueError("published native capture census/CRC differs")
            meta=json.loads(z.read("capture.json"));locator=Path(meta["output_locator"])
            if locator.parent!=work/"cases/reference-v2/calls" or locator.name!=meta["execution_id"]:
                raise ValueError("published capture locator leaves selected native root")
            for row in meta["files"]:
                name=Path(row["name"])
                if name.is_absolute() or ".." in name.parts:raise ValueError("unsafe raw capture member")
                source=locator/name;member="files/"+name.as_posix();raw=z.read(member)
                if len(raw)!=row["bytes"] or sha256(raw).hexdigest()!=row["sha256"] or source.read_bytes()!=raw:
                    raise ValueError("published raw member no longer matches physical source")
                coverage[str(source)]={"kind":"existing-genuine-callback-raw-ZIP-member","publication":publication,"zip_member":member}
            bridge_source=work/"cases/reference-v2/bridge"/(meta["execution_id"]+".capture.zip")
            if bridge_source.is_file() and bridge_source.read_bytes()==payload:
                coverage[str(bridge_source)]={"kind":"byte-identical-existing-genuine-publication","publication":publication}
    for path in sorted(raw_root.glob("*.plan.zip")):
        payload=path.read_bytes()
        publication=authentic_row(path,payload)
        with zipfile.ZipFile(io.BytesIO(payload)) as z:meta=json.loads(z.read("plan.json"))
        source=work/"cases/reference-v2/bridge"/(meta["execution_id"]+".plan.zip")
        if source.is_file() and source.read_bytes()==payload:
            coverage[str(source)]={"kind":"byte-identical-existing-genuine-publication","publication":publication}
    return coverage


def complete_refusal(worker_cpu, now, deadline, parent_cpu, packet_bytes, cumulative_bytes):
    return ("COMPLETE_WORKER_CPU_CAP" if worker_cpu > BOUNDS["worker_cpu_seconds"] else
        "WHOLE_WALL_CAP" if now >= deadline else
        "COMPLETE_PARENT_CPU_CAP" if parent_cpu > BOUNDS["parent_cpu_seconds"] else
        "COMPLETE_PACKET_BYTE_CAP" if packet_bytes > BOUNDS["packet_bytes"] else
        "COMPLETE_CUMULATIVE_BYTE_CAP" if cumulative_bytes > BOUNDS["cumulative_output_bytes"] else None)


def waited_children_cpu():
    usage=resource.getrusage(resource.RUSAGE_CHILDREN)
    return usage.ru_utime+usage.ru_stime


def complete_parent_cpu():
    return own_cpu()+waited_children_cpu()-WAITED_WORKER_CPU


def reconcile_worker_cpu(total_wait_delta, parent_metadata_delta):
    if parent_metadata_delta<0 or total_wait_delta<parent_metadata_delta-1e-9:
        raise ValueError("waited worker/parent-metadata CPU reconciliation differs")
    return max(0.0,total_wait_delta-parent_metadata_delta)


def publication_request(plane, root, name, prefix, key, relative, raw, media="text/plain", canonical=False):
    from empirical_lawhood.kernel.evidence import OutcomeAccess, VisibilityCeiling
    from empirical_lawhood.runtime.artifacts import ArtifactProfile, ArtifactWriteRequest, ExternalRootContract
    if len(raw) > 16*MIB or Path(relative).is_absolute() or ".." in Path(relative).parts:
        raise ValueError("bounded safe publication member required")
    value = ArtifactWriteRequest(prefix+"."+key, name+"/"+relative,
        ExternalRootContract.SCHEMA if canonical else RAW_SCHEMA,
        ArtifactProfile.CANONICAL_JSON if canonical else ArtifactProfile.RAW_SOURCE_BYTES,
        "application/json" if canonical else media, prefix, name, raw,
        VisibilityCeiling.DEVELOPMENT_ONLY, (), OutcomeAccess.DEVELOPMENT_VISIBLE,
        minimum_free_bytes=BOUNDS["packet_bytes"])
    actual = plane.root.verify(for_write=True, operation_minimum_free_bytes=BOUNDS["packet_bytes"])
    (actual/value.relative_path).resolve(strict=False).relative_to((actual/name).resolve(strict=False))
    if actual != Path(root) or not plane._preflight_publication((value,)).contains(value.relative_path):
        raise ValueError("publication scope differs")
    plane.validators.validate(value)
    return value


def drain_bridges(work, bridge, publish):
    family = work/"cases"
    if not family.exists():
        return
    for case in sorted(family.iterdir()):
        if case.is_symlink() or not case.is_dir() or case.name != "reference-v2":
            raise ValueError("unselected case locator")
        br, locator = case/"bridge", case/"calls"
        if not br.exists():
            continue
        def publish_plan(key, raw):
            return publish("plan.reference-v2."+key, "callback-custody/reference-v2/"+key+".plan.zip", raw, "application/zip")["manifest_sha256"]
        def publish_raw(key, raw):
            return publish("raw.reference-v2."+key, "callback-custody/reference-v2/"+key+".raw.zip", raw, "application/zip")["manifest_sha256"]
        bridge.publish_pending(br, publish_plan, locator_root=locator)
        bridge.publish_pending_captures(br, publish_raw, locator_root=locator)


def wait_worker(argv, env, work, out, deadline, roots, custody, bridge, publish, base_bytes,mutable_roots):
    global WAITED_WORKER_CPU
    before = waited_children_cpu()
    process, reason, error = None, None, None
    peak_cpu = peak_rss = 0
    metadata_cpu=postwait_metadata_cpu=0.0
    killed=False
    def drain_with_cost():
        nonlocal metadata_cpu
        before_drain=waited_children_cpu()
        try:
            drain_bridges(work,bridge,publish)
        finally:
            # No worker poll/wait occurs inside the bridge. Any child reaped
            # by publication here is a parent metadata inspector, not worker.
            metadata_cpu+=waited_children_cpu()-before_drain
    def limits():
        resource.setrlimit(resource.RLIMIT_CPU, (BOUNDS["worker_cpu_seconds"],)*2)
        resource.setrlimit(resource.RLIMIT_AS, (BOUNDS["memory_bytes"],)*2)
        resource.setrlimit(resource.RLIMIT_FSIZE, (16*MIB,)*2)
        resource.setrlimit(resource.RLIMIT_CORE, (0,0))
    with (out/"worker-stdout.txt").open("xb") as stdout, (out/"worker-stderr.txt").open("xb") as stderr:
        try:
            process = subprocess.Popen(argv, cwd=work, env=env, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, preexec_fn=limits, start_new_session=True)
            while process.poll() is None:
                cpu, rss = custody.total_proc_cpu(process.pid)
                peak_cpu, peak_rss = max(peak_cpu,cpu), max(peak_rss,rss)
                aggregate = monitor_inventory(base_bytes,mutable_roots)
                reason = ("WORKER_CPU_CAP" if cpu >= BOUNDS["worker_cpu_seconds"]-0.5 else
                    "WHOLE_WALL_CAP" if time.monotonic() >= deadline else
                    "PARENT_CPU_CAP" if complete_parent_cpu() >= BOUNDS["parent_cpu_seconds"]-0.5 else
                    "PACKET_CLOSURE_RESERVE" if directory_bytes(out) >= BOUNDS["packet_bytes"]-BOUNDS["closure_reserve_bytes"] else
                    "CUMULATIVE_CLOSURE_RESERVE" if aggregate >= BOUNDS["cumulative_output_bytes"]-BOUNDS["closure_reserve_bytes"] else
                    "WORKER_MEMORY_CAP" if rss > BOUNDS["memory_bytes"] else None)
                if reason:
                    break
                drain_with_cost()
                time.sleep(MONITOR_INTERVAL_SECONDS)
        except BaseException as exc:
            reason = reason or "WORKER_OR_MONITOR_REFUSAL"
            error = {"type":type(exc).__name__,"message":str(exc)}
        finally:
            if process is not None and process.poll() is None:
                try:
                    os.killpg(process.pid,signal.SIGKILL)
                    killed=True
                except ProcessLookupError:
                    pass
            code = process.wait() if process is not None else None
    cpu=reconcile_worker_cpu(waited_children_cpu()-before,metadata_cpu)
    WAITED_WORKER_CPU=cpu
    aggregate, _ = cumulative_inventory(roots)
    reason = reason or complete_refusal(cpu,time.monotonic(),deadline,complete_parent_cpu(),directory_bytes(out),aggregate)
    before_postwait=waited_children_cpu()
    try:
        drain_bridges(work,bridge,publish)
    except BaseException as exc:
        reason = reason or "POSTWAIT_PENDING_CUSTODY_REFUSAL"
        error = error or {"type":type(exc).__name__,"message":str(exc)}
    finally:
        postwait_metadata_cpu=waited_children_cpu()-before_postwait
    aggregate=monitor_inventory(base_bytes,mutable_roots)
    reason=reason or complete_refusal(cpu,time.monotonic(),deadline,complete_parent_cpu(),directory_bytes(out),aggregate)
    return {"exit_code":code,"operational_refusal":reason,"error":error,
        "complete_waited_worker_cpu_seconds":cpu,"observed_peak_tree_cpu_seconds":peak_cpu,
        "observed_waited_worker_cpu_seconds":cpu,
        "complete_descendant_cpu_accounting":not killed and code==0,
        "unwaited_descendant_cpu_status":"NOT_OBSERVED_NORMAL_WORKER_EXIT" if not killed and code==0 else "UNKNOWN_AFTER_ABNORMAL_WORKER_TERMINATION",
        "observed_peak_tree_rss_bytes":peak_rss,
        "parent_metadata_waited_child_cpu_during_worker_seconds":metadata_cpu,
        "parent_metadata_waited_child_cpu_postwait_drain_seconds":postwait_metadata_cpu,
        "forced_worker_group_kill":killed,
        "complete_parent_cpu_seconds_after_final_drain":complete_parent_cpu(),
        "conservative_worker_cpu_charge_seconds":max(800,cpu) if killed or code != 0 else cpu,
        "monitor_interval_seconds":MONITOR_INTERVAL_SECONDS,
        "cost_scope":"normally waited worker/all waited descendants incl startup/report tail, with separately observed parent metadata child CPU removed; abnormal group kill conservatively charges at least full800; outer wait supplies complete parent/closure tail"}


def _run_selected(started,journal):
    journal["stage"]="CONFIGURATION_VALIDATION"
    if len(sys.argv)!=3:
        raise ValueError("explicit frozen CONFIG CONFIG_SHA256 required")
    config_path=Path(sys.argv[1]);config_raw=config_path.read_bytes()
    if len(config_raw)>4*MIB or sha256(config_raw).hexdigest()!=sys.argv[2]:
        raise ValueError("selected configuration differs")
    config=json.loads(config_raw);out=validate_scope(config);roots=selected_directories(config)
    verify_python_cache(config)
    deadline=started+BOUNDS["wall_seconds"]
    inherited=resource.getrlimit(resource.RLIMIT_CPU)[1]
    if inherited!=resource.RLIM_INFINITY and inherited<BOUNDS["worker_cpu_seconds"]:
        raise ValueError("inherited hard CPU cannot select worker800")
    resource.setrlimit(resource.RLIMIT_CPU,(BOUNDS["parent_cpu_seconds"],BOUNDS["worker_cpu_seconds"]))
    resource.setrlimit(resource.RLIMIT_AS,(BOUNDS["memory_bytes"],)*2)
    resource.setrlimit(resource.RLIMIT_FSIZE,(16*MIB,)*2)
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    for row in config["selected_sources"]:read(row)
    protocol_raw=read(config["protocol"],128*1024);profile_raw=read(config["profile"],8*MIB)
    journal["stage"]="FULL_PROFILE_AUTHENTICATION"
    profile_census=authenticate_profile(json.loads(profile_raw))
    custody=load(config["custody_reference"],"_retained_reference_custody")
    bridge=load(config["custody_bridge"],"_retained_reference_bridge")
    journal["stage"]="ANCESTOR_AUTHENTICATION"
    ancestry={row["label"]:authenticate_closed(row) for row in config["closed_ancestors"]}
    if len(ancestry)!=len(config["closed_ancestors"]) or not {"v5","v8","preparation-v2","retained-reference-v1","retained-reference-v2"}<=set(ancestry):
        raise ValueError("complete unique direct ancestry required")
    prep_root=Path(next(row["census"]["path"] for row in config["closed_ancestors"] if row["label"]=="preparation-v2")).parent
    old8=Path(next(row["census"]["path"] for row in config["closed_ancestors"] if row["label"]=="v8")).parent
    old5=Path(next(row["census"]["path"] for row in config["closed_ancestors"] if row["label"]=="v5")).parent
    if Path(config["derived_prmtop"]["path"])!=prep_root/"preparation-work/probe/preparation-scratch/reference-v2-derived.prmtop":
        raise ValueError("prepared topology must use authentic closed locator")
    prep_census=next(row["census"] for row in config["closed_ancestors"] if row["label"]=="preparation-v2")
    if config["retained_preparation_census"]!=prep_census:
        raise ValueError("retained preparation must bind authenticated closed census")
    for key,relative in (("retained_preparation_report","preparation-work/probe/probe-report.json"),
                         ("retained_reload_witness","preparation-work/probe/witnesses/derived-reloaded-native-witness.json")):
        if Path(config[key]["path"])!=prep_root/relative:
            raise ValueError("retained preparation witness differs from actual closed native locator")
    if Path(config["reference_plan_join"]["path"])!=old8/"native-work/reference-topology-plan.json.join.json":
        raise ValueError("held plan must use authentic closed v8 chunks")
    prep_report_raw=read(config["retained_preparation_report"])
    prep_report=json.loads(prep_report_raw)
    if (prep_report.get("status")!="PREPARATION_CONFORMANT" or prep_report.get("native_preparation_attempts")!=1
            or prep_report.get("native_preparations_returned")!=1):
        raise ValueError("retained actual preparation conformance missing")
    join_raw=read(config["reference_plan_join"])
    joined_bytes(json.loads(join_raw),old8/"native-work")
    derived_raw=read(config["derived_prmtop"]);reload_raw=read(config["retained_reload_witness"])
    completed_raw=read(config["retained_completed_summary"]);completed=json.loads(completed_raw)
    controls_raw=read(config["retained_completed_controls"])
    if (Path(config["retained_completed_summary"]["path"])!=old5/"measured-summary.json"
            or Path(config["retained_completed_controls"]["path"])!=old5/"native-work/native-controls/control-report.json"
            or completed["worker_report"]["capacity"]["status"]!="PASS"
            or json.loads(controls_raw)["status"]!="PASS"):
        raise ValueError("receipt-bound completed controls/capacity missing")
    aggregate,initial_inventory=cumulative_inventory(roots)
    if aggregate>=BOUNDS["cumulative_output_bytes"]-BOUNDS["packet_bytes"]:
        raise ValueError("complete selected output scope lacks new320MiB allowance")
    mutable_roots=(out,Path(config["helper_root"]))
    validate_immutable_roots(roots,mutable_roots)
    base_bytes=aggregate-sum(directory_bytes(p) for p in mutable_roots if p.exists())
    archive,archive_index=custody.zip_payload({f"source-{i:05d}/"+Path(row["path"]).name:read(row) for i,row in enumerate(config["selected_sources"])})
    from empirical_lawhood.infrastructure.artifacts import ExternalArtifactPlane,GuardedExternalRoot,LocalFilesystemInspector
    from empirical_lawhood.infrastructure.task_receipts import decode_artifact_manifest
    from empirical_lawhood.runtime.artifacts import ExternalRootContract
    root=Path(config["artifact_root"]);name=config["packet_name"];prefix="rubisco."+name
    contract=ExternalRootContract(prefix,"One retained referenceV2 coupled model and constrained repair; no kinetics",str(root),"/","empirical-lawhood/rubisco/local-exposed-mount",BOUNDS["packet_bytes"])
    plane=ExternalArtifactPlane(GuardedExternalRoot(contract,inspector=LocalFilesystemInspector()))
    publications=[]
    def request(key,relative,raw,media="text/plain",canonical=False):
        return publication_request(plane,root,name,prefix,key,relative,raw,media,canonical)
    def publish(key,relative,raw,media="text/plain",canonical=False,closure=False):
        aggregate=monitor_inventory(base_bytes,mutable_roots)
        reserve=0 if closure else BOUNDS["closure_reserve_bytes"]
        if (directory_bytes(out)+len(raw)+65536>BOUNDS["packet_bytes"]-reserve
                or aggregate+len(raw)+65536>BOUNDS["cumulative_output_bytes"]-reserve):
            raise ValueError("complete selected publication allocation exhausted")
        receipt=plane.write(request(key,relative,raw,media,canonical))
        if not receipt.created:raise ValueError("unexpected publication reuse")
        manifest= root/receipt.manifest_materialization.relative_path
        manifest_raw=manifest.read_bytes()
        if sha256(manifest_raw).hexdigest()!=receipt.manifest_materialization.physical_sha256:
            raise ValueError("actual manifest byte identity differs")
        plane.verify_manifest(decode_artifact_manifest(manifest_raw))
        row={"key":key,"relative":relative,"payload_bytes":len(raw),"payload_sha256":sha256(raw).hexdigest(),"manifest_sha256":sha256(manifest_raw).hexdigest()}
        publications.append(row);return row
    def publish_blob(key,relative,raw,media="text/plain",closure=False):
        if len(raw)<=8*MIB:return publish(key,relative,raw,media,closure=closure)
        chunks=[]
        for i,offset in enumerate(range(0,len(raw),8*MIB)):
            piece=raw[offset:offset+8*MIB];target=relative+f".part-{i:04d}"
            actual=publish(key+f"-part-{i:04d}",target,piece,media,closure=closure)
            chunks.append({"relative":target,"bytes":len(piece),"sha256":sha256(piece).hexdigest(),"publication":actual})
        return publish(key+"-join",relative+".join.json",rawjson({"whole_bytes":len(raw),"whole_sha256":sha256(raw).hexdigest(),"ordered_chunks":chunks}),closure=closure)
    initial=[("storage","storage-contract.json",contract.canonical_bytes(),"application/json",True),
        ("protocol","sources/frozen-protocol.md",protocol_raw,"text/plain",False),
        ("config","sources/frozen-config.json",config_raw,"text/plain",False),
        ("profile","sources/frozen-native-profile.json",profile_raw,"text/plain",False),
        ("producing-index","sources/producing-source-index.json",rawjson({"selected_sources":config["selected_sources"],"archive_members":archive_index}),"text/plain",False),
        ("reuse-ancestry","sources/retained-source-and-cost-ancestry.json",rawjson({"ancestors":ancestry,"profile_census":profile_census,"initial_cumulative_inventory":initial_inventory,"initial_cumulative_bytes":aggregate,"old_cost_and_exposure":config["old_cost_and_exposure"],"repeated_old_controls":0,"new_source_table_control":C4_SELECTION,"new_native_preparations":0}),"text/plain",False),
        ("preparation-report","retained-preparation/report.json",prep_report_raw,"text/plain",False),
        ("reloaded-witness","retained-preparation/derived-reloaded-witness.json",reload_raw,"text/plain",False),
        ("derived-topology","retained-preparation/derived.prmtop",derived_raw,"text/plain",False),
        ("controls","retained-controls/controls.json",controls_raw,"text/plain",False),
        ("controls-summary","retained-controls/summary.json",completed_raw,"text/plain",False)]
    journal["stage"]="PUBLICATION_PREFLIGHT"
    for row in initial:request(*row)
    request("code-preflight","sources/producing-code.zip",archive[:min(len(archive),8*MIB)],"application/zip")
    request("barrier","prefit-barrier.json",rawjson({"preflight_only":True}))
    request("summary","measured-summary.json",rawjson({"preflight_only":True}))
    out.mkdir();work=out/"reference-work";work.mkdir()
    journal["stage"]="CUSTODY_PUBLICATION"
    for row in initial:publish(*row)
    publish_blob("code","sources/producing-code.zip",archive,"application/zip")
    publish("plan-join","retained-plan/original-join.json",join_raw)
    for i,row in enumerate(json.loads(join_raw)["ordered_chunks"]):
        publish("plan-part-"+str(i),f"retained-plan/plan.part-{i:04d}",read({"path":str(old8/"native-work"/row["name"]),"bytes":row["bytes"],"sha256":row["sha256"]},8*MIB))
    barrier=publish("barrier","prefit-barrier.json",rawjson({"role":"actual retained-reference native entry barrier","started_monotonic":started,"deadline_monotonic":deadline,"protocol_sha256":config["protocol"]["sha256"],"configuration_sha256":sha256(config_raw).hexdigest(),"publications":publications,"reference_roster":[{"variant":"unedited-reference","proton_view":"V2","status":"UNENTERED"}],"new_controls":1,"source_table_control_roster":[C4_SELECTION],"repeated_old_controls":0,"new_control_quantum_callbacks":0,"new_native_preparations":0,"maximum_new_callbacks":101,"previous_callback_reservations":33,"old_windows_closed":True}))
    if time.monotonic()>=deadline or complete_parent_cpu()>=BOUNDS["parent_cpu_seconds"]-0.5:raise ValueError("new allocation exhausted before worker entry")
    argv=[config["native_python"],config["worker"]["path"],"--config",str(config_path),"--sha256",sys.argv[2],"--work",str(work),"--prefit-sha256",barrier["manifest_sha256"],"--started",str(started),"--deadline",str(deadline)]
    journal.update(stage="WORKER_LAUNCH_REQUEST",worker_launch_requests=1)
    process=wait_worker(argv,config["worker_environment"],work,out,deadline,roots,custody,bridge,publish,base_bytes,mutable_roots)
    journal["stage"]="WORKER_WAIT_FINISHED"
    path=work/"worker-report.json";report=read_structured_produced(path)
    reason=process["operational_refusal"]
    if report is None or process["exit_code"]!=0:reason=reason or "WORKER_OR_REPORT_REFUSAL"
    if report and report.get("final_source_closure_refusal"):reason=reason or "WORKER_SOURCE_CLOSURE_REFUSAL"
    if report and report.get("attempted_callback_reservations",0)>101:reason=reason or "CALLBACK_CAP"
    existing_coverage=published_raw_coverage(work,out,publications)
    remainder=[];complete_coverage=[]
    reached=files(work)+(out/"worker-stdout.txt",out/"worker-stderr.txt")
    for p in reached:
        raw=p.read_bytes();row={"path":str(p),"bytes":len(raw),"sha256":sha256(raw).hexdigest()}
        if str(p) in existing_coverage:row["coverage"]=existing_coverage[str(p)]
        else:remainder.append(row)
        complete_coverage.append(row)
    for i in range(0,len(remainder),50):
        rows=remainder[i:i+50]
        raw,index=custody.zip_payload({Path(row["path"]).relative_to(out).as_posix():read(row) for row in rows})
        pub=publish_blob(f"remainder-{i//50:03d}",f"raw/remainder-{i//50:03d}.zip",raw,"application/zip",closure=True)
        for row in rows:row["coverage"]={"kind":"new-genuine-closure-archive-member","publication":pub,"zip_member":Path(row["path"]).relative_to(out).as_posix()}
        publish(f"remainder-index-{i//50:03d}",f"raw/remainder-{i//50:03d}.index.json",rawjson(index),closure=True)
    if any("coverage" not in row for row in complete_coverage):raise ValueError("complete reached source custody coverage missing")
    publish_blob("complete-raw-coverage","raw/complete-physical-source-coverage.json",rawjson(complete_coverage),closure=True)
    try:
        for row in config["selected_sources"]:read(row)
        authenticate_profile(json.loads(profile_raw))
        verify_python_cache(config)
    except BaseException as exc:
        reason=reason or "FINAL_PRODUCING_SOURCE_REFUSAL";process["final_source_refusal"]={"type":type(exc).__name__,"message":str(exc)}
    aggregate,inventory=cumulative_inventory(roots)
    validate_immutable_roots(roots,mutable_roots)
    reason=reason or complete_refusal(process["complete_waited_worker_cpu_seconds"],time.monotonic(),deadline,complete_parent_cpu(),directory_bytes(out),aggregate)
    summary={"role":"one exposed retained-reference coupled repair; no kinetics/qualification","process":process,"operational_refusal":reason,"worker_report":report,
        "selected_reference_status":"OPERATIONALLY_REFUSED" if reason else report["native_case_status"],
        "old_cost_and_exposure":config["old_cost_and_exposure"],"cumulative_worker_cpu_seconds_before_outer_tail":str(PRIOR_WORKER+Decimal(str(process["complete_waited_worker_cpu_seconds"]))),
        "cumulative_worker_cpu_charge_seconds":str(PRIOR_WORKER+Decimal(str(process["conservative_worker_cpu_charge_seconds"]))),
        "started_monotonic":started,"deadline_monotonic":deadline,"whole_elapsed_seconds_before_closure":time.monotonic()-started,"parent_cpu_seconds_before_closure":complete_parent_cpu(),"parent_own_cpu_seconds_before_closure":own_cpu(),
        "cumulative_directories":inventory,"cumulative_physical_bytes_before_closure":aggregate,"new_controls":1,"source_table_control_selection":C4_SELECTION,"repeated_old_controls":0,"new_control_quantum_callbacks":0,"new_native_preparations":0}
    summary_raw=(json.dumps(summary,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
    if len(summary_raw)>32*MIB:raise ValueError("bounded complete structured summary required")
    publish_blob("summary","measured-summary.json",summary_raw,closure=True)
    journal["stage"]="CLOSED_CENSUS_VERIFICATION"
    manifests=tuple(out.rglob("*.manifest.json"))
    for p in manifests:plane.verify_manifest(decode_artifact_manifest(p.read_bytes()))
    rows=[{"name":p.relative_to(out).as_posix(),"bytes":p.stat().st_size,"sha256":sha256(p.read_bytes()).hexdigest()} for p in files(out)]
    census=rawjson({"members_excluding_self":rows,"authenticated_publications":len(manifests),"bounds":BOUNDS,"whole_elapsed_seconds_before_census":time.monotonic()-started,"parent_cpu_seconds_before_census":complete_parent_cpu(),"parent_own_cpu_seconds_before_census":own_cpu(),"old_cost_and_exposure":config["old_cost_and_exposure"],"cumulative_directories_before_census":cumulative_inventory(roots)[1]})
    aggregate,_=cumulative_inventory(roots)
    if len(census)>16*MIB or complete_refusal(process["complete_waited_worker_cpu_seconds"],time.monotonic(),deadline,complete_parent_cpu(),directory_bytes(out)+len(census),aggregate+len(census)):
        raise ValueError("final complete closure bound refused; reached bytes preserved")
    with (out/"closed-census.json").open("xb") as f:f.write(census)
    for p in files(out):p.chmod(0o444)
    for p in sorted([p for p in out.rglob("*") if p.is_dir()],reverse=True):p.chmod(0o555)
    out.chmod(0o555);journal["stage"]="PACKET_CLOSED"
    print(json.dumps({"packet":str(out),"census_sha256":sha256(census).hexdigest(),"status":summary["selected_reference_status"],"operational_refusal":reason}))
    if reason:raise SystemExit(2)


def main():
    started=time.monotonic()
    journal={"event":"PARENT_ENTRY","started_monotonic":started,"deadline_monotonic":started+1200,"stage":"BEFORE_CONFIGURATION_GUARDS","worker_launch_requests":0,"own_cpu_seconds_at_entry":own_cpu()}
    print(json.dumps(journal,sort_keys=True),file=sys.stderr,flush=True)
    def cpu_signal(signum,frame):
        raise RuntimeError("PARENT_SIGXCPU_CAP_REACHED")
    signal.signal(signal.SIGXCPU,cpu_signal)
    exc_info=None
    try:return _run_selected(started,journal)
    except BaseException as exc:
        exc_info={"type":type(exc).__name__,"message":str(exc),"system_exit_code":exc.code if isinstance(exc,SystemExit) else None};raise
    finally:
        children=resource.getrusage(resource.RUSAGE_CHILDREN)
        final={**journal,"event":"PARENT_EXIT","exception":exc_info,"own_cpu_seconds_before_exit_record":own_cpu(),"waited_child_cpu_seconds_before_exit_record":children.ru_utime+children.ru_stime,"known_waited_worker_cpu_seconds":WAITED_WORKER_CPU,"complete_parent_cpu_seconds_before_exit_record":complete_parent_cpu(),"elapsed_wall_seconds_before_exit_record":time.monotonic()-started,"measurement_tail":"full outer wait retains startup/exit serialization/closure tails"}
        print(json.dumps(final,sort_keys=True),file=sys.stderr,flush=True)


if __name__=="__main__":main()
