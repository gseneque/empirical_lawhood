"""Prospective selected QM/MM worker. Nothing runs on import."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys


def rawjson(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()


def exact_read(binding, maximum=16*1024**2):
    path = Path(binding['path'])
    if path.is_symlink() or not path.is_file() or path.stat().st_size > maximum:
        raise ValueError('bounded regular frozen source required')
    raw = path.read_bytes()
    if len(raw) != binding['bytes'] or sha256(raw).hexdigest() != binding['sha256']:
        raise ValueError('frozen source identity differs')
    return raw


def write_new(path, value):
    raw = value if type(value) is bytes else rawjson(value)
    if len(raw) > 16*1024**2:
        raise ValueError('selected worker member byte bound exceeded')
    with Path(path).open('xb') as stream:
        stream.write(raw)


def loaded_profile(profile, selected_sources):
    """Check actual module/native mappings without importing scientific packages."""
    rows = profile['files']+selected_sources
    by_path = {str(Path(row.get('resolved_path', row['path'])).resolve()): row for row in rows}
    mapped = set()
    for line in Path('/proc/self/maps').read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith('/'):
            path = fields[5].removesuffix(' (deleted)')
            mapped.add(str(Path(path).resolve()))
    modules = set()
    for module in tuple(sys.modules.values()):
        path = getattr(module, '__file__', None)
        if path:
            member = Path(path)
            if member.suffix == '.pyc':
                import importlib.util
                member = Path(importlib.util.source_from_cache(str(member)))
            modules.add(str(member.resolve()))
    unknown = sorted((mapped | modules)-set(by_path))
    if unknown:
        raise ValueError('unbound actual native/module source: '+repr(unknown))
    return {'mapped_files': sorted(mapped), 'module_files': sorted(modules),
            'all_observed_sources_bound': True,
            'scope': 'observed source closure at this point; future imports are checked again'}


def main():
    import os
    import resource
    import time
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--work', required=True)
    parser.add_argument('--prefit-barrier-sha256', required=True)
    args = parser.parse_args()
    config_path = Path(args.config)
    config_raw = config_path.read_bytes()
    if sha256(config_raw).hexdigest() != args.sha256:
        raise ValueError('selected configuration digest differs')
    config = json.loads(config_raw)
    if config.get('scientific_protocol_frozen') is not True:
        raise ValueError('prospective draft cannot enter native work')
    work = Path(args.work)
    if work.is_symlink() or not work.is_dir() or any(work.iterdir()):
        raise ValueError('explicit selected unused worker directory required')
    selected = config['selected_sources']
    for row in selected:
        exact_read(row, maximum=64*1024**2)
    protocol = exact_read(config['protocol'], maximum=128*1024)
    if sha256(protocol).hexdigest() != config['protocol']['sha256']:
        raise ValueError('selected scientific protocol differs')
    profile = json.loads(exact_read(config['profile'], maximum=8*1024**2))
    for row in profile['files']:
        actual = Path(row['path']).resolve(strict=True)
        if str(actual) != row['resolved_path'] or actual.stat().st_size != row['bytes']:
            raise ValueError('selected installed source location/count differs')
        digest = sha256()
        with actual.open('rb') as stream:
            for block in iter(lambda: stream.read(1024**2), b''):
                digest.update(block)
        if digest.hexdigest() != row['sha256']:
            raise ValueError('selected installed source bytes changed')
    start = config['whole_started_monotonic']
    if not 0 < start <= time.monotonic() < start+config['bounds']['wall_seconds']:
        raise ValueError('selected cumulative wall allocation exhausted')
    resource.setrlimit(resource.RLIMIT_AS, (config['bounds']['memory_bytes'],)*2)
    resource.setrlimit(resource.RLIMIT_CPU, (config['bounds']['worker_cpu_seconds'],)*2)
    resource.setrlimit(resource.RLIMIT_FSIZE, (32*1024**2,)*2)
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
    expected_env = config['worker_environment']
    if any(os.environ.get(k) != v for k, v in expected_env.items()):
        raise ValueError('realized selected worker environment differs')
    for name in ('ash_user_settings.ini', '.ncrc', '.netcdfrc', '.xtbrc'):
        if Path('/home/chevre', name).exists() or Path('/home/chevre', name).is_symlink():
            raise ValueError('unselected native user configuration present: '+name)
    sys.path.insert(0, config['el_source_root'])
    sys.path.insert(0, config['helper_root'])
    from empirical_lawhood.adapters.simulators.rubisco_electronic import rr_qmmm_xtb as qm
    if Path(qm.__file__).resolve() != Path(config['qm_owner']['path']):
        raise ValueError('actual EL source resolved to another checkout')
    import bounded_executor
    import custody_bridge
    import native_coupling
    entered = []
    def native_audit(event, values):
        if event == 'subprocess.Popen':
            if values[0] != config['binary']['path']:
                raise RuntimeError('unselected worker process '+repr(values[0]))
            entered.append({'program': str(values[0]), 'argv': tuple(str(v) for v in values[1]),
                            'cwd': None if values[2] is None else os.fspath(values[2])})
    sys.addaudithook(native_audit)
    cases = work/'cases'
    cases.mkdir()
    controls_root = work/'native-controls'
    runtimes = []
    stage = 'controls'
    report = {'role': 'selected exposed finite QM/MM supplier inquiry; no kinetic qualification',
        'protocol_sha256': config['protocol']['sha256'],
        'prefit_barrier_sha256': args.prefit_barrier_sha256,
        'native_case_status': 'UNENTERED', 'controls': 'UNENTERED',
        'new_original_nonbonded_admissions': 0, 'new_coupled_source_admissions': 0,
        'new_exposed_context_reconstructions': 0, 'reference_native_constructions': 0,
        'original_nonbonded_admission_attempts': 0, 'coupled_source_admission_attempts': 0,
        'exposed_context_reconstruction_attempts': 0, 'reference_native_construction_attempts': 0}

    def factory(scratch_case, label, maximum_callbacks):
        case = Path(scratch_case)
        if (not case.is_absolute() or case.parent not in (cases, controls_root)
                or case.exists() or case.is_symlink()):
            raise ValueError('unused selected direct case locator required')
        case.mkdir()
        calls = case/'calls'; calls.mkdir()
        bridge = case/'bridge'; bridge.mkdir()
        a = bounded_executor.ExecutorAllocation(str(calls), config['binary']['path'], config['binary']['sha256'],
            config['parameters']['path'], config['parameters']['sha256'], maximum_callbacks,
            config['bounds']['control_cpu_seconds'] if stage == 'controls' else config['bounds']['worker_cpu_seconds'],
            config['bounds']['wall_seconds'],
            config['bounds']['per_native_cpu_seconds'], config['bounds']['per_native_wall_seconds'],
            config['bounds']['memory_bytes'], 16*1024**2, config['bounds']['native_case_output_bytes'])
        executor = bounded_executor.BoundedExecutor(a, capture_type=qm.XtbSinglePointCaptureV1,
            whole_started_monotonic=start)
        def selected_executor(plan):
            if sum(r.callback_reservations for r, _ in runtimes) > config['bounds']['objective_cap']:
                raise ValueError('whole objective reservation cap exhausted')
            loaded_profile(profile, selected)
            if stage == 'controls':
                own = resource.getrusage(resource.RUSAGE_SELF)
                waited = resource.getrusage(resource.RUSAGE_CHILDREN)
                if own.ru_utime+own.ru_stime+waited.ru_utime+waited.ru_stime >= config['bounds']['control_cpu_seconds']:
                    raise ValueError('complete control-stage CPU allocation exhausted')
            custody_bridge.await_plan_publication(plan, bridge,
                whole_deadline=start+config['bounds']['wall_seconds'])
            return executor(plan)
        def retain(plan, capture):
            custody_bridge.await_capture_publication(plan, capture, bridge,
                whole_deadline=start+config['bounds']['wall_seconds'])
        theory = qm.StrictQmmmXtbTheoryV1(executable_path=a.binary, parameter_path=a.parameter,
            output_root=str(calls), executor=selected_executor, retain_capture=retain,
            maximum_callbacks=maximum_callbacks)
        runtimes.append((theory, executor))
        return theory

    os.chdir(work)
    try:
        libs = native_coupling.load_bound_native_libraries(protocol_sha256=config['protocol']['sha256'],
            site_packages=config['native_site_packages'])
        report['profile_after_native_import'] = loaded_profile(profile, selected)
        report['controls'] = json.loads(exact_read(config['retained_completed_controls']))
        prior_summary = json.loads(exact_read(config['retained_completed_summary']))
        report['capacity'] = prior_summary['worker_report']['capacity']
        report['reused_development_controls'] = {
            'source_protocol_sha256': config['completed_operational_ancestor']['protocol_sha256'],
            'new_control_contexts': 0, 'new_control_callbacks': 0,
            'new_capacity_callbacks': 0, 'fresh_biological_evidence': False}
        if report['controls']['status'] != 'PASS' or report['capacity']['status'] != 'PASS':
            raise ValueError('retained complete native controls did not pass')
        own = resource.getrusage(resource.RUSAGE_SELF)
        waited = resource.getrusage(resource.RUSAGE_CHILDREN)
        report['complete_control_stage_cpu_seconds_before_reference'] = own.ru_utime+own.ru_stime+waited.ru_utime+waited.ru_stime
        if report['complete_control_stage_cpu_seconds_before_reference'] > config['bounds']['control_cpu_seconds']:
            raise ValueError('complete control-stage CPU allocation exceeded')
        stage = 'reference'
        from empirical_lawhood.adapters.physical.rubisco_kinetics import rr_amber_nonbonded as amber
        from empirical_lawhood.adapters.physical.rubisco_kinetics import rr_coupled_preparation as preparation
        from empirical_lawhood.adapters.physical.rubisco_kinetics import rr_qmmm_reference_topology as topology
        from empirical_lawhood.adapters.simulators.rubisco_electronic import rr_xtb_repair as old
        chunks = tuple(exact_read(row, maximum=8*1024**2) for row in config['prmtop_chunks'])
        report['original_nonbonded_admission_attempts'] += 1
        original = amber.decode_rr_amber_nonbonded(chunks)
        report['new_original_nonbonded_admissions'] += 1
        source_args = tuple(exact_read(row) for row in config['coupled_sources'])
        report['coupled_source_admission_attempts'] += 1
        if len(source_args) != 7:
            raise ValueError('complete seven-member coupled source roster required')
        source = preparation.decode_rr_coupled_source(*source_args[:4], source_args[4:])
        report['new_coupled_source_admissions'] += 1
        report['exposed_context_reconstruction_attempts'] += 1
        job = old.RrXtbRepairInputV1(source, exact_read(config['held_reference_v2']))
        report['new_exposed_context_reconstructions'] += 1
        reference = topology.derive_rr_reference_topology(job.context, job.embedding, original)
        manifest = reference.native_manifest()
        manifest_raw = rawjson(manifest)
        if len(manifest_raw) > 64*1024**2:
            raise ValueError('whole native plan serialization exceeds selected64MiB bound')
        plan_members = []
        for i, offset in enumerate(range(0, len(manifest_raw), 8*1024**2)):
            member = manifest_raw[offset:offset+8*1024**2]
            name = f'reference-topology-plan.json.part-{i:04d}'
            write_new(work/name, member)
            plan_members.append({'name': name, 'bytes': len(member), 'sha256': sha256(member).hexdigest()})
        report['reference_plan_binding'] = {'whole_bytes': len(manifest_raw),
            'whole_sha256': sha256(manifest_raw).hexdigest(), 'ordered_chunks': plan_members,
            'whole_bound_bytes': 64*1024**2, 'chunk_bound_bytes': 8*1024**2}
        write_new(work/'reference-topology-plan.json.join.json', report['reference_plan_binding'])
        quantum = factory(cases/'reference-v2', 'reference-v2', 101)
        prmtop = work/'original-prepared.prmtop'
        with prmtop.open('xb') as stream:
            for chunk in chunks:
                stream.write(chunk)
        report['reference_native_construction_attempts'] += 1
        session = native_coupling.build_reference_coupling(prmtop, manifest, quantum,
            scratch_directory=cases/'reference-v2'/'model', protocol_sha256=config['protocol']['sha256'],
            native_libraries=libs)
        report['reference_native_constructions'] += 1
        write_new(work/'reference-native-construction.json', session.audit)
        report['profile_after_reference_construction'] = loaded_profile(profile, selected)
        import reference_assessment
        report['reference'] = reference_assessment.run_reference_repair(libs, session, quantum,
            job, work/'reference-observations', config)
        report['native_case_status'] = report['reference']['status']
    except BaseException as exc:
        report['refusal'] = {'type': type(exc).__name__, 'message': str(exc)}
        report['native_case_status'] = 'REFUSED' if report['reference_native_construction_attempts'] else 'UNENTERED'
    finally:
        try:
            report['profile_after_all_operation_tails'] = loaded_profile(profile, selected)
        except BaseException as exc:
            report['final_source_closure_refusal'] = {'type': type(exc).__name__, 'message': str(exc)}
            report['native_case_status'] = 'REFUSED' if report['reference_native_construction_attempts'] else 'UNENTERED'
        own = resource.getrusage(resource.RUSAGE_SELF)
        waited = resource.getrusage(resource.RUSAGE_CHILDREN)
        report['own_cpu_seconds_before_report_serialization'] = own.ru_utime+own.ru_stime
        report['waited_children_cpu_seconds_before_report_serialization'] = waited.ru_utime+waited.ru_stime
        report['whole_wall_seconds_before_report_serialization'] = time.monotonic()-start
        report['complete_worker_cost_scope'] = 'external caller wait accounts startup, report serialization and tail'
        report['attempted_callback_reservations'] = sum(r.callback_reservations for r, _ in runtimes)
        report['native_processes_started'] = sum(executor.started_processes for _, executor in runtimes)
        report['attempted_popen_audit_event_count'] = len(entered)
        report['attempted_popen_audit_events'] = entered
        report['executor_observations'] = [observation for _, executor in runtimes for observation in executor.observations]
        write_new(work/'worker-report.json', report)


if __name__ == '__main__':
    main()
