"""Prospective bounded CLI executor; no I/O, clock or process at import.

The selected caller supplies frozen inputs, output roots and allocations.
This helper retains raw attempts; it creates no scientific issue authority.
"""
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path


def rawjson(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()


def digest_file(path):
    digest = sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024**2), b''):
            digest.update(block)
    return digest.hexdigest()


def write_new(path, raw, maximum):
    if type(raw) is not bytes or len(raw) > maximum:
        raise ValueError('selected output member byte bound exceeded')
    with path.open('xb') as stream:
        stream.write(raw)


def regular_files(root, member_maximum):
    rows = []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError('output symbolic link refused')
        if path.is_dir():
            continue
        if not path.is_file() or path.stat().st_size > member_maximum:
            raise ValueError('output member type or size refused')
        rows.append({'name': path.relative_to(root).as_posix(),
                     'bytes': path.stat().st_size, 'sha256': digest_file(path)})
    return rows


def observe_output_files(root, member_maximum):
    """Keep refusal metadata without following native symlinks or special files."""
    import os
    import stat
    rows = []
    refusal = None
    for path in sorted(root.rglob('*')):
        state = path.lstat()
        if stat.S_ISDIR(state.st_mode):
            continue
        row = {'name': path.relative_to(root).as_posix(), 'bytes': state.st_size,
               'mode': stat.S_IMODE(state.st_mode)}
        if stat.S_ISLNK(state.st_mode):
            row['refused_symlink_target'] = os.readlink(path)
            refusal = refusal or 'NATIVE_OUTPUT_SYMBOLIC_LINK_REFUSED'
        elif not stat.S_ISREG(state.st_mode):
            row['refused_nonregular_mode'] = state.st_mode
            refusal = refusal or 'NATIVE_OUTPUT_SPECIAL_FILE_REFUSED'
        else:
            row['sha256'] = digest_file(path)
            if state.st_size > member_maximum:
                row['refused_member_overbound'] = True
                refusal = refusal or 'NATIVE_MEMBER_CAP'
        rows.append(row)
    return rows, refusal


@dataclass(frozen=True)
class ExecutorAllocation:
    output_root: str
    binary: str
    binary_sha256: str
    parameter: str
    parameter_sha256: str
    maximum_callbacks: int
    total_cpu_seconds: int
    total_wall_seconds: int
    per_call_cpu_seconds: int
    per_call_wall_seconds: int
    memory_bytes: int
    member_bytes: int
    aggregate_output_bytes: int

    def __post_init__(self):
        for name in ('output_root', 'binary', 'parameter'):
            path = Path(getattr(self, name))
            if not path.is_absolute() or '..' in path.parts:
                raise ValueError('explicit absolute selected paths required')
        for name in ('binary_sha256', 'parameter_sha256'):
            value = getattr(self, name)
            if type(value) is not str or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
                raise ValueError('exact selected source hash required')
        for name in ('maximum_callbacks', 'total_cpu_seconds', 'total_wall_seconds',
                     'per_call_cpu_seconds', 'per_call_wall_seconds', 'memory_bytes',
                     'member_bytes', 'aggregate_output_bytes'):
            if type(getattr(self, name)) is not int or getattr(self, name) <= 0:
                raise ValueError('positive finite integral allocation required')
        if self.per_call_cpu_seconds > self.total_cpu_seconds or self.per_call_wall_seconds > self.total_wall_seconds:
            raise ValueError('individual allocation exceeds selected total')
        if self.aggregate_output_bytes < 256*1024 or self.member_bytes < 65536:
            raise ValueError('allocation must retain bounded refusal/closure sidecars')


class BoundedExecutor:
    """Explicit selection starts one cumulative allocation, never a fresh retry."""

    def __init__(self, allocation, *, capture_type, whole_started_monotonic):
        import time
        if type(allocation) is not ExecutorAllocation:
            raise ValueError('exact selected allocation required')
        if type(whole_started_monotonic) not in (int, float) or not 0 < whole_started_monotonic <= time.monotonic():
            raise ValueError('selected whole-operation start required')
        self.allocation = allocation
        self.capture_type = capture_type
        self.started = whole_started_monotonic
        self.attempted = 0
        self.started_processes = 0
        self.observations = []

    def _costs(self):
        import resource
        import time
        own = resource.getrusage(resource.RUSAGE_SELF)
        children = resource.getrusage(resource.RUSAGE_CHILDREN)
        return own.ru_utime+own.ru_stime, children.ru_utime+children.ru_stime, time.monotonic()-self.started

    def __call__(self, plan):
        import math
        import os
        import resource
        import subprocess
        import time
        a = self.allocation
        root, work = Path(a.output_root), Path(plan.output_locator)
        if root.is_symlink() or not root.is_dir() or work.parent != root or work.exists() or work.is_symlink():
            raise ValueError('unused direct child of selected output root required')
        if plan.program_argv[0] != a.binary or '--vparam' not in plan.program_argv:
            raise ValueError('selected CLI source path differs')
        parameter_index = plan.program_argv.index('--vparam')+1
        if parameter_index >= len(plan.program_argv) or plan.program_argv[parameter_index] != a.parameter:
            raise ValueError('selected exact parameter operand differs')
        for path, digest in ((Path(a.binary), a.binary_sha256), (Path(a.parameter), a.parameter_sha256)):
            if path.is_symlink() or not path.is_file() or digest_file(path) != digest:
                raise ValueError('selected native source changed before contact')
        if (Path(a.parameter).parent/'.xtbrc').exists() or (Path(a.parameter).parent/'.xtbrc').is_symlink():
            raise ValueError('unselected native parameter configuration present')
        own_before, waited_before, wall_before = self._costs()
        if self.attempted >= a.maximum_callbacks or own_before+waited_before >= a.total_cpu_seconds-1 or wall_before >= a.total_wall_seconds:
            raise ValueError('complete cumulative callback allocation exhausted')
        existing, existing_refusal = observe_output_files(root, a.member_bytes)
        if existing_refusal or sum(r['bytes'] for r in existing)+sum(len(raw) for _, raw in plan.input_files)+65536 > a.aggregate_output_bytes:
            raise ValueError('complete output allocation exhausted before native contact')
        self.attempted += 1
        work.mkdir()
        for name, raw in plan.input_files:
            relative = Path(name)
            if relative.name != name or name in ('.', '..'):
                raise ValueError('native input must be a single bounded basename')
            write_new(work/name, raw, a.member_bytes)
        environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
            'XTBPATH': str(Path(a.parameter).parent), 'XTBHOME': str(Path(a.parameter).parent),
            'TMPDIR': str(work), 'OMP_NUM_THREADS': '1', 'OMP_DYNAMIC': 'FALSE',
            'OMP_MAX_ACTIVE_LEVELS': '1', 'MKL_NUM_THREADS': '1', 'MKL_DYNAMIC': 'FALSE',
            'OPENBLAS_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1',
            'VECLIB_MAXIMUM_THREADS': '1', 'BLIS_NUM_THREADS': '1'}
        if 'HOME' in os.environ:
            environment['HOME'] = os.environ['HOME']
        write_new(work/'entered-contact.json', rawjson({'plan_identity': plan.identity,
            'execution_id': plan.execution_id, 'argv': plan.program_argv, 'environment': environment,
            'reserved_native_objectives': 1, 'native_process_started': False}), a.member_bytes)
        own, waited, wall = self._costs()
        inherited_hard = resource.getrlimit(resource.RLIMIT_CPU)[1]
        cpu_limit = min(a.per_call_cpu_seconds, math.floor(a.total_cpu_seconds-own-waited))
        if inherited_hard != resource.RLIM_INFINITY:
            cpu_limit = min(cpu_limit, inherited_hard)
        remaining_wall = min(a.per_call_wall_seconds, a.total_wall_seconds-wall)
        if cpu_limit < 1 or remaining_wall <= 0:
            raise ValueError('allocation exhausted during native preflight')
        before_spawn, before_spawn_refusal = observe_output_files(root, a.member_bytes)
        preflight_refusal = before_spawn_refusal or ('NATIVE_OUTPUT_CAP' if sum(row['bytes'] for row in before_spawn)+65536 > a.aggregate_output_bytes else None)

        def limits():
            resource.setrlimit(resource.RLIMIT_CPU, (cpu_limit, cpu_limit))
            resource.setrlimit(resource.RLIMIT_AS, (a.memory_bytes, a.memory_bytes))
            resource.setrlimit(resource.RLIMIT_FSIZE, (a.member_bytes, a.member_bytes))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))

        process = None
        exit_code = None
        reason = None
        error = None
        native_started = time.monotonic()
        peak_rss = 0
        with (work/'stdout.txt').open('xb') as out, (work/'stderr.txt').open('xb') as err:
            try:
                if preflight_refusal:
                    raise ValueError('output allocation exhausted in final pre-spawn census')
                process = subprocess.Popen(plan.program_argv, cwd=work, env=environment,
                    stdin=subprocess.DEVNULL, stdout=out, stderr=err, preexec_fn=limits)
                self.started_processes += 1
                write_new(work/'started-native-process.json', rawjson({'pid': process.pid,
                    'execution_id': plan.execution_id, 'reserved_native_objectives': 1}), a.member_bytes)
                while process.poll() is None:
                    own, waited, wall = self._costs()
                    live_cpu = 0.0
                    try:
                        fields = Path(f'/proc/{process.pid}/stat').read_text().rsplit(')', 1)[1].split()
                        live_cpu = sum(int(fields[i]) for i in (11, 12, 13, 14))/os.sysconf('SC_CLK_TCK')
                        for line in Path(f'/proc/{process.pid}/status').read_text().splitlines():
                            if line.startswith('VmHWM:'):
                                peak_rss = max(peak_rss, int(line.split()[1])*1024)
                    except FileNotFoundError:
                        pass
                    size = 0
                    for path in root.rglob('*'):
                        if path.is_symlink():
                            reason = 'NATIVE_OUTPUT_SYMBOLIC_LINK_REFUSED'
                            break
                        if path.is_file():
                            size += path.stat().st_size
                            if path.stat().st_size > a.member_bytes:
                                reason = 'NATIVE_MEMBER_CAP'
                                break
                    reason = reason or ('NATIVE_CALL_WALL_CAP' if time.monotonic()-native_started >= remaining_wall else
                        'WHOLE_WALL_CAP' if wall >= a.total_wall_seconds else
                        'WHOLE_CPU_CAP' if own+waited+live_cpu >= a.total_cpu_seconds-.25 else
                        'NATIVE_MEMORY_CAP' if peak_rss > a.memory_bytes else
                        'NATIVE_OUTPUT_CAP' if size > a.aggregate_output_bytes-65536 else None)
                    if reason:
                        process.kill()
                        break
                    time.sleep(.02)
                exit_code = process.wait()
            except Exception as exc:
                error = {'type': type(exc).__name__, 'message': str(exc)}
                reason = preflight_refusal or ('NATIVE_SPAWN_REFUSAL' if process is None else 'NATIVE_MONITOR_REFUSAL')
                if process is not None:
                    if process.poll() is None:
                        process.kill()
                    exit_code = process.wait()
        own_after, waited_after, wall_after = self._costs()
        files, file_refusal = observe_output_files(work, a.member_bytes)
        total_files, root_refusal = observe_output_files(root, a.member_bytes)
        reason = reason or ('WHOLE_CPU_CAP' if own_after+waited_after > a.total_cpu_seconds else
            'WHOLE_WALL_CAP' if wall_after > a.total_wall_seconds else
            'NATIVE_CALL_WALL_CAP' if time.monotonic()-native_started > remaining_wall else
            'NATIVE_CALL_CPU_CAP' if waited_after-waited_before > cpu_limit else
            'NATIVE_OUTPUT_CAP' if sum(row['bytes'] for row in total_files) > a.aggregate_output_bytes-65536 else
            file_refusal or root_refusal)
        observation = {'execution_id': plan.execution_id, 'plan_identity': plan.identity,
            'argv': plan.program_argv, 'environment': environment,
            'native_started': process is not None, 'pid': None if process is None else process.pid,
            'returncode': exit_code, 'operational_refusal': reason, 'exception': error,
            'waited_native_cpu_seconds': waited_after-waited_before,
            'own_cpu_seconds': own_after-own_before, 'wall_seconds': wall_after-wall_before,
            'whole_cpu_seconds': own_after+waited_after, 'whole_wall_seconds': wall_after,
            'observed_peak_rss_bytes': peak_rss, 'child_cpu_rlimit': cpu_limit,
            'attempted_callbacks': self.attempted, 'started_processes': self.started_processes,
            'reserved_native_objectives': self.attempted, 'files_before_observation': files,
            'reserved_closure_bytes': 65536,
            'cost_scope': 'through waited process and pre-census costs; census/serialization/tail remain in whole-worker accounting'}
        # Derive the exact stable final byte count before publishing the sidecar.
        physical_before = sum(row['bytes'] for row in total_files)
        for _ in range(16):
            raw_observation = rawjson(observation)
            final_bytes = physical_before+len(raw_observation)
            if final_bytes > a.aggregate_output_bytes and reason is None:
                reason = observation['operational_refusal'] = 'NATIVE_OUTPUT_CAP'
                continue
            if observation.get('aggregate_bytes_after_this_sidecar') == final_bytes:
                break
            observation['aggregate_bytes_after_this_sidecar'] = final_bytes
        else:
            raise ValueError('bounded closure byte identity did not stabilize')
        write_new(work/'process-observation.json', raw_observation, min(65536, a.member_bytes))
        final_files, final_refusal = observe_output_files(root, a.member_bytes)
        final_actual = sum(row['bytes'] for row in final_files)
        reason = reason or final_refusal or ('NATIVE_OUTPUT_CAP' if final_actual > a.aggregate_output_bytes else None)
        if reason != observation['operational_refusal']:
            write_new(work/'post-write-operational-refusal.json', rawjson({
                'execution_id': plan.execution_id, 'operational_refusal': reason,
                'aggregate_bytes_observed_before_refusal_sidecar': final_actual,
                'original_process_observation_sha256': sha256(raw_observation).hexdigest()}), 65536)
        self.observations.append(observation)

        def optional(name):
            path = work/name
            if not path.exists():
                return None
            if path.is_symlink() or not path.is_file() or path.stat().st_size > a.member_bytes:
                return None
            return path.read_bytes()

        failures = tuple(row['name'] for row in files if row['name'] in
            ('.sccnotconverged', '.sccerror', '.xtb_error', 'NOT_CONVERGED'))
        return self.capture_type(plan_identity=plan.identity, execution_id=plan.execution_id,
            output_locator=plan.output_locator, program_argv=plan.program_argv,
            returncode=exit_code, stdout=optional('stdout.txt') or b'',
            stderr=optional('stderr.txt') or b'', gradient_bytes=optional('gradient'),
            pcgrad_bytes=optional('pcgrad'), native_failure_files=failures,
            operational_refusal=reason)
