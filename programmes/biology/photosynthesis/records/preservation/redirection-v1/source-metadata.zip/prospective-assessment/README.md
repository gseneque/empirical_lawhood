# Prospective coupled-return retention successor

This is exposed software work under R0–R2. No native evaluation, authentic
source admission, protocol freeze or public workflow is selected here. It does
not recover the missing historical v3 coupled energy or gradient.

The maintained pure adapter encoder returns ordinary JSON bytes for the complete
provided energy and gradient, with source/atom/input/unit joins. Float tokens
preserve binary64 bits; NumPy arrays additionally retain exact dtype/endian,
shape and C-order logical value bytes, including nonfinite payloads. That byte
snapshot represents the logical array values rather than its backing allocation.
No numerical admission or truncation occurs in the encoder. Unsupported
representations and encoding limits refuse the complete capture explicitly.

The private `reference_assessment.py` copies the frozen v8 helper and inserts
raw retention immediately after the coupled function returns, before its
unchanged energy/gradient guards. It distinguishes returned, captured and
numerically accepted counts. The original scientific finite bound, units,
geometry screens, active/fixed denominator and optimizer call are unchanged.
A failed capture prevents numerical admission. Partial physical writes, if any,
remain for the selected caller's complete raw-file closure.

A future selected config must add `coupled_return_encoder` with the maintained
module's exact `path`, `bytes` and `sha256`, select it in source guards and the
producing archive, and bind this new assessment. The helper checks the encoder
bytes and actual imported module path before use. Raw capture has sixteen MiB
expanded and stored limits, inside the future caller's full physical budgets.
Its ordinary files do not create artifact-plane receipts or qualification.

The portable tests are `tests/test_rubisco_coupled_return.py`; this directory's
`test_reference_assessment.py` adds fake optimizer/return integration and failure
checks. Use the existing locked electronic profile with `uv run --no-sync`:

```bash
UV_PROJECT_ENVIRONMENT=/tmp/rubisco-electronic-20261010-env \
UV_CACHE_DIR=/tmp/rubisco-qmmm-software-uv-cache \
PYTHONDONTWRITEBYTECODE=1 uv run --no-sync python -m pytest \
  tests/test_rubisco_coupled_return.py \
  /tmp/rubisco-qmmm-redirection-v1/test_reference_assessment.py -q
```

`implementation-handoff.json` gives exact source identities and the last focused
check outcome; `assessment-successor.diff` preserves the proposed change against
the frozen helper. The two maintained files are currently untracked, and this
private successor depends on temporary storage until explicitly preserved by
the parent handoff. Old frozen helper and packet bytes are unchanged.
