"""Synthetic fake coupled returns only; no authentic source or native effects."""
import gzip
import importlib.util
import json
from pathlib import Path
import struct
from types import SimpleNamespace

import numpy as np
import pytest

from empirical_lawhood.adapters.simulators.rubisco_electronic import coupled_return as r


def join(count=2):
    return r.CoupledReturnJoinV1(
        1, 'optimization', tuple(f'atom:{i}' for i in range(count)), ('H',) * count,
        123, '1' * 64, '2' * 64, '3' * 64, (('source', 456, '4' * 64),),
    )


def numeric(token):
    return struct.unpack('>d', bytes.fromhex(token['binary64_be']))[0]


def assessment():
    # Private successor is deliberately not a public installed workflow.
    path = Path('/tmp/rubisco-qmmm-redirection-v1/reference_assessment.py')
    spec = importlib.util.spec_from_file_location('_synthetic_raw_assessment', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.parametrize('energy,gradient', [
    (float('nan'), [[0., 0., 0.], [0., 0., 0.]]),
    (float('inf'), [[0., 0., 0.], [0., 0., 0.]]),
    (1e9, [[0., 0., 0.], [0., 0., 0.]]),
    (1., [[float('nan'), 0., 0.], [0., 0., 0.]]),
    (1., [[0., float('inf'), 0.], [0., 0., 0.]]),
    (1., [[0., 0., 1e9], [0., 0., 0.]]),
    (1., [[0., 0.]]),
])
def test_complete_raw_energy_and_gradient_written_before_first_numeric_guard(tmp_path, monkeypatch, energy, gradient):
    a = assessment()
    events = []
    original_guard = a._finite

    def guard(value):
        # Even an ENERGY failure has already retained the whole gradient.
        raw = gzip.decompress((tmp_path / 'evaluation-001-unverified-return.json.gz').read_bytes())
        record = json.loads(raw)
        assert record['energy'] is not None and record['gradient'] is not None
        events.append('guard-after-complete-capture')
        return original_guard(value)

    monkeypatch.setattr(a, '_finite', guard)
    row = {'ordinal': 1, 'numerical_operand_accepted': False}
    with pytest.raises(ValueError):
        a._retain_return(tmp_path, row, energy, gradient, join())
    assert events
    assert row['native_coupled_returned'] is True
    assert row['unverified_return_capture'] == 'COMPLETE_UNVERIFIED_COUPLED_RETURN'
    assert row['numerical_operand_accepted'] is False


def test_finite_acceptance_preserves_original_guards_and_all_full_source_rows(tmp_path):
    a = assessment()
    count = 13828
    gradient = np.zeros((count, 3))
    gradient[-1, -1] = 7.
    row = {'ordinal': 1, 'numerical_operand_accepted': False}
    energy, accepted = a._retain_return(tmp_path, row, -100., gradient, join(count))
    record = json.loads(gzip.decompress((tmp_path / 'evaluation-001-unverified-return.json.gz').read_bytes()))
    assert len(record['gradient']['items']) == count
    assert numeric(record['gradient']['items'][-1]['items'][-1]) == 7.
    assert energy == -100. and accepted[-1][-1] == 7.
    assert row['numerical_operand_accepted'] is True


@pytest.mark.parametrize('failure', ['serialization', 'write'])
def test_capture_failure_retains_native_return_counter_and_never_runs_numeric_guard(tmp_path, monkeypatch, failure):
    a = assessment()

    def failed_capture(*args, **kwargs):
        raise ValueError('selected complete capture failure')

    monkeypatch.setattr(a, 'encode_unverified_coupled_return' if failure == 'serialization'
                        else '_write_raw_return', failed_capture)
    monkeypatch.setattr(a, '_finite', lambda v: pytest.fail('guard entered after capture refusal'))
    row = {'ordinal': 1, 'numerical_operand_accepted': False}
    with pytest.raises(ValueError, match='complete capture failure'):
        a._retain_return(tmp_path, row, -1., [[0., 0., 0.]], join(1))
    assert row['native_coupled_returned'] is True
    assert row['unverified_return_capture'] == 'REFUSED'
    assert row['numerical_operand_accepted'] is False
    assert 'unverified_return_snapshot' not in row


@pytest.mark.parametrize('capture_failure', [False, True])
def test_fake_optimizer_integration_reports_returned_retained_accepted_separately(tmp_path, monkeypatch, capture_failure):
    a = assessment()
    monkeypatch.setattr(a, 'PHYSICAL_ATOMS', 2)
    monkeypatch.setattr(a, '_load_geometry', lambda binding: None)
    monkeypatch.setattr(a, '_exact_read', lambda binding: b'{}')
    original = ((0., 0., 0.), (1., 0., 0.))
    monkeypatch.setattr(a, '_intake', lambda *args: (
        ('amber:1', 'amber:2'), original, (0,), (1,), (), (), (), (),
    ))
    quantum = SimpleNamespace(maximum_callbacks=101, callback_reservations=0,
                              last_observation=None)

    def native_double(**kwargs):
        quantum.callback_reservations += 1
        return float('inf'), np.array([[0., 0., 0.], [0., 0., 9e99]])

    theory = SimpleNamespace(run=native_double)
    session = SimpleNamespace(theory=theory, fragment=SimpleNamespace(coords=original))

    def optimizer(**kwargs):
        kwargs['theory'].run(current_coords=original, Grad=True, elems=('H', 'H'),
                             charge=-6, mult=1)
        pytest.fail('scientific optimizer accepted refused operands')

    libs = SimpleNamespace(numpy=np, ash=SimpleNamespace(
        constants=SimpleNamespace(bohr2ang=float(a.ASH_BOHR_ANGSTROM)), Optimizer=optimizer,
    ))
    job = SimpleNamespace(context=SimpleNamespace(
        physical_atoms=(SimpleNamespace(element='H'), SimpleNamespace(element='H')),
    ))
    binding = {'bytes': 2, 'sha256': '7' * 64}
    encoder_path = Path(r.__file__).resolve()
    encoder_binding = {'path': str(encoder_path), 'bytes': encoder_path.stat().st_size,
                       'sha256': __import__('hashlib').sha256(encoder_path.read_bytes()).hexdigest()}
    config = {'scientific_protocol_frozen': True, 'geometry_helper': binding,
              'held_reference_v2': binding, 'native_coupling': binding,
              'qm_owner': binding, 'coupled_sources': (binding,) * 7,
              'coupled_return_encoder': encoder_binding,
              'protocol': binding, 'reference_assessment': binding}
    if capture_failure:
        monkeypatch.setattr(a, '_write_raw_return', lambda *args: (_ for _ in ()).throw(
            OSError('selected raw writer refusal')))
    report = a.run_reference_repair(libs, session, quantum, job, tmp_path / 'output', config)
    assert report['status'] == 'REFERENCE_REPAIR_REFUSED'
    assert report['coupled_evaluation_entries'] == 1
    assert report['native_coupled_evaluation_returns'] == 1
    assert report['complete_unverified_return_captures'] == int(not capture_failure)
    assert report['numerically_accepted_coupled_returns'] == 0
    assert report['full_physical_evaluation_returns'] == 0
    assert report['fresh_full_coupled_gradient'] == 'UNENTERED'
    assert report['native_callback_reservations'] == 1
    assert theory.run is native_double
    assert quantum.maximum_callbacks == 101
    if not capture_failure:
        row = report['evaluation_roster'][0]
        record = json.loads(gzip.decompress(Path(row['unverified_return_snapshot']['path']).read_bytes()))
        assert record['energy']['hex'] == 'inf'
        assert numeric(record['gradient']['items'][-1]['items'][-1]) == 9e99


